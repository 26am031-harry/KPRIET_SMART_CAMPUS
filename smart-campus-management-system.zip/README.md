# KPRIET Smart Campus — Issue & Lost-and-Found Portal

Full-stack portal for **KPR Institute of Engineering and Technology (KPRIET)** to report lost/found items and maintenance issues, upvote them, claim them, and track official status updates.

Stack: Next.js (App Router) + TypeScript + Tailwind CSS · PostgreSQL via Drizzle ORM · Cookie (HMAC-signed) auth with scrypt passwords.

## Demo logins (password: `password123`)

| Role | Email |
|---|---|
| Admin | admin@kpriet.ac.in |
| Student | priya@kpriet.ac.in |
| Staff | lakshmi@kpriet.ac.in |

(One-click demo buttons are on the sign-in page.)

## Run locally

Requirements: Node.js 22+, npm 10+, PostgreSQL 14+.

**Before starting, run the pre-flight check:** `bash scripts/local-check.sh` — it verifies node, npm, PostgreSQL connectivity and your `.env`/`node_modules`, and tells you exactly what to fix.

> **The app never crashes when the database is down.** If PostgreSQL is missing or unreachable, every page still renders, a banner explains how to fix it, `/api/health` returns `ok:false` with a reason, and API calls return `503 Database unavailable` instead of a white error screen.

```bash
# 1. Install dependencies
npm install

# 2. Create a database (default name used by .env is app_db)
sudo -u postgres psql -c "CREATE DATABASE app_db;"

# 3. Point the app at your database (this project already has .env)
#    DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
#    (optional) SESSION_SECRET=...     — change the session signing secret
#    (optional) OPENAI_API_KEY=...     — makes the voice assistant answer with an LLM
#    (optional) ESCALATION_WAIT_DAYS=3 / ESCALATION_WAIT_DAYS_HIGH=1

# 4. Create the tables
npx drizzle-kit push

# 5a. Development mode (hot reload)
npm run dev              # → http://localhost:3000

# 5b. Production mode
npm run build
npm run start            # → http://localhost:3000
```

The database is seeded automatically on first request (12+ sample reports at KPRIET places like Central Library, Raagam Hall, Gym, Saaral Bakery, the blocks' classrooms, etc.). To reset the demo data:

```bash
psql "postgresql://postgres:postgres@127.0.0.1:5432/app_db" -c "TRUNCATE photos, activity, comments, claims, upvotes, escalations, posts, users RESTART IDENTITY CASCADE;"
```

## Useful scripts

```bash
npm run dev         # dev server
npm run build       # production build
npm run start       # production server
npm run typecheck   # tsc --noEmit
npx drizzle-kit push  # sync schema to Postgres
```

## Health check

```bash
curl http://localhost:3000/api/health   # {"ok":true}
```
