import { CreatorContact } from "./CreatorContact";
import { ManagementContact } from "./ManagementContact";

/**
 * Bottom-left dock shown on every page:
 *   Option B — college management details / helpline
 *   Option A — creator contact for website issues
 */
export function SupportDock() {
  return (
    <div className="fixed bottom-4 left-3 z-40 flex max-w-[calc(100vw-1.5rem)] flex-col items-start gap-2 sm:bottom-5 sm:left-5">
      <ManagementContact />
      <CreatorContact />
    </div>
  );
}
