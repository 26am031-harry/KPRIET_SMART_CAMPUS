"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { PostStatus, PostType } from "@/db/schema";
import { STATUS_META, statusesForType } from "@/lib/constants";
import { cn } from "@/lib/utils";

export function AdminQuickStatus({ postId, type, status }: { postId: number; type: PostType; status: PostStatus }) {
  const router = useRouter();
  const [current, setCurrent] = useState<PostStatus>(status);
  const [busy, setBusy] = useState(false);
  const options = statusesForType(type);
  // Ensure the current status is selectable even if it's not typical for the type.
  const all = options.includes(current) ? options : [current, ...options];

  return (
    <select
      value={current}
      disabled={busy}
      onChange={async (e) => {
        const next = e.target.value as PostStatus;
        const prev = current;
        setCurrent(next);
        setBusy(true);
        const res = await fetch(`/api/posts/${postId}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status: next }),
        });
        setBusy(false);
        if (!res.ok) {
          setCurrent(prev);
          const data = (await res.json().catch(() => ({}))) as { error?: string };
          alert(data.error ?? "Failed to update");
          return;
        }
        router.refresh();
      }}
      className={cn(
        "rounded-full border-0 py-1 pl-2.5 pr-7 text-xs font-medium ring-1 ring-inset focus:ring-2 focus:ring-indigo-300",
        STATUS_META[current].classes,
      )}
    >
      {all.map((s) => (
        <option key={s} value={s}>
          {STATUS_META[s].label}
        </option>
      ))}
    </select>
  );
}
