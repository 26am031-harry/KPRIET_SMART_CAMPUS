import Image from "next/image";
import { COLLEGE } from "@/lib/college";

// Deterministic particle layout (no Math.random → no hydration mismatch).
const PARTICLES = Array.from({ length: 18 }, (_, i) => ({
  left: `${(i * 53) % 100}%`,
  bottom: `${(i * 17) % 30}%`,
  size: 2 + (i % 4),
  duration: 9 + ((i * 7) % 10),
  delay: -((i * 13) % 18),
  drift: `${((i % 5) - 2) * 18}px`,
}));

/** Animated KPRIET campus photo with cinematic motion and a dark closing vignette. */
export function CampusBackdrop() {
  return (
    <div className="absolute inset-0 -z-10 overflow-hidden bg-slate-950" aria-hidden="true">
      <Image
        src={COLLEGE.campusImage}
        alt=""
        fill
        priority
        sizes="100vw"
        className="kenburns object-cover object-center"
      />
      {/* brand-colour tint */}
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-950/70 via-slate-950/30 to-teal-900/40 mix-blend-multiply" />
      {/* moving light sweep */}
      <div className="light-sweep absolute inset-y-0 left-0 w-1/3 bg-gradient-to-r from-transparent via-white/15 to-transparent" />
      {/* glowing accents */}
      <div className="glow-pulse absolute -left-32 top-10 h-96 w-96 rounded-full bg-indigo-500/30 blur-3xl" />
      <div className="glow-pulse absolute -right-24 bottom-24 h-80 w-80 rounded-full bg-teal-400/20 blur-3xl [animation-delay:-3s]" />
      {/* floating light particles */}
      {PARTICLES.map((p, i) => (
        <span
          key={i}
          className="particle absolute rounded-full bg-white/70 shadow-[0_0_8px_rgba(255,255,255,0.8)]"
          style={{
            left: p.left,
            bottom: p.bottom,
            width: p.size,
            height: p.size,
            animationDuration: `${p.duration}s`,
            animationDelay: `${p.delay}s`,
            ["--drift" as string]: p.drift,
          }}
        />
      ))}
      {/* dark closure vignette */}
      <div className="dark-closure absolute inset-0" />
    </div>
  );
}
