"use client";

import { useState } from "react";
import { CREATOR } from "@/lib/creator";

/** Fixed bottom-left badge on every page so users can report website problems to the creator. */
export function CreatorContact() {
  const [open, setOpen] = useState(false);
  return (
    <aside aria-label="Website creator contact" className="relative">
      {open ? (
        <div className="fade-up w-64 rounded-2xl border border-white/15 bg-[rgb(2_6_23/0.92)] p-4 text-xs text-[#cbd5e1] shadow-2xl shadow-black/50 backdrop-blur-md">
          <div className="flex items-start justify-between gap-2">
            <p className="font-semibold text-[#f8fafc]">Facing an issue with this website?</p>
            <button type="button" onClick={() => setOpen(false)} aria-label="Close creator contact" className="-mr-1 -mt-1 grid h-6 w-6 place-items-center rounded-full text-[#94a3b8] hover:bg-white/10">
              ✕
            </button>
          </div>
          <p className="mt-1 text-[11px] text-[#94a3b8]">Contact the creator of the portal:</p>
          <dl className="mt-3 space-y-1.5">
            <div className="flex gap-2">
              <dt className="w-16 text-[#94a3b8]">Name:</dt>
              <dd className="font-semibold text-[#f8fafc]">{CREATOR.name}</dd>
            </div>
            <div className="flex gap-2">
              <dt className="w-16 text-[#94a3b8]">Contact no:</dt>
              <dd>
                <a href={`tel:${CREATOR.tel}`} className="font-semibold text-[#a5b4fc] hover:underline">{CREATOR.phone}</a>
              </dd>
            </div>
            <div className="flex gap-2">
              <dt className="w-16 text-[#94a3b8]">Email:</dt>
              <dd className="min-w-0">
                <a href={`mailto:${CREATOR.email}`} className="block truncate font-semibold text-[#a5b4fc] hover:underline" title={CREATOR.email}>{CREATOR.email}</a>
              </dd>
            </div>
          </dl>
          <a
            href={`mailto:${CREATOR.email}?subject=${encodeURIComponent("Issue with the KPRIET Smart Campus portal")}&body=${encodeURIComponent("Hi Haarish,\n\nI'd like to report an issue with the KPRIET Smart Campus portal:\n\n")}`}
            className="mt-3 flex items-center justify-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-2 py-1.5 text-center font-semibold text-[#e2e8f0] hover:bg-white/10"
          >
            ✉️ Email the creator
          </a>
          <div className="mt-2 flex gap-2">
            <a href={`tel:${CREATOR.tel}`} className="flex-1 rounded-lg bg-indigo-600 px-2 py-1.5 text-center font-semibold text-white hover:bg-indigo-500">📞 Call</a>
            <a
              href={`https://wa.me/${CREATOR.tel.replace("+", "")}?text=${encodeURIComponent("Hi Haarish, I'd like to report an issue with the KPRIET Smart Campus portal: ")}`}
              target="_blank"
              rel="noreferrer"
              className="flex-1 rounded-lg bg-emerald-600 px-2 py-1.5 text-center font-semibold text-white hover:bg-emerald-500"
            >
              💬 WhatsApp
            </a>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => setOpen(true)}
          aria-expanded={open}
          className="flex items-center gap-2 rounded-full border border-white/15 bg-[rgb(2_6_23/0.85)] py-1.5 pl-1.5 pr-3 text-left text-[11px] leading-tight text-[#cbd5e1] shadow-lg shadow-black/40 backdrop-blur-md transition hover:border-indigo-400/50"
        >
          <span className="grid h-7 w-7 place-items-center rounded-full bg-indigo-600 text-xs text-white" aria-hidden>🛟</span>
          <span>
            <span className="block font-semibold text-[#f8fafc]">Name: {CREATOR.name}</span>
            <span className="block text-[#94a3b8]">Contact no: {CREATOR.phone}</span>
          </span>
          <span className="sr-only">Report a website issue to the creator</span>
        </button>
      )}
    </aside>
  );
}
