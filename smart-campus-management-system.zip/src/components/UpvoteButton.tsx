"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { cn } from "@/lib/utils";

type Props = {
  postId: number;
  initialCount: number;
  initialUpvoted: boolean;
  isAuthed: boolean;
  size?: "sm" | "md";
};

export function UpvoteButton({ postId, initialCount, initialUpvoted, isAuthed, size = "sm" }: Props) {
  const router = useRouter();
  const [count, setCount] = useState(initialCount);
  const [upvoted, setUpvoted] = useState(initialUpvoted);
  const [pending, startTransition] = useTransition();

  async function toggle(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (!isAuthed) {
      router.push(`/login?next=/posts/${postId}`);
      return;
    }
    // optimistic
    const nextUpvoted = !upvoted;
    setUpvoted(nextUpvoted);
    setCount((c) => c + (nextUpvoted ? 1 : -1));
    const res = await fetch(`/api/posts/${postId}/upvote`, { method: "POST" });
    if (res.ok) {
      const data = (await res.json()) as { upvoted: boolean; upvoteCount: number };
      setUpvoted(data.upvoted);
      setCount(data.upvoteCount);
      startTransition(() => router.refresh());
    } else {
      setUpvoted(!nextUpvoted);
      setCount((c) => c - (nextUpvoted ? 1 : -1));
    }
  }

  return (
    <button
      type="button"
      onClick={toggle}
      disabled={pending}
      title={isAuthed ? (upvoted ? "Remove upvote" : "Upvote") : "Sign in to upvote"}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-lg border font-semibold transition",
        size === "sm" ? "px-2.5 py-1 text-xs" : "px-4 py-2 text-sm",
        upvoted
          ? "border-indigo-300 bg-indigo-50 text-indigo-700 hover:bg-indigo-100"
          : "border-slate-200 bg-white text-slate-600 hover:border-indigo-300 hover:text-indigo-700",
      )}
    >
      <svg
        viewBox="0 0 20 20"
        fill="currentColor"
        className={cn(size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4", upvoted && "-translate-y-px")}
        aria-hidden
      >
        <path d="M10 3l6 7h-4v7H8v-7H4l6-7z" />
      </svg>
      {count}
    </button>
  );
}
