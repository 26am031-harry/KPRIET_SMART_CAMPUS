/** Shown on every page when the database cannot be reached. Never crashes the page. */
export function SetupNotice({ message, compact = false }: { message?: string; compact?: boolean }) {
  return (
    <div
      role="status"
      className={`flex ${compact ? "gap-3 px-4 py-3" : "gap-4 px-5 py-4"} rounded-xl border border-amber-300/30 bg-amber-400/10 text-amber-100 shadow-lg shadow-black/20 backdrop-blur`}
    >
      <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className={`${compact ? "h-5 w-5" : "h-7 w-7"} flex-none text-amber-300`}>
        <path d="M3 9a5 5 0 0 1 9.9-1.5A4 4 0 0 1 17 17H7" strokeLinecap="round" />
        <path d="m5 21 14-18" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M12 17v4" strokeLinecap="round" />
      </svg>
      <div className="min-w-0">
        <p className={`${compact ? "text-sm" : "text-base"} font-bold text-amber-200`}>
          Database not available — set up PostgreSQL to start using the portal
        </p>
        <p className="mt-1 text-xs leading-relaxed text-amber-100/85">
          {message ??
            "Create a .env file with DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db, run: npx drizzle-kit push  — then restart the server (or reload this page)."}
        </p>
        <ol className="mt-2 list-decimal space-y-0.5 pl-5 text-[11px] text-amber-100/70">
          <li>Start PostgreSQL on 127.0.0.1:5432</li>
          <li>Create the database: <code className="rounded bg-black/30 px-1">psql -c "CREATE DATABASE app_db"</code></li>
          <li>Create <code className="rounded bg-black/30 px-1">.env</code> with your <code className="rounded bg-black/30 px-1">DATABASE_URL</code></li>
          <li>Create the tables: <code className="rounded bg-black/30 px-1">npx drizzle-kit push</code></li>
        </ol>
      </div>
    </div>
  );
}
