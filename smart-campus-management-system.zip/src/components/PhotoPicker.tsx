"use client";

import { useEffect, useRef, useState } from "react";
import { MAX_PHOTO_BYTES, MAX_SOURCE_PHOTO_BYTES, PHOTO_ACCEPT, PHOTO_MIME_TYPES } from "@/lib/photo-config";

type Props = {
  value: File | null;
  onChange: (file: File | null) => void;
  onProcessingChange: (processing: boolean) => void;
  disabled?: boolean;
  label?: string;
};

function CameraIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true">
      <path d="M8 5 6 8H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-9a2 2 0 0 0-2-2h-2l-2-3H8Z" />
      <circle cx="12" cy="14" r="4" />
    </svg>
  );
}

function toJpeg(canvas: HTMLCanvasElement) {
  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("Could not prepare the photo. Please try again.")), "image/jpeg", 0.85);
  });
}

/** Resize and re-encode before upload, also removing photo metadata such as GPS. */
async function preparePhoto(file: File) {
  if (file.size > MAX_SOURCE_PHOTO_BYTES) throw new Error("Please choose a photo smaller than 15 MB.");
  if (!PHOTO_MIME_TYPES.includes(file.type) && !(file.type === "" && /\.(jpe?g|png|webp)$/i.test(file.name))) {
    throw new Error("Please choose a JPEG, PNG or WebP photo. If your phone uses HEIC, export it as JPEG first.");
  }
  const source = URL.createObjectURL(file);
  try {
    const image = new window.Image();
    image.src = source;
    await image.decode().catch(() => { throw new Error("This photo could not be opened. Please choose another image."); });
    if (!image.naturalWidth || !image.naturalHeight) throw new Error("This photo appears to be empty.");
    const scale = Math.min(1, 1600 / Math.max(image.naturalWidth, image.naturalHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Your browser could not process the photo. Please try another browser.");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    const blob = await toJpeg(canvas);
    if (blob.size > MAX_PHOTO_BYTES) throw new Error("This photo is still too large. Please choose a smaller image.");
    return new File([blob], `${file.name.replace(/\.[^.]+$/, "") || "campus-photo"}.jpg`, { type: "image/jpeg" });
  } finally {
    URL.revokeObjectURL(source);
  }
}

export function PhotoPicker({ value, onChange, onProcessingChange, disabled = false, label = "Photo of the item" }: Props) {
  const fileInput = useRef<HTMLInputElement>(null);
  const nativeCameraInput = useRef<HTMLInputElement>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const cameraRequest = useRef(0);
  const [preview, setPreview] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [cameraReady, setCameraReady] = useState(false);
  const [capturing, setCapturing] = useState(false);

  useEffect(() => {
    if (!value) { setPreview(null); return; }
    const url = URL.createObjectURL(value);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [value]);

  useEffect(() => () => {
    cameraRequest.current += 1;
    streamRef.current?.getTracks().forEach((track) => track.stop());
  }, []);

  function closeCamera() {
    cameraRequest.current += 1;
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    dialogRef.current?.close();
    setCameraReady(false);
  }

  async function selectPhoto(file: File | undefined) {
    if (!file) return;
    setProcessing(true);
    onProcessingChange(true);
    setError(null);
    try {
      onChange(await preparePhoto(file));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load this photo.");
    } finally {
      setProcessing(false);
      onProcessingChange(false);
    }
  }

  async function openCamera() {
    setError(null);
    // Phones get their native rear camera, which also works in embedded previews.
    if (/Android|iPhone|iPad|iPod/i.test(navigator.userAgent) || !navigator.mediaDevices?.getUserMedia) {
      nativeCameraInput.current?.click();
      return;
    }
    setCameraError(null);
    setCameraReady(false);
    dialogRef.current?.showModal();
    const request = ++cameraRequest.current;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: { facingMode: { ideal: "environment" }, width: { ideal: 1600 }, height: { ideal: 1200 } },
      });
      // A camera permission prompt may resolve after the dialog has been closed.
      if (request !== cameraRequest.current || !dialogRef.current?.open) {
        stream.getTracks().forEach((track) => track.stop());
        return;
      }
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
    } catch (err) {
      if (request !== cameraRequest.current) return;
      streamRef.current?.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
      const name = err instanceof DOMException ? err.name : "";
      setCameraError(name === "NotFoundError"
        ? "No camera was found on this device. You can upload a photo instead."
        : "Camera access is not available. Allow camera permission in your browser, open the portal in a new tab, or choose a photo from your device.");
    }
  }

  async function capture() {
    const video = videoRef.current;
    if (!video || !cameraReady || !video.videoWidth) return;
    setCapturing(true);
    const request = cameraRequest.current;
    try {
      const canvas = document.createElement("canvas");
      const scale = Math.min(1, 1600 / Math.max(video.videoWidth, video.videoHeight));
      canvas.width = Math.round(video.videoWidth * scale);
      canvas.height = Math.round(video.videoHeight * scale);
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Could not take a photo. Please try uploading one.");
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const blob = await toJpeg(canvas);
      if (request !== cameraRequest.current) return;
      closeCamera();
      await selectPhoto(new File([blob], "kpriet-item-photo.jpg", { type: "image/jpeg" }));
    } catch (err) {
      setCameraError(err instanceof Error ? err.message : "Could not capture this photo.");
    } finally {
      setCapturing(false);
    }
  }

  const locked = disabled || processing;

  return (
    <fieldset disabled={disabled} className="min-w-0">
      <legend className="mb-1 text-sm font-medium text-slate-700">{label} <span className="font-normal text-slate-400">(optional)</span></legend>
      <p className="mb-3 text-xs text-slate-500">A clear photo helps the KPRIET community identify and return items faster.</p>
      <div className="rounded-xl border-2 border-dashed border-indigo-200 bg-indigo-50/30 p-4">
        {preview && value ? (
          <div className="mb-4 overflow-hidden rounded-lg border border-slate-200 bg-white">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={preview} alt="Preview of the photo attached to your report" className="max-h-64 w-full object-contain" />
            <div className="flex items-center justify-between gap-2 border-t border-slate-100 px-3 py-2">
              <span className="min-w-0 text-xs text-slate-500"><span className="block truncate font-medium text-slate-700">{value.name}</span>{Math.max(1, Math.round(value.size / 1024))} KB · Ready to attach</span>
              <button type="button" disabled={locked} className="rounded-md px-2 py-1 text-xs font-semibold text-rose-600 hover:bg-rose-50 disabled:opacity-50" onClick={() => { onChange(null); setError(null); }}>Remove photo</button>
            </div>
          </div>
        ) : (
          <div className="mb-3 flex items-center gap-3">
            <span className="grid h-11 w-11 flex-none place-items-center rounded-xl border border-indigo-100 bg-white text-indigo-600"><CameraIcon className="h-6 w-6" /></span>
            <div>
              <p className="text-sm font-semibold text-slate-800">Show it, don’t just describe it</p>
              <p className="mt-0.5 text-xs text-slate-500">Take a new photo or choose one you already have.</p>
            </div>
          </div>
        )}
        <div className="flex flex-wrap gap-2">
          <button type="button" disabled={locked} onClick={openCamera} className="btn-primary !py-2"><CameraIcon />{value ? "Retake photo" : "Take photo"}</button>
          <button type="button" disabled={locked} onClick={() => fileInput.current?.click()} className="btn-secondary !py-2">
            <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true"><path d="M12 16V3m-5 5 5-5 5 5M4 15v5a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-5" /></svg>
            {value ? "Choose another" : "Upload photo"}
          </button>
        </div>
        <p className="mt-3 text-[11px] leading-relaxed text-slate-500">JPEG, PNG or WebP · Up to 15 MB before optimization. Photos are resized and location metadata is removed before upload.</p>
        {processing && <p className="mt-2 text-xs font-medium text-indigo-700" role="status">Preparing your photo…</p>}
        {error && <p className="mt-2 text-sm text-rose-600" role="alert">{error}</p>}
      </div>
      <input ref={fileInput} type="file" accept={PHOTO_ACCEPT} aria-label="Upload a report photo" className="hidden" onChange={(e) => { const file = e.target.files?.[0]; e.target.value = ""; void selectPhoto(file); }} />
      <input ref={nativeCameraInput} type="file" accept="image/*" capture="environment" aria-label="Take a photo with your device camera" className="hidden" onChange={(e) => { const file = e.target.files?.[0]; e.target.value = ""; void selectPhoto(file); }} />

      <dialog ref={dialogRef} aria-labelledby="camera-title" className="fixed inset-0 m-auto w-[calc(100%-2rem)] max-w-xl overflow-hidden rounded-2xl border-0 bg-white p-0 text-slate-900 shadow-2xl backdrop:bg-slate-950/70 backdrop:backdrop-blur-sm" onCancel={(e) => { e.preventDefault(); closeCamera(); }}>
        <div className="flex items-center justify-between border-b border-slate-100 p-4">
          <div><h2 id="camera-title" className="font-semibold">Take a photo</h2><p className="text-xs text-slate-500">Position your item clearly in the frame.</p></div>
          <button type="button" aria-label="Exit camera" onClick={closeCamera} className="grid h-8 w-8 place-items-center rounded-full bg-slate-100 text-lg text-slate-600 hover:bg-slate-200">×</button>
        </div>
        <div className="relative aspect-[4/3] bg-slate-950">
          <video ref={videoRef} autoPlay muted playsInline onLoadedData={() => setCameraReady(true)} className="h-full w-full object-contain" aria-label="Live camera preview" />
          {!cameraReady && !cameraError && <div className="absolute inset-0 grid place-items-center p-6 text-center text-sm text-white" role="status">Waiting for camera…<br />Allow camera access when your browser asks.</div>}
          {cameraError && <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-slate-50 p-6 text-center"><CameraIcon className="h-10 w-10 text-slate-400" /><p className="max-w-sm text-sm text-slate-600" role="alert">{cameraError}</p><button type="button" className="btn-secondary" onClick={() => { closeCamera(); fileInput.current?.click(); }}>Choose a photo instead</button><button type="button" className="text-xs font-medium text-indigo-600 hover:underline" onClick={() => { closeCamera(); nativeCameraInput.current?.click(); }}>Open device camera</button></div>}
        </div>
        <div className="flex items-center justify-between gap-3 p-4">
          <button type="button" className="btn-secondary" onClick={closeCamera}>Cancel</button>
          <button type="button" className="btn-primary" disabled={!cameraReady || capturing || !!cameraError} onClick={capture}><CameraIcon />{capturing ? "Capturing…" : "Capture photo"}</button>
        </div>
        <p className="px-4 pb-4 text-[11px] text-slate-400">Camera only—no audio is recorded. The camera turns off when you close this window.</p>
      </dialog>
    </fieldset>
  );
}
