"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { cn, timeAgo } from "@/lib/utils";
import { TYPE_META } from "@/lib/constants";

type Hit = {
  id: number;
  type: "lost" | "found" | "issue";
  title: string;
  description: string;
  category: string;
  location: string;
  status: string;
  upvoteCount: number;
  imageUrl: string | null;
  createdAt: string;
};

const TABS = [
  { value: "", label: "Everything" },
  { value: "lost", label: "🔍 Lost" },
  { value: "found", label: "🎒 Found" },
  { value: "issue", label: "🛠️ Issues" },
];

const SUGGESTIONS = ["headphones", "water bottle", "calculator", "laptop", "wallet", "Wi-Fi", "Gym", "library"];

export function DashboardSearch() {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [q, setQ] = useState("");
  const [type, setType] = useState("");
  const [matches, setMatches] = useState<Hit[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [total, setTotal] = useState<number | null>(null);
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);
  const abort = useRef<AbortController | null>(null);

  const runSearch = useCallback(async (query: string, tab: string) => {
    if (debounce.current) clearTimeout(debounce.current);
    if (!query.trim()) {
      setMatches([]);
      setTotal(null);
      setLoading(false);
      return;
    }
    debounce.current = setTimeout(async () => {
      abort.current?.abort();
      const ctrl = new AbortController();
      abort.current = ctrl;
      setLoading(true);
      try {
        const params = new URLSearchParams({ q: query.trim(), sort: "top", limit: "6" });
        if (tab) params.set("type", tab);
        const res = await fetch(`/api/posts?${params}`, { signal: ctrl.signal });
        const data = (await res.json()) as { posts?: Hit[] };
        setMatches(data.posts ?? []);
        setTotal(data.posts?.length ?? 0);
        setOpen(true);
      } catch {
        /* aborted or network error */
      } finally {
        if (abort.current === ctrl) setLoading(false);
      }
    }, 220);
  }, []);

  useEffect(() => {
    runSearch(q, type);
    return () => {
      if (debounce.current) clearTimeout(debounce.current);
    };
  }, [q, type, runSearch]);

  // Pressing "/" focuses the search box (like most modern apps).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "/" && !/input|textarea|select/i.test((e.target as HTMLElement).tagName)) {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function go() {
    const params = new URLSearchParams();
    if (q.trim()) params.set("q", q.trim());
    if (type) params.set("type", type);
    router.push(`/browse${params.toString() ? `?${params}` : ""}`);
  }

  function chip(term: string) {
    setQ(term);
    setOpen(true);
    inputRef.current?.focus();
  }

  return (
    <div className="relative" role="search" aria-label="Search campus reports">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          go();
        }}
        className="rounded-2xl border border-white/20 bg-slate-950/55 p-3 shadow-2xl shadow-black/40 backdrop-blur-md"
      >
        <div className="flex flex-wrap items-center gap-2">
          <label className="sr-only" htmlFor="dash-search">Search reports</label>
          <svg viewBox="0 0 24 24" className="h-5 w-5 flex-none text-white/70" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <circle cx="11" cy="11" r="7" />
            <path d="m20 20-3.5-3.5" />
          </svg>
          <input
            ref={inputRef}
            id="dash-search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onFocus={() => q.trim() && setOpen(true)}
            onBlur={() => setTimeout(() => setOpen(false), 180)}
            maxLength={200}
            placeholder="Search lost items, found items, maintenance issues, places…"
            className="min-w-0 flex-1 bg-transparent py-2 text-sm text-white placeholder:text-white/45 focus:outline-none sm:text-base"
          />
          <kbd className="hidden rounded-md border border-white/15 bg-white/5 px-2 py-1 text-[10px] font-semibold text-white/60 sm:inline">/</kbd>
          <button type="submit" className="btn-primary !px-4 !py-1.5 !text-xs">
            Search
          </button>
        </div>

        <div className="mt-2 flex flex-wrap items-center gap-2">
          <div className="flex rounded-full border border-white/10 bg-white/5 p-0.5">
            {TABS.map((t) => (
              <button
                key={t.value}
                type="button"
                onClick={() => {
                  setType(t.value);
                  runSearch(q, t.value);
                }}
                aria-pressed={type === t.value}
                className={cn(
                  "rounded-full px-3 py-1 text-[11px] font-semibold transition",
                  type === t.value ? "bg-white text-slate-900" : "text-white/70 hover:text-white",
                )}
              >
                {t.label}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap gap-1.5">
            {SUGGESTIONS.slice(0, 5).map((term) => (
              <button
                key={term}
                type="button"
                onClick={() => chip(term)}
                className="rounded-full border border-white/15 bg-white/5 px-2.5 py-1 text-[11px] text-white/75 transition hover:border-indigo-300/60 hover:bg-white/10 hover:text-white"
              >
                {term}
              </button>
            ))}
          </div>
        </div>
      </form>

      {open && q.trim() && (
        <div className="absolute inset-x-0 bottom-auto z-[45] mt-2 max-h-[22rem] overflow-y-auto rounded-2xl border border-white/15 bg-[rgb(2_6_23/0.96)] p-2 shadow-2xl shadow-black/50 backdrop-blur-md">
          {loading ? (
            <p className="px-4 py-6 text-center text-xs text-white/60">Searching campus reports…</p>
          ) : matches.length === 0 ? (
            <div className="px-4 py-6 text-center text-xs text-white/70">
              <p>No matches for <strong className="text-white">“{q.trim()}”</strong>.</p>
              <p className="mt-1">Try a different word or source, or submit the report yourself.</p>
            </div>
          ) : (
            <>
              <p className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-white/45">
                {total ?? matches.length} match{total === 1 ? "" : "es"} · tap a result to open it
              </p>
              <ul className="space-y-1">
                {matches.map((m) => (
                  <li key={m.id}>
                    <button
                      type="button"
                      onClick={() => router.push(`/posts/${m.id}`)}
                      className="flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-left transition hover:bg-white/10"
                    >
                      {m.imageUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={m.imageUrl} alt="" className="h-12 w-12 flex-none rounded-lg object-cover ring-1 ring-white/20" />
                      ) : (
                        <span className="grid h-12 w-12 flex-none place-items-center rounded-lg bg-white/10 text-lg ring-1 ring-white/10" aria-hidden="true">
                          {TYPE_META[m.type].icon}
                        </span>
                      )}
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-semibold text-white">{highlight(m.title, q)}</span>
                        <span className="mt-0.5 block truncate text-xs text-white/55">
                          {m.location} · {m.category} · {timeAgo(m.createdAt)}
                        </span>
                      </span>
                      <span className="flex-none rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-bold text-indigo-100">
                        {m.type.toUpperCase()}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
              <button
                type="button"
                onClick={go}
                className="mt-2 w-full rounded-xl bg-indigo-600/80 px-3 py-2.5 text-xs font-semibold text-white transition hover:bg-indigo-600"
              >
                See all results in Browse →
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}

function highlight(text: string, q: string) {
  const needle = q.trim().toLowerCase();
  if (!needle) return text;
  const idx = text.toLowerCase().indexOf(needle);
  if (idx === -1) return text;
  return (
    <>
      {text.slice(0, idx)}
      <strong className="font-bold text-[#a5b4fc]">{text.slice(idx, idx + needle.length)}</strong>
      {text.slice(idx + needle.length)}
    </>
  );
}
