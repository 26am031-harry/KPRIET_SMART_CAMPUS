"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import { COLLEGE } from "@/lib/college";

const DEMO_ACCOUNTS = [
  { label: "Student", name: "Priya Sharma", email: "priya@kpriet.ac.in", tone: "bg-slate-100 text-slate-700 hover:bg-slate-200" },
  { label: "Staff", name: "Dr. Lakshmi N.", email: "lakshmi@kpriet.ac.in", tone: "bg-teal-50 text-teal-700 hover:bg-teal-100" },
  { label: "Admin", name: "Campus Admin", email: "admin@kpriet.ac.in", tone: "bg-indigo-50 text-indigo-700 hover:bg-indigo-100" },
];

export function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") || "/";
  const [form, setForm] = useState({ name: "", email: "", password: "", department: "", role: "student" });
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(payload: Record<string, string>, endpoint: string) {
    setBusy(true);
    setError(null);
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    setBusy(false);
    if (!res.ok) {
      setError(data.error ?? "Something went wrong.");
      return;
    }
    router.push(next);
    router.refresh();
  }

  return (
    <div className="mx-auto max-w-md">
      <div className="card p-6 sm:p-8">
        <div className="mb-6 text-center">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/images/kpriet-emblem.png" alt="KPRIET logo" className="mx-auto h-14 w-14 rounded-2xl bg-[#fff] object-contain p-1.5 shadow-lg shadow-black/40" />
          <p className="mt-4 text-[10px] font-bold uppercase tracking-[0.15em] text-indigo-600">KPRIET Smart Campus</p>
          <h1 className="mt-2 text-xl font-bold text-slate-900">
            {mode === "login" ? "Welcome back to KPRIET" : "Join your KPRIET community"}
          </h1>
          <p className="mt-1 text-xs leading-relaxed text-slate-500">{COLLEGE.name}</p>
          <p className="mt-2 text-sm text-slate-500">
            {mode === "login" ? "Sign in to report, upvote and claim." : "For KPRIET students and staff. Use your college email to register."}
          </p>
        </div>

        <form
          className="space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            if (mode === "login") submit({ email: form.email, password: form.password }, "/api/auth/login");
            else submit(form, "/api/auth/register");
          }}
        >
          {mode === "register" && (
            <div>
              <label className="label" htmlFor="name">Full name</label>
              <input id="name" className="input" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
          )}
          <div>
            <label className="label" htmlFor="email">College email</label>
            <input id="email" type="email" className="input" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder={`you@${COLLEGE.emailDomain}`} />
            {mode === "register" && <p className="mt-1.5 text-xs text-slate-500">New accounts require an @{COLLEGE.emailDomain} college email address.</p>}
          </div>
          <div>
            <label className="label" htmlFor="password">Password</label>
            <input id="password" type="password" className="input" required minLength={6} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </div>
          {mode === "register" && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label" htmlFor="department">Department</label>
                <input id="department" className="input" value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} placeholder="e.g. Biology" />
              </div>
              <div>
                <label className="label" htmlFor="role">I am a</label>
                <select id="role" className="input" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
                  <option value="student">Student</option>
                  <option value="staff">Staff</option>
                </select>
              </div>
            </div>
          )}

          {error && <p className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700">{error}</p>}

          <button className="btn-primary w-full" disabled={busy}>
            {busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}
          </button>
        </form>

        <p className="mt-4 text-center text-sm text-slate-500">
          {mode === "login" ? (
            <>
              No account? <Link href={`/register?next=${encodeURIComponent(next)}`} className="font-medium text-indigo-600 hover:underline">Register</Link>
            </>
          ) : (
            <>
              Already registered? <Link href={`/login?next=${encodeURIComponent(next)}`} className="font-medium text-indigo-600 hover:underline">Sign in</Link>
            </>
          )}
        </p>
      </div>

      <div className="card mt-4 p-4">
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">One-click demo login</p>
        <div className="mt-2 grid grid-cols-3 gap-2">
          {DEMO_ACCOUNTS.map((a) => (
            <button
              key={a.email}
              type="button"
              disabled={busy}
              onClick={() => submit({ email: a.email, password: "password123" }, "/api/auth/login")}
              className={`rounded-lg px-3 py-2 text-left text-xs font-medium transition ${a.tone}`}
            >
              <span className="block text-[10px] uppercase tracking-wide opacity-70">{a.label}</span>
              <span className="block truncate">{a.name}</span>
            </button>
          ))}
        </div>
        <p className="mt-2 text-[11px] text-slate-400">All demo accounts use the password <code>password123</code>.</p>
      </div>
    </div>
  );
}
