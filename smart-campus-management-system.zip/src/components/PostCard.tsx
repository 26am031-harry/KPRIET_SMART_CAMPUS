import Link from "next/link";
import type { PostListItem } from "@/lib/posts";
import { PriorityBadge, StatusBadge, TypeBadge } from "./Badges";
import { UpvoteButton } from "./UpvoteButton";
import { TYPE_META, formatClass } from "@/lib/constants";
import { ZoomableImage } from "./ZoomableImage";
import { cn, timeAgo } from "@/lib/utils";

const CATEGORY_ICON: Record<string, string> = {
  Electronics: "🎧", "ID / Cards": "🪪", Keys: "🔑", "Bags & Wallets": "🎒", Clothing: "🧥",
  "Books & Notes": "📚", "Water Bottles": "🧴", "Jewelry & Accessories": "⌚", Other: "📦",
};

export function PostCard({ post, isAuthed }: { post: PostListItem; isAuthed: boolean }) {
  const isItem = post.type !== "issue";
  const cls = formatClass(post);

  return (
    <Link
      href={`/posts/${post.id}`}
      className={cn(
        "card fade-up group flex flex-col overflow-hidden transition hover:-translate-y-0.5 hover:shadow-md",
        !isItem && cn("border-l-4", TYPE_META[post.type].accent),
      )}
    >
      {isItem && (
        <div className="relative aspect-[16/9] overflow-hidden bg-gradient-to-br from-slate-100 to-slate-200">
          {post.imageUrl ? (
            <ZoomableImage
              src={post.imageUrl}
              alt={`Photo of ${post.title}`}
              className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
            />
          ) : (
            <div className="flex h-full flex-col items-center justify-center gap-1 text-slate-400">
              <span className="text-4xl" aria-hidden>{CATEGORY_ICON[post.category] ?? "📦"}</span>
              <span className="text-xs font-medium">No photo provided</span>
            </div>
          )}
          <div className="absolute inset-x-0 top-0 flex items-center gap-1.5 bg-gradient-to-b from-black/50 to-transparent p-2.5">
            <TypeBadge type={post.type} className="!bg-slate-950/80 !text-white !ring-white/20" />
            <StatusBadge status={post.status} className="!bg-slate-950/80 !text-white !ring-white/20" />
          </div>
        </div>
      )}

      <div className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex flex-wrap items-center gap-2">
          {!isItem && (
            <>
              <TypeBadge type={post.type} />
              <StatusBadge status={post.status} />
              {post.priority === "high" && <PriorityBadge priority="high" />}
            </>
          )}
          <span className="rounded bg-slate-100 px-1.5 py-0.5 text-xs text-slate-600">{post.category}</span>
          <span className="ml-auto text-xs text-slate-400">{timeAgo(post.createdAt)}</span>
        </div>

        <div className="min-w-0">
          <h3 className="line-clamp-1 text-base font-semibold text-slate-900 group-hover:text-indigo-700">{post.title}</h3>
          <p className="mt-1 line-clamp-2 text-sm text-slate-600">{post.description}</p>
        </div>

        <div className="mt-auto space-y-2 text-xs text-slate-500">
          <p className="flex items-center gap-1">
            <span aria-hidden>📍</span>
            <span className="font-medium text-slate-700">{post.location}</span>
            {post.locationDetail && <span className="truncate">· {post.locationDetail}</span>}
          </p>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <span>
              👤 {post.reporterName ?? post.authorName}
              {cls && <span className="text-slate-400"> · {cls}</span>}
            </span>
            <span className="ml-auto inline-flex items-center gap-3">
              {post.commentCount > 0 && <span title="Comments">💬 {post.commentCount}</span>}
              {post.pendingClaims > 0 && (
                <span className="rounded bg-violet-50 px-1.5 py-0.5 font-medium text-violet-700">
                  {post.pendingClaims} claim{post.pendingClaims > 1 ? "s" : ""} pending
                </span>
              )}
              <UpvoteButton postId={post.id} initialCount={post.upvoteCount} initialUpvoted={post.viewerUpvoted} isAuthed={isAuthed} />
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}
