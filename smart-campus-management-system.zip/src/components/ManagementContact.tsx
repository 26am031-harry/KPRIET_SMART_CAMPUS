"use client";

import { useState } from "react";
import { COLLEGE, COLLEGE_CONTACTS } from "@/lib/college";

/**
 * Option B of the bottom-left dock: verified college management contacts,
 * enquiries and the helpline — available on every page of the portal.
 */
export function ManagementContact() {
  const [open, setOpen] = useState(false);
  const rows = [
    { ...COLLEGE_CONTACTS.office, icon: "🏢" },
    { ...COLLEGE_CONTACTS.principal, icon: "🎓" },
    { ...COLLEGE_CONTACTS.helpline, icon: "☎️" },
  ];

  return (
    <aside aria-label="College management contacts" className="relative">
      {open ? (
        <div className="fade-up max-h-[min(70dvh,26rem)] w-[min(20rem,calc(100vw-1.5rem))] overflow-y-auto rounded-2xl border border-white/15 bg-[rgb(2_6_23/0.94)] p-4 text-xs text-[#cbd5e1] shadow-2xl shadow-black/50 backdrop-blur-md">
          <div className="flex items-start justify-between gap-2">
            <div>
              <span className="rounded bg-indigo-500/20 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-[#c7d2fe]">Option B</span>
              <p className="mt-1.5 font-semibold text-[#f8fafc]">College management &amp; helpline</p>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Exit college management contacts"
              className="-mr-1 -mt-1 grid h-6 w-6 flex-none place-items-center rounded-full text-[#94a3b8] hover:bg-white/10"
            >
              ✕
            </button>
          </div>

          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/images/kpriet-logo-full.png" alt="KPR Institute of Engineering and Technology logo" className="mt-3 h-8 w-auto rounded bg-[#fff] px-2 py-1" />
          <p className="mt-2 text-[11px] leading-relaxed text-[#94a3b8]">{COLLEGE.address}</p>

          <ul className="mt-3 space-y-2">
            {rows.map((c) => (
              <li key={c.label} className="rounded-lg border border-white/10 bg-white/5 p-2">
                <p className="text-[11px] font-semibold text-[#e2e8f0]">
                  <span aria-hidden>{c.icon}</span> {c.label}
                </p>
                <a href={`tel:${c.tel}`} className="mt-0.5 block text-[11px] font-medium text-[#a5b4fc] hover:underline">
                  📞 {c.phone}
                </a>
                <a href={`mailto:${c.email}`} className="block break-all text-[11px] text-[#a5b4fc] hover:underline">
                  ✉️ {c.email}
                </a>
              </li>
            ))}
          </ul>

          <p className="mt-3 rounded-lg bg-white/5 px-2.5 py-2 text-[10px] leading-relaxed text-[#94a3b8]">
            <strong className="text-[#cbd5e1]">Office hours:</strong> {COLLEGE_CONTACTS.hours} · Fax {COLLEGE_CONTACTS.fax}.
            <br />
            No action on a submitted report? Escalate it to the {COLLEGE_CONTACTS.ceoOffice.label} from the report page after the portal verifies it.
          </p>

          <div className="mt-3 flex gap-2">
            <a href={`tel:${COLLEGE_CONTACTS.office.tel}`} className="flex-1 rounded-lg bg-indigo-600 px-2 py-1.5 text-center font-semibold text-white hover:bg-indigo-500">
              📞 Call office
            </a>
            <a href={`mailto:${COLLEGE_CONTACTS.office.email}`} className="flex-1 rounded-lg border border-white/15 bg-white/5 px-2 py-1.5 text-center font-semibold text-[#e2e8f0] hover:bg-white/10">
              ✉️ Email
            </a>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => setOpen(true)}
          aria-expanded={open}
          className="flex items-center gap-2 rounded-full border border-white/15 bg-[rgb(2_6_23/0.85)] py-1.5 pl-1.5 pr-3 text-left text-[11px] leading-tight text-[#cbd5e1] shadow-lg shadow-black/40 backdrop-blur-md transition hover:border-teal-400/50"
        >
          <span className="grid h-7 w-7 flex-none place-items-center rounded-full bg-teal-600 text-xs text-white" aria-hidden>🏛️</span>
          <span className="min-w-0">
            <span className="block font-semibold text-[#f8fafc]">College management · Option B</span>
            <span className="block truncate text-[#94a3b8]">Enquiries &amp; helpline · {COLLEGE_CONTACTS.office.phone}</span>
          </span>
        </button>
      )}
    </aside>
  );
}
