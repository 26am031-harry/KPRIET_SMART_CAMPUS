"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { PostStatus, PostType, Priority } from "@/db/schema";
import { STATUS_META, statusesForType } from "@/lib/constants";
import { cn } from "@/lib/utils";

async function api(url: string, method: string, body?: unknown) {
  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = (await res.json().catch(() => ({}))) as { error?: string };
  if (!res.ok) throw new Error(data.error ?? "Request failed");
  return data;
}

/* ---------------- Claim form ---------------- */
export function ClaimForm({ postId, type }: { postId: number; type: PostType }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  if (done) {
    return (
      <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-800">
        ✅ Claim submitted! An admin will review it and update the status.
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-violet-200 bg-violet-50 p-4">
      <p className="text-sm font-semibold text-violet-900">
        {type === "found" ? "Is this yours?" : "Did you find this item?"}
      </p>
      <p className="text-xs text-violet-700">
        {type === "found"
          ? "Submit a claim with details only the owner would know. An admin will verify it."
          : "Let the owner know you have it. An admin will coordinate the hand-off."}
      </p>
      {!open ? (
        <button type="button" onClick={() => setOpen(true)} className="btn-primary mt-3 !bg-violet-600 hover:!bg-violet-500">
          {type === "found" ? "Claim this item" : "I found this"}
        </button>
      ) : (
        <form
          className="mt-3 space-y-2"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            setError(null);
            try {
              await api(`/api/posts/${postId}/claims`, "POST", { message });
              setDone(true);
              router.refresh();
            } catch (err) {
              setError((err as Error).message);
            } finally {
              setBusy(false);
            }
          }}
        >
          <textarea
            className="input min-h-[90px]"
            required
            minLength={10}
            placeholder="Describe identifying details (stickers, scratches, contents, lock-screen photo…)"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          />
          {error && <p className="text-sm text-rose-600">{error}</p>}
          <div className="flex gap-2">
            <button className="btn-primary !bg-violet-600 hover:!bg-violet-500" disabled={busy}>
              {busy ? "Sending…" : "Submit claim"}
            </button>
            <button type="button" className="btn-secondary" onClick={() => setOpen(false)}>
              Cancel
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

/* ---------------- Comment form ---------------- */
export function CommentForm({ postId, isAdmin }: { postId: number; isAdmin: boolean }) {
  const router = useRouter();
  const [body, setBody] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <form
      className="space-y-2"
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        setError(null);
        try {
          await api(`/api/posts/${postId}/comments`, "POST", { body });
          setBody("");
          router.refresh();
        } catch (err) {
          setError((err as Error).message);
        } finally {
          setBusy(false);
        }
      }}
    >
      <textarea
        className="input min-h-[80px]"
        placeholder={isAdmin ? "Post an official update…" : "Add a comment or helpful tip…"}
        value={body}
        onChange={(e) => setBody(e.target.value)}
        required
      />
      {error && <p className="text-sm text-rose-600">{error}</p>}
      <div className="flex justify-end">
        <button className="btn-primary" disabled={busy}>
          {busy ? "Posting…" : isAdmin ? "Post official update" : "Post comment"}
        </button>
      </div>
    </form>
  );
}

/* ---------------- Admin panel ---------------- */
export function AdminPanel({
  postId,
  type,
  status,
  priority,
  adminNote,
}: {
  postId: number;
  type: PostType;
  status: PostStatus;
  priority: Priority;
  adminNote: string | null;
}) {
  const router = useRouter();
  const [nextStatus, setNextStatus] = useState<PostStatus>(status);
  const [nextPriority, setNextPriority] = useState<Priority>(priority);
  const [note, setNote] = useState(adminNote ?? "");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function save() {
    setBusy(true);
    setMsg(null);
    try {
      await api(`/api/posts/${postId}`, "PATCH", { status: nextStatus, priority: nextPriority, adminNote: note });
      setMsg({ ok: true, text: "Saved. Reporter and followers will see the update." });
      router.refresh();
    } catch (err) {
      setMsg({ ok: false, text: (err as Error).message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-xl border border-indigo-200 bg-gradient-to-b from-indigo-50 to-transparent p-4">
      <div className="flex items-center gap-2">
        <span className="rounded-md bg-indigo-600 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">Admin</span>
        <p className="text-sm font-semibold text-slate-900">Manage this report</p>
      </div>

      <div className="mt-3">
        <p className="label">Status</p>
        <div className="flex flex-wrap gap-1.5">
          {statusesForType(type).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setNextStatus(s)}
              className={cn(
                "rounded-full border px-2.5 py-1 text-xs font-medium transition",
                nextStatus === s ? cn(STATUS_META[s].classes, "ring-2") : "border-slate-200 bg-white text-slate-600 hover:border-slate-300",
              )}
            >
              {STATUS_META[s].label}
            </button>
          ))}
        </div>
      </div>

      {type === "issue" && (
        <div className="mt-3">
          <p className="label">Priority</p>
          <div className="flex gap-1.5">
            {(["low", "medium", "high"] as const).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setNextPriority(p)}
                className={cn(
                  "flex-1 rounded-lg border px-2 py-1 text-xs font-medium capitalize",
                  nextPriority === p ? "border-indigo-400 bg-indigo-100 text-indigo-800" : "border-slate-200 bg-white text-slate-600",
                )}
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="mt-3">
        <label className="label" htmlFor="adminNote">Public admin note</label>
        <textarea
          id="adminNote"
          className="input min-h-[70px]"
          placeholder="e.g. Work order created, technician visiting Thursday."
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
      </div>

      {msg && (
        <p className={cn("mt-2 text-xs", msg.ok ? "text-emerald-700" : "text-rose-600")}>{msg.text}</p>
      )}

      <button type="button" onClick={save} disabled={busy} className="btn-primary mt-3 w-full">
        {busy ? "Saving…" : "Save update"}
      </button>
    </div>
  );
}

/* ---------------- Claim review (admin) ---------------- */
export function ClaimReviewButtons({ claimId }: { claimId: number }) {
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);
  async function act(status: "approved" | "rejected") {
    setBusy(status);
    try {
      await api(`/api/claims/${claimId}`, "PATCH", { status });
      router.refresh();
    } catch (err) {
      alert((err as Error).message);
    } finally {
      setBusy(null);
    }
  }
  return (
    <div className="flex gap-2">
      <button type="button" className="btn-success !px-3 !py-1 !text-xs" disabled={!!busy} onClick={() => act("approved")}>
        {busy === "approved" ? "…" : "Approve"}
      </button>
      <button type="button" className="btn-danger !px-3 !py-1 !text-xs" disabled={!!busy} onClick={() => act("rejected")}>
        {busy === "rejected" ? "…" : "Reject"}
      </button>
    </div>
  );
}

/* ---------------- Delete ---------------- */
export function DeletePostButton({ postId }: { postId: number }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  return (
    <button
      type="button"
      disabled={busy}
      className="text-xs font-medium text-rose-600 hover:underline disabled:opacity-50"
      onClick={async () => {
        if (!confirm("Delete this report? This cannot be undone.")) return;
        setBusy(true);
        try {
          await api(`/api/posts/${postId}`, "DELETE");
          router.push("/browse");
          router.refresh();
        } catch (err) {
          alert((err as Error).message);
          setBusy(false);
        }
      }}
    >
      Delete report
    </button>
  );
}
