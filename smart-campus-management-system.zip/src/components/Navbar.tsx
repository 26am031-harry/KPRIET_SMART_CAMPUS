import Image from "next/image";
import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { initials } from "@/lib/utils";
import { RoleBadge } from "./Badges";
import { SignOutButton } from "./SignOutButton";

export async function Navbar() {
  const user = await getCurrentUser();

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-slate-950/75 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6">
        <Link href="/" aria-label="KPRIET Smart Campus dashboard" className="flex flex-none items-center gap-2.5">
          <span className="grid h-10 w-10 flex-none place-items-center rounded-xl bg-[#fff] p-1 shadow-md shadow-black/40 ring-1 ring-white/20">
            <Image src="/images/kpriet-emblem.png" alt="KPRIET logo" width={34} height={34} priority className="h-full w-full object-contain" />
          </span>
          <span className="hidden flex-col leading-tight min-[420px]:flex">
            <span className="text-sm font-bold tracking-tight text-slate-900">KPRIET <span className="hidden font-medium text-indigo-600 sm:inline">Smart Campus</span></span>
            <span className="mt-0.5 hidden text-[10px] font-medium text-slate-500 sm:inline">Issues & Lost-and-Found</span>
          </span>
        </Link>

        <nav aria-label="Main navigation" className="ml-2 hidden items-center gap-0.5 xl:flex">
          <NavLink href="/">Dashboard</NavLink>
          <NavLink href="/browse">Browse</NavLink>
          <NavLink href="/browse?type=lost">Lost</NavLink>
          <NavLink href="/browse?type=found">Found</NavLink>
          <NavLink href="/browse?type=issue">Issues</NavLink>
          {user && <NavLink href="/my">My Activity</NavLink>}
          {user?.role === "admin" && (
            <NavLink href="/admin"><span className="inline-flex items-center gap-1.5">Admin<span className="h-1.5 w-1.5 rounded-full bg-indigo-500" /></span></NavLink>
          )}
        </nav>

        <div className="ml-auto flex flex-none items-center gap-2">
          <Link href="/submit" className="btn-primary !px-3 !py-1.5" aria-label="Submit a report">
            <span className="text-base leading-none">+</span><span className="hidden sm:inline">Report</span>
          </Link>
          {user ? (
            <div className="flex items-center gap-2 rounded-full border border-slate-200 bg-white py-1 pl-1 pr-2">
              <span className="grid h-7 w-7 place-items-center rounded-full bg-indigo-100 text-xs font-bold text-indigo-700">{initials(user.name)}</span>
              <span className="hidden text-sm font-medium text-slate-700 sm:inline">{user.name.split(" ")[0]}</span>
              <RoleBadge role={user.role} />
              <SignOutButton />
            </div>
          ) : <Link href="/login" className="btn-secondary !px-3 !py-1.5">Sign in</Link>}
        </div>
      </div>
      <nav aria-label="Campus navigation" className="flex gap-1 overflow-x-auto border-t border-slate-100 px-3 py-1.5 xl:hidden">
        <NavLink href="/">Dashboard</NavLink>
        <NavLink href="/browse">Browse</NavLink>
        <NavLink href="/browse?type=lost">Lost</NavLink>
        <NavLink href="/browse?type=found">Found</NavLink>
        <NavLink href="/browse?type=issue">Issues</NavLink>
        {user && <NavLink href="/my">My Activity</NavLink>}
        {user?.role === "admin" && <NavLink href="/admin">Admin</NavLink>}
      </nav>
    </header>
  );
}

function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return <Link href={href} className="whitespace-nowrap rounded-lg px-3 py-1.5 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900">{children}</Link>;
}
