"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { COLLEGE_CONTACTS } from "@/lib/college";
import { cn, formatDate } from "@/lib/utils";

export type EscalationRow = {
  id: number;
  reference: string;
  postId: number;
  postTitle: string;
  postType: "lost" | "found" | "issue";
  location: string;
  postStatus: string;
  status: "submitted" | "acknowledged" | "closed";
  reason: string;
  waitingDays: number;
  upvoteCount: number;
  requesterName: string;
  createdAt: string;
  handledAt: string | null;
  handledNote: string | null;
};

const STYLE: Record<EscalationRow["status"], string> = {
  submitted: "border-rose-400/40 bg-rose-500/10",
  acknowledged: "border-amber-400/40 bg-amber-500/10",
  closed: "border-emerald-400/40 bg-emerald-500/10",
};

export function EscalationQueue({ escalations }: { escalations: EscalationRow[] }) {
  const router = useRouter();
  const [noteFor, setNoteFor] = useState<number | null>(null);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const open = escalations.filter((e) => e.status !== "closed");

  async function act(id: number, status: "acknowledged" | "closed") {
    setBusy(`${id}-${status}`);
    const res = await fetch(`/api/escalations/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status, note }),
    });
    setBusy(null);
    if (!res.ok) {
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      alert(data.error ?? "Could not update this escalation.");
      return;
    }
    setNote("");
    setNoteFor(null);
    router.refresh();
  }

  return (
    <section aria-label="CEO's Office escalations" className="card overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-5 py-4">
        <div>
          <h2 className="font-semibold text-slate-900">
            🏛️ CEO&apos;s Office escalations{" "}
            <span className="text-slate-400">({open.length} open · {escalations.length} total)</span>
          </h2>
          <p className="mt-0.5 text-xs text-slate-500">
            Reports verified as having no action, escalated by students. Route: {COLLEGE_CONTACTS.ceoOffice.label} · {COLLEGE_CONTACTS.ceoOffice.phone}
          </p>
        </div>
      </div>

      {escalations.length === 0 ? (
        <p className="p-5 text-sm text-slate-500">
          No escalations yet. Students can escalate a report only after it stays without action for the waiting period.
        </p>
      ) : (
        <ul className="divide-y divide-white/10">
          {escalations.map((e) => (
            <li key={e.id} className={cn("p-5", STYLE[e.status])}>
              <div className="flex flex-col gap-3 lg:flex-row lg:items-start">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded-md bg-white/10 px-2 py-0.5 font-mono text-xs font-bold text-slate-900">{e.reference}</span>
                    <span
                      className={cn(
                        "rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ring-1",
                        e.status === "submitted" ? "bg-rose-500/20 text-rose-200 ring-rose-400/40" : e.status === "acknowledged" ? "bg-amber-500/20 text-amber-200 ring-amber-400/40" : "bg-emerald-500/20 text-emerald-200 ring-emerald-400/40",
                      )}
                    >
                      {e.status}
                    </span>
                    <Link href={`/posts/${e.postId}`} className="text-sm font-semibold text-slate-900 hover:underline">
                      {e.postTitle}
                    </Link>
                  </div>
                  <p className="mt-1.5 text-xs text-slate-500">
                    {e.location} · {e.postType} · escalated by {e.requesterName} on {formatDate(e.createdAt)} · waited {e.waitingDays} day(s) · ▲ {e.upvoteCount} · report status: {e.postStatus.replace("_", " ")}
                  </p>
                  <p className="mt-2 rounded-lg bg-black/25 px-3 py-2 text-xs italic text-slate-300">“{e.reason}”</p>
                  {e.handledNote && (
                    <p className="mt-2 text-xs text-slate-400">
                      <strong className="text-slate-300">Office note:</strong> {e.handledNote} {e.handledAt ? `· ${formatDate(e.handledAt)}` : ""}
                    </p>
                  )}
                </div>

                <div className="flex w-full flex-none flex-col gap-2 lg:w-64">
                  {e.status !== "closed" && (
                    <>
                      {noteFor === e.id ? (
                        <textarea
                          aria-label={`Note for escalation ${e.reference}`}
                          className="input min-h-[70px] !text-xs"
                          placeholder="Action taken / advice to the student…"
                          value={note}
                          onChange={(ev) => setNote(ev.target.value)}
                        />
                      ) : (
                        <button type="button" className="btn-secondary !px-3 !py-1.5 !text-xs" onClick={() => { setNoteFor(e.id); setNote(e.handledNote ?? ""); }}>
                          ✍️ Add office note
                        </button>
                      )}
                      <div className="flex gap-2">
                        <button type="button" disabled={!!busy} onClick={() => act(e.id, "acknowledged")} className="btn-primary flex-1 !px-2 !py-1.5 !text-xs">
                          {busy === `${e.id}-acknowledged` ? "…" : "Acknowledge"}
                        </button>
                        <button type="button" disabled={!!busy} onClick={() => act(e.id, "closed")} className="btn-success flex-1 !px-2 !py-1.5 !text-xs">
                          {busy === `${e.id}-closed` ? "…" : "Mark resolved"}
                        </button>
                      </div>
                      <Link href={`/posts/${e.postId}`} className="text-center text-[11px] font-medium text-indigo-300 hover:underline">
                        Open report & change status →
                      </Link>
                    </>
                  )}
                  {e.status === "closed" && (
                    <p className="text-center text-[11px] text-emerald-200/80">Closed · no further action needed</p>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
