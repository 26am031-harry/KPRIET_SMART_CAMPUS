"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

const MIN_SCALE = 1;
const MAX_SCALE = 5;
const DOUBLE_TAP_MS = 320;
const DOUBLE_TAP_MOVE = 40;

type Props = {
  src: string;
  alt: string;
  className?: string;
};

/**
 * Image with double-tap / double-click zoom.
 * Single tap opens the fullscreen viewer; a second quick tap zooms in/out
 * (works on touch and with a mouse). In the viewer: wheel/pinch/buttons zoom,
 * drag to pan, double-click toggles zoom, exit arrow or Esc closes.
 */
export function ZoomableImage({ src, alt, className }: Props) {
  const [viewerOpen, setViewerOpen] = useState(false);
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [zoomHint, setZoomHint] = useState<string | null>(null);
  const lastTap = useRef<{ t: number; x: number; y: number } | null>(null);
  const tapTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const drag = useRef<{ x: number; y: number; ox: number; oy: number } | null>(null);
  const [dragging, setDragging] = useState(false);
  const imgRef = useRef<HTMLImageElement>(null);

  const reset = useCallback(() => {
    setScale(1);
    setOffset({ x: 0, y: 0 });
  }, []);

  const close = useCallback(() => {
    setViewerOpen(false);
    reset();
  }, [reset]);

  const openViewer = useCallback((zoomed: boolean) => {
    setScale(zoomed ? 2.5 : 1);
    setOffset({ x: 0, y: 0 });
    setViewerOpen(true);
    setZoomHint(zoomed ? "Zoomed in — double-tap to zoom out" : "Double-tap the picture to zoom in");
  }, []);

  /** Handles single vs double tap for both touch and mouse. */
  const handleTap = useCallback(
    (clientX: number, clientY: number, inViewer: boolean) => {
      const now = Date.now();
      const prev = lastTap.current;
      const isDouble = !!prev && now - prev.t < DOUBLE_TAP_MS && Math.hypot(clientX - prev.x, clientY - prev.y) < DOUBLE_TAP_MOVE;
      lastTap.current = { t: now, x: clientX, y: clientY };

      if (tapTimer.current) clearTimeout(tapTimer.current);

      if (isDouble) {
        lastTap.current = null;
        if (!inViewer) {
          openViewer(true); // double-tap a thumbnail → open already zoomed
          return;
        }
        setScale((s) => {
          const next = s > MIN_SCALE ? MIN_SCALE : 2.5;
          if (next === MIN_SCALE) setOffset({ x: 0, y: 0 });
          setZoomHint(next === MIN_SCALE ? "Zoomed out" : "Zoomed in");
          return next;
        });
        return;
      }

      // Wait to see whether a second tap follows before treating it as a single tap.
      tapTimer.current = setTimeout(() => {
        if (!inViewer) openViewer(false);
      }, DOUBLE_TAP_MS);
    },
    [openViewer],
  );

  useEffect(() => {
    if (!viewerOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "+" || e.key === "=") setScale((s) => Math.min(MAX_SCALE, s + 0.5));
      if (e.key === "-") setScale((s) => Math.max(MIN_SCALE, s - 0.5));
      if (e.key === "0") reset();
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [viewerOpen, close, reset]);

  useEffect(() => {
    if (!zoomHint) return;
    const t = setTimeout(() => setZoomHint(null), 1800);
    return () => clearTimeout(t);
  }, [zoomHint]);

  function onWheel(e: React.WheelEvent) {
    if (!viewerOpen) return;
    e.preventDefault();
    setScale((s) => Math.min(MAX_SCALE, Math.max(MIN_SCALE, s - e.deltaY * 0.002)));
  }

  function startDrag(e: React.PointerEvent) {
    if (!viewerOpen || scale <= 1) return;
    drag.current = { x: e.clientX, y: e.clientY, ox: offset.x, oy: offset.y };
    setDragging(true);
    (e.target as Element).setPointerCapture?.(e.pointerId);
  }

  function moveDrag(e: React.PointerEvent) {
    if (!drag.current) return;
    setOffset({ x: drag.current.ox + (e.clientX - drag.current.x), y: drag.current.oy + (e.clientY - drag.current.y) });
  }

  function endDrag() {
    drag.current = null;
    setDragging(false);
  }

  return (
    <>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={src}
        alt={alt}
        loading="lazy"
        className={cn("cursor-zoom-in touch-manipulation select-none", className)}
        title="Tap to open · double-tap to zoom"
        onClick={(e) => {
          // Inside a card link: open the viewer instead of navigating.
          e.preventDefault();
          e.stopPropagation();
          handleTap(e.clientX, e.clientY, false);
        }}
        onDoubleClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
        }}
        onTouchEnd={(e) => e.stopPropagation()}
      />

      {viewerOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={`Zoomable view of ${alt}`}
          className="fade-up fixed inset-0 z-[70] flex flex-col bg-black/95 backdrop-blur-sm"
          onClick={(e) => {
            if (e.target === e.currentTarget) close();
          }}
        >
          <header className="flex items-center gap-3 border-b border-white/10 px-4 py-3 text-white">
            <button
              type="button"
              onClick={close}
              aria-label="Exit image viewer"
              className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 text-xs font-semibold hover:bg-white/20"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M19 12H5" />
                <path d="m11 18-6-6 6-6" />
              </svg>
              Exit
            </button>
            <p className="min-w-0 flex-1 truncate text-xs text-white/70">{alt}</p>
            <div className="flex items-center gap-1.5">
              <ZoomButton label="Zoom out" onClick={() => setScale((s) => Math.max(MIN_SCALE, s - 0.5))} disabled={scale <= MIN_SCALE}>−</ZoomButton>
              <span className="w-14 text-center text-xs font-semibold tabular-nums text-white/80">{scale.toFixed(1)}×</span>
              <ZoomButton label="Zoom in" onClick={() => setScale((s) => Math.min(MAX_SCALE, s + 0.5))} disabled={scale >= MAX_SCALE}>+</ZoomButton>
              <ZoomButton label="Reset zoom" onClick={reset} disabled={scale === MIN_SCALE}>⤾</ZoomButton>
            </div>
          </header>

          <div
            className="relative flex-1 touch-none overflow-hidden"
            onPointerDown={startDrag}
            onPointerMove={moveDrag}
            onPointerUp={endDrag}
            onPointerCancel={endDrag}
            onWheel={onWheel}
            onClick={(e) => handleTap(e.clientX, e.clientY, true)}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              ref={imgRef}
              src={src}
              alt={alt}
              draggable={false}
              className={cn(
                "pointer-events-none absolute left-1/2 top-1/2 max-h-[85vh] max-w-[92vw] select-none object-contain transition-transform duration-200 ease-out",
                dragging && "!duration-0",
                scale > 1 ? (dragging ? "cursor-grabbing" : "cursor-grab") : "cursor-zoom-in",
              )}
              style={{ transform: `translate(-50%, -50%) translate(${offset.x}px, ${offset.y}px) scale(${scale})` }}
            />
            {zoomHint && (
              <p className="pointer-events-none absolute bottom-6 left-1/2 -translate-x-1/2 rounded-full bg-white/15 px-4 py-1.5 text-xs font-medium text-white backdrop-blur">
                {zoomHint}
              </p>
            )}
          </div>

          <p className="px-4 py-2 text-center text-[11px] text-white/50">
            Double-tap the picture to zoom in and out · scroll or pinch to zoom · drag to move · Esc to exit
          </p>
        </div>
      )}
    </>
  );
}

function ZoomButton({ children, onClick, label, disabled }: { children: React.ReactNode; onClick: () => void; label: string; disabled?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-label={label}
      className="grid h-8 w-8 place-items-center rounded-full bg-white/10 text-sm font-bold text-white transition hover:bg-white/20 disabled:opacity-40"
    >
      {children}
    </button>
  );
}
