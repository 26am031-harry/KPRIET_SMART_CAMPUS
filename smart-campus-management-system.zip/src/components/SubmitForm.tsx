"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { PostType } from "@/db/schema";
import { DEPARTMENTS, LOCATION_GROUPS, POST_TYPES, REPORTER_YEARS, SECTIONS, categoriesForType } from "@/lib/constants";
import { cn } from "@/lib/utils";
import { PhotoPicker } from "@/components/PhotoPicker";

type Reporter = { name: string; email: string; department: string | null };

type Pin = { lat: string; lng: string; accuracy: string } | null;

/** Opt-in: attach the reporter's current GPS position so others can track the spot. */
function GpsPin({ lat, lng, accuracy, onChange, disabled }: { lat: string; lng: string; accuracy: string; onChange: (p: Pin) => void; disabled?: boolean }) {
  const [state, setState] = useState<"idle" | "locating" | "error">("idle");
  const [msg, setMsg] = useState<string | null>(null);

  function pin() {
    if (!("geolocation" in navigator)) {
      setState("error");
      setMsg("Location isn't available in this browser.");
      return;
    }
    setState("locating");
    setMsg(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setState("idle");
        onChange({ lat: pos.coords.latitude.toFixed(6), lng: pos.coords.longitude.toFixed(6), accuracy: String(Math.round(pos.coords.accuracy)) });
      },
      (err) => {
        setState("error");
        setMsg(
          err.code === err.PERMISSION_DENIED
            ? "Location permission was denied. Allow location for this site (or open the portal in a new tab) to pin the spot."
            : "Couldn't get your location. Move to an open area and try again.",
        );
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 },
    );
  }

  if (lat && lng) {
    return (
      <div className="mt-2 flex items-center justify-between gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-800">
        <span>📍 GPS pinned ({lat}, {lng}) · ±{accuracy || "?"} m</span>
        <button type="button" disabled={disabled} onClick={() => onChange(null)} className="font-semibold text-rose-600 hover:underline">Remove</button>
      </div>
    );
  }
  return (
    <div className="mt-2">
      <button type="button" disabled={disabled || state === "locating"} onClick={pin} className="btn-secondary w-full !py-1.5 !text-xs">
        {state === "locating" ? "Getting your location…" : "📍 Pin my current location (optional)"}
      </button>
      <p className="mt-1 text-[11px] text-slate-400">Pin it while standing at the spot so others can track it. Only this one position is saved — you are not tracked.</p>
      {msg && <p className="mt-1 text-[11px] text-rose-600" role="alert">{msg}</p>}
    </div>
  );
}

export function SubmitForm({ initialType, reporter }: { initialType: PostType; reporter: Reporter }) {
  const router = useRouter();
  const [type, setType] = useState<PostType>(initialType);
  const [form, setForm] = useState({
    title: "",
    description: "",
    category: "",
    location: "",
    locationDetail: "",
    reporterName: reporter.name,
    reporterPhone: "",
    reporterEmail: reporter.email,
    reporterYear: "",
    reporterDepartment: reporter.department && DEPARTMENTS.includes(reporter.department) ? reporter.department : "",
    reporterSection: "",
    reportLat: "",
    reportLng: "",
    reportAccuracy: "",
    priority: "medium",
    imageUrl: "",
    contactInfo: "",
    occurredAt: "",
  });
  const [photo, setPhoto] = useState<File | null>(null);
  const [photoProcessing, setPhotoProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const categories = categoriesForType(type);
  const isIssue = type === "issue";

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (photoProcessing || busy) return;
    setBusy(true);
    setError(null);
    try {
      const payload = new FormData();
      for (const [key, value] of Object.entries({ ...form, type })) payload.set(key, value);
      if (photo) payload.set("photo", photo);
      // Let the browser set the multipart boundary; the photo and report are saved together.
      const res = await fetch("/api/posts", { method: "POST", body: payload });
      const data = (await res.json().catch(() => ({}))) as { error?: string; post?: { id: number } };
      if (!res.ok || !data.post) throw new Error(data.error ?? "Could not submit. Please try again.");
      router.push(`/posts/${data.post.id}`);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "We couldn’t submit your report. Please check your connection and try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-6">
      <fieldset disabled={busy} className="grid min-w-0 gap-3 sm:grid-cols-3">
        <legend className="sr-only">Report type</legend>
        {POST_TYPES.map((t) => (
          <button
            key={t.value}
            type="button"
            aria-pressed={type === t.value}
            onClick={() => { setType(t.value); setForm((f) => ({ ...f, category: "" })); }}
            className={cn("flex items-center gap-3 rounded-xl border-2 p-4 text-left transition", type === t.value ? "border-indigo-500 bg-indigo-50 shadow-sm" : "border-slate-200 bg-white hover:border-slate-300")}
          >
            <span className="text-2xl">{t.icon}</span>
            <span><span className="block text-sm font-semibold text-slate-900">{t.label}</span><span className="block text-xs text-slate-500">{t.blurb}</span></span>
          </button>
        ))}
      </fieldset>

      <div className="card space-y-5 p-5 sm:p-6">
        <div>
          <label className="label" htmlFor="title">{isIssue ? "What's the problem?" : type === "lost" ? "What did you lose?" : "What did you find?"}</label>
          <input id="title" className="input" required minLength={4} maxLength={160} disabled={busy} placeholder={isIssue ? "e.g. Broken projector in a lecture hall" : "e.g. Black Sony headphones with a cat sticker"} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        </div>

        <PhotoPicker
          value={photo}
          onChange={(nextPhoto) => { setPhoto(nextPhoto); if (nextPhoto) setForm((f) => ({ ...f, imageUrl: "" })); }}
          onProcessingChange={setPhotoProcessing}
          disabled={busy}
          label={isIssue ? "Photo of the issue" : "Photo of the item"}
        />

        {!photo && (
          <details className="rounded-lg border border-slate-200 px-3 py-2">
            <summary className="cursor-pointer text-xs font-medium text-slate-500 hover:text-indigo-600">Use a photo link instead</summary>
            <label className="label mt-3" htmlFor="imageUrl">Photo URL</label>
            <input id="imageUrl" type="url" className="input" placeholder="https://…" disabled={busy} value={form.imageUrl} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} />
          </details>
        )}

        <div>
          <label className="label" htmlFor="description">Description</label>
          <textarea
            id="description" className="input min-h-[120px]" required minLength={10} maxLength={10000} disabled={busy}
            placeholder={isIssue ? "Describe the issue, when it started, and how it affects people." : "Describe the item: color, brand, distinguishing marks, when and where. For found items, leave out one detail so claimants can verify."}
            value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
          />
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="category">Category</label>
            <select id="category" className="input" required disabled={busy} value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              <option value="" disabled>Select a category…</option>
              {categories.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="location">KPRIET campus location</label>
            <select id="location" className="input" required disabled={busy} value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })}>
              <option value="" disabled>Select a campus location…</option>
              {LOCATION_GROUPS.map((g) => (
                <optgroup key={g.label} label={`${g.icon} ${g.label}`}>
                  {g.locations.map((l) => <option key={l} value={l}>{l}</option>)}
                </optgroup>
              ))}
            </select>
            <input
              className="input mt-2"
              aria-label="Exact spot or room number"
              maxLength={120}
              disabled={busy}
              placeholder={form.location.includes("Classrooms") ? "Room no. e.g. B-204 (optional)" : "Exact spot e.g. near billing counter (optional)"}
              value={form.locationDetail}
              onChange={(e) => setForm({ ...form, locationDetail: e.target.value })}
            />
            <GpsPin
              disabled={busy}
              lat={form.reportLat}
              lng={form.reportLng}
              accuracy={form.reportAccuracy}
              onChange={(p) => setForm((f) => ({ ...f, reportLat: p?.lat ?? "", reportLng: p?.lng ?? "", reportAccuracy: p?.accuracy ?? "" }))}
            />
          </div>
        </div>

        {isIssue ? (
          <fieldset disabled={busy}>
            <legend className="label">Priority</legend>
            <div className="flex gap-2">
              {(["low", "medium", "high"] as const).map((p) => (
                <button key={p} type="button" aria-pressed={form.priority === p} onClick={() => setForm({ ...form, priority: p })}
                  className={cn("flex-1 rounded-lg border px-3 py-2 text-sm font-medium capitalize transition", form.priority === p ? p === "high" ? "border-rose-400 bg-rose-50 text-rose-700" : p === "medium" ? "border-amber-400 bg-amber-50 text-amber-700" : "border-slate-400 bg-slate-100 text-slate-700" : "border-slate-200 bg-white text-slate-500 hover:border-slate-300")}>{p}</button>
              ))}
            </div>
          </fieldset>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="occurredAt">{type === "lost" ? "When did you lose it?" : "When did you find it?"}</label>
              <input id="occurredAt" type="datetime-local" className="input" disabled={busy} value={form.occurredAt} onChange={(e) => setForm({ ...form, occurredAt: e.target.value })} />
            </div>
            <div>
              <label className="label" htmlFor="contactInfo">Contact info <span className="font-normal text-slate-400">(optional, public)</span></label>
              <input id="contactInfo" className="input" maxLength={200} disabled={busy} placeholder="College email or pickup location" value={form.contactInfo} onChange={(e) => setForm({ ...form, contactInfo: e.target.value })} />
            </div>
          </div>
        )}

        <fieldset disabled={busy} className="min-w-0 rounded-xl border border-slate-200 bg-slate-50/60 p-4">
          <legend className="px-1 text-sm font-semibold text-slate-800">👤 Reporter details</legend>
          <p className="mb-4 text-xs text-slate-500">So the owner or finder can reach you. Contact details are shown only to signed-in KPRIET members.</p>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="reporterName">Full name</label>
              <input id="reporterName" className="input" required minLength={2} maxLength={120} value={form.reporterName} onChange={(e) => setForm({ ...form, reporterName: e.target.value })} />
            </div>
            <div>
              <label className="label" htmlFor="reporterPhone">Mobile number</label>
              <input id="reporterPhone" type="tel" inputMode="numeric" className="input" required pattern="(\+91)?[6-9][0-9]{9}" title="10-digit Indian mobile number" placeholder="98765 43210" value={form.reporterPhone} onChange={(e) => setForm({ ...form, reporterPhone: e.target.value.replace(/[^\d+]/g, "") })} />
            </div>
            <div className="sm:col-span-2">
              <label className="label" htmlFor="reporterEmail">Email</label>
              <input id="reporterEmail" type="email" className="input" maxLength={200} value={form.reporterEmail} onChange={(e) => setForm({ ...form, reporterEmail: e.target.value })} />
            </div>
            <div>
              <label className="label" htmlFor="reporterYear">Studying year</label>
              <select id="reporterYear" className="input" required value={form.reporterYear} onChange={(e) => setForm({ ...form, reporterYear: e.target.value })}>
                <option value="" disabled>Select year…</option>
                {REPORTER_YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-[1fr_90px] gap-2">
              <div>
                <label className="label" htmlFor="reporterDepartment">Department</label>
                <select id="reporterDepartment" className="input" required value={form.reporterDepartment} onChange={(e) => setForm({ ...form, reporterDepartment: e.target.value })}>
                  <option value="" disabled>Select…</option>
                  {DEPARTMENTS.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div>
                <label className="label" htmlFor="reporterSection">Section</label>
                <select id="reporterSection" className="input" required={form.reporterYear !== "Faculty / Staff"} disabled={form.reporterYear === "Faculty / Staff"} value={form.reporterYear === "Faculty / Staff" ? "" : form.reporterSection} onChange={(e) => setForm({ ...form, reporterSection: e.target.value })}>
                  <option value="">{form.reporterYear === "Faculty / Staff" ? "N/A" : "–"}</option>
                  {SECTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>
          </div>
        </fieldset>

        <p className="rounded-lg bg-slate-50 px-3 py-2 text-xs leading-relaxed text-slate-500">Please report items and issues from the KPRIET campus only. Photos are visible with your report—avoid including ID numbers, private documents or other personal information.</p>
        {error && <p className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700" role="alert">{error}</p>}
        <div className="flex items-center justify-end gap-3 border-t border-slate-100 pt-4">
          <button type="button" className="btn-secondary" disabled={busy} onClick={() => router.back()}>Cancel</button>
          <button className="btn-primary" disabled={busy || photoProcessing}>{busy ? (photo ? "Uploading photo & report…" : "Submitting…") : photoProcessing ? "Preparing photo…" : `Submit ${POST_TYPES.find((t) => t.value === type)?.label}`}</button>
        </div>
      </div>
    </form>
  );
}
