"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { ALL_CATEGORIES, ISSUE_CATEGORIES, ITEM_CATEGORIES, LOCATION_GROUPS, STATUS_META, STATUSES } from "@/lib/constants";
import { cn } from "@/lib/utils";

const TYPE_TABS = [
  { value: "", label: "All" },
  { value: "lost", label: "🔍 Lost" },
  { value: "found", label: "🎒 Found" },
  { value: "issue", label: "🛠️ Issues" },
];

export function FilterBar({ total }: { total: number }) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const type = params.get("type") ?? "";
  const status = params.get("status") ?? "";
  const category = params.get("category") ?? "";
  const location = params.get("location") ?? "";
  const sort = params.get("sort") ?? "newest";
  const [q, setQ] = useState(params.get("q") ?? "");

  useEffect(() => {
    setQ(params.get("q") ?? "");
  }, [params]);

  function update(next: Record<string, string>) {
    const sp = new URLSearchParams(params.toString());
    for (const [k, v] of Object.entries(next)) {
      if (v) sp.set(k, v);
      else sp.delete(k);
    }
    router.push(`${pathname}?${sp.toString()}`);
  }

  const categories = type === "issue" ? ISSUE_CATEGORIES : type ? ITEM_CATEGORIES : ALL_CATEGORIES;
  const hasFilters = type || status || category || location || params.get("q");

  return (
    <div className="card space-y-4 p-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex rounded-lg bg-slate-100 p-1">
          {TYPE_TABS.map((t) => (
            <button
              key={t.value}
              type="button"
              onClick={() => update({ type: t.value, category: "" })}
              className={cn(
                "rounded-md px-3 py-1.5 text-sm font-medium transition",
                type === t.value ? "bg-white text-slate-900 shadow-sm" : "text-slate-600 hover:text-slate-900",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>

        <form
          className="relative min-w-[200px] flex-1"
          onSubmit={(e) => {
            e.preventDefault();
            update({ q });
          }}
        >
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search title, description, location…"
            className="input !pl-9"
          />
          <svg className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" viewBox="0 0 20 20" fill="currentColor" aria-hidden>
            <path
              fillRule="evenodd"
              d="M9 3.5a5.5 5.5 0 100 11 5.5 5.5 0 000-11zM2 9a7 7 0 1112.452 4.391l3.328 3.329a.75.75 0 11-1.06 1.06l-3.329-3.328A7 7 0 012 9z"
              clipRule="evenodd"
            />
          </svg>
        </form>

        <select value={category} onChange={(e) => update({ category: e.target.value })} className="input !w-auto">
          <option value="">All categories</option>
          {categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>

        <select value={location} aria-label="Filter by campus location" onChange={(e) => update({ location: e.target.value })} className="input !w-auto max-w-[220px]">
          <option value="">All KPRIET locations</option>
          {LOCATION_GROUPS.map((g) => (
            <optgroup key={g.label} label={g.label}>
              {g.locations.map((l) => <option key={l} value={l}>{l}</option>)}
            </optgroup>
          ))}
        </select>

        <select value={sort} onChange={(e) => update({ sort: e.target.value })} className="input !w-auto">
          <option value="newest">Newest first</option>
          <option value="top">Most upvoted</option>
          <option value="oldest">Oldest first</option>
        </select>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">Status</span>
        <StatusPill active={status === ""} onClick={() => update({ status: "" })} label="Any" dot="bg-slate-300" />
        <StatusPill active={status === "active"} onClick={() => update({ status: "active" })} label="Active" dot="bg-emerald-500" />
        {STATUSES.map((s) => (
          <StatusPill
            key={s}
            active={status === s}
            onClick={() => update({ status: s })}
            label={STATUS_META[s].label}
            dot={STATUS_META[s].dot}
          />
        ))}
        <span className="ml-auto text-sm text-slate-500">
          {total} result{total === 1 ? "" : "s"}
          {hasFilters && (
            <button type="button" onClick={() => router.push(pathname)} className="ml-3 font-medium text-indigo-600 hover:underline">
              Clear filters
            </button>
          )}
        </span>
      </div>
    </div>
  );
}

function StatusPill({ active, onClick, label, dot }: { active: boolean; onClick: () => void; label: string; dot: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium transition",
        active ? "border-indigo-300 bg-indigo-50 text-indigo-700" : "border-slate-200 bg-white text-slate-600 hover:border-slate-300",
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", dot)} />
      {label}
    </button>
  );
}
