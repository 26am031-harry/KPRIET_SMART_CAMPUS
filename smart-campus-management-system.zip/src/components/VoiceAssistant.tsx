"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { ZoomableImage } from "./ZoomableImage";

type Match = {
  id: number;
  type: "lost" | "found" | "issue";
  title: string;
  location: string;
  locationDetail: string | null;
  statusLabel: string;
  imageUrl: string | null;
  when: string;
  reporterName: string | null;
  reporterClass: string | null;
  reporterPhone: string | null;
};
type Msg = { id: number; role: "user" | "bot"; text: string; matches?: Match[] };

// Minimal Web Speech API typings (not in TypeScript's DOM lib).
type SRResult = { isFinal: boolean; 0: { transcript: string } };
type SREvent = { resultIndex: number; results: ArrayLike<SRResult> };
type SRInstance = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((e: SREvent) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
};
type SRCtor = new () => SRInstance;

const DEFAULT_SUGGESTIONS = [
  "I lost my headphones in the library",
  "Was any water bottle found at the Gym?",
  "What was found at Raagam Hall?",
  "How do I report a lost item?",
];

function cleanForSpeech(text: string) {
  return text.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, "").replace(/\s+/g, " ").trim();
}

export function VoiceAssistant() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([
    {
      id: 0,
      role: "bot",
      text: "Vanakkam! 👋 I'm the KPRIET Lost & Found voice assistant. Tap the mic and tell me what you lost or found and where — I'll search all reports for you.",
    },
  ]);
  const [input, setInput] = useState("");
  const [suggestions, setSuggestions] = useState(DEFAULT_SUGGESTIONS);
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [voiceOn, setVoiceOn] = useState(true);
  const [micSupported, setMicSupported] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const recRef = useRef<SRInstance | null>(null);
  const finalRef = useRef("");
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const idRef = useRef(1);

  useEffect(() => {
    const w = window as unknown as { SpeechRecognition?: SRCtor; webkitSpeechRecognition?: SRCtor };
    setMicSupported(!!(w.SpeechRecognition || w.webkitSpeechRecognition));
    return () => {
      recRef.current?.abort();
      window.speechSynthesis?.cancel();
    };
  }, []);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  useEffect(() => {
    if (!open) {
      recRef.current?.abort();
      window.speechSynthesis?.cancel();
      setSpeaking(false);
      return;
    }
    inputRef.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const speak = useCallback(
    (text: string) => {
      if (!voiceOn || !("speechSynthesis" in window)) return;
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(cleanForSpeech(text));
      const voices = window.speechSynthesis.getVoices();
      const voice =
        voices.find((v) => v.lang === "en-IN") ?? voices.find((v) => v.lang.startsWith("en-GB")) ?? voices.find((v) => v.lang.startsWith("en"));
      if (voice) u.voice = voice;
      u.lang = voice?.lang ?? "en-IN";
      u.rate = 1;
      u.onstart = () => setSpeaking(true);
      u.onend = () => setSpeaking(false);
      u.onerror = () => setSpeaking(false);
      window.speechSynthesis.speak(u);
    },
    [voiceOn],
  );

  const ask = useCallback(
    async (question: string) => {
      const q = question.trim();
      if (!q || busy) return;
      setNotice(null);
      setInput("");
      setMessages((m) => [...m, { id: idRef.current++, role: "user", text: q }]);
      setBusy(true);
      try {
        const res = await fetch("/api/assistant", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: q }),
        });
        const data = (await res.json().catch(() => ({}))) as { reply?: string; matches?: Match[]; suggestions?: string[]; error?: string };
        const reply = data.reply ?? data.error ?? "Sorry, something went wrong. Please try again.";
        setMessages((m) => [...m, { id: idRef.current++, role: "bot", text: reply, matches: data.matches }]);
        if (data.suggestions?.length) setSuggestions(data.suggestions);
        speak(reply);
      } catch {
        const reply = "I couldn't reach the server. Please check your connection and try again.";
        setMessages((m) => [...m, { id: idRef.current++, role: "bot", text: reply }]);
      } finally {
        setBusy(false);
      }
    },
    [busy, speak],
  );

  function toggleMic() {
    if (listening) {
      recRef.current?.stop();
      return;
    }
    const w = window as unknown as { SpeechRecognition?: SRCtor; webkitSpeechRecognition?: SRCtor };
    const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Ctor) {
      setNotice("Voice input isn't supported in this browser. Please type your question (Chrome or Edge support voice).");
      return;
    }
    window.speechSynthesis?.cancel();
    const rec = new Ctor();
    rec.lang = "en-IN";
    rec.interimResults = true;
    rec.continuous = false;
    finalRef.current = "";
    rec.onresult = (e) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        if (r.isFinal) finalRef.current += r[0].transcript;
        else interim += r[0].transcript;
      }
      setInput((finalRef.current + " " + interim).trim());
    };
    rec.onerror = (e) => {
      setListening(false);
      if (e.error === "not-allowed" || e.error === "service-not-allowed") {
        setNotice("Microphone access was blocked. Allow the microphone for this site (or open the portal in a new tab), or type your question.");
      } else if (e.error === "no-speech") {
        setNotice("I didn't hear anything. Tap the mic and speak again.");
      } else if (e.error !== "aborted") {
        setNotice("Voice input stopped unexpectedly. Please try again or type your question.");
      }
    };
    rec.onend = () => {
      setListening(false);
      const said = finalRef.current.trim();
      if (said) void ask(said);
    };
    recRef.current = rec;
    try {
      rec.start();
      setListening(true);
      setNotice(null);
    } catch {
      setNotice("Couldn't start the microphone. Please try again.");
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-controls="kpriet-assistant"
        className={cn(
          "fixed bottom-5 right-5 z-50 flex items-center gap-2 rounded-full bg-gradient-to-r from-indigo-600 to-teal-500 py-3 pl-3 pr-4 text-sm font-semibold text-white shadow-xl shadow-indigo-900/30 transition hover:scale-105 focus:outline-none focus:ring-4 focus:ring-indigo-300",
          open && "pr-3",
        )}
      >
        <span className="relative grid h-8 w-8 place-items-center rounded-full bg-white/20">
          {!open && <span className="absolute inset-0 animate-ping rounded-full bg-white/30" />}
          {open ? "✕" : <MicIcon className="h-4 w-4" />}
        </span>
        {!open && <span className="hidden sm:inline">Ask KPRIET Assistant</span>}
        <span className="sr-only">{open ? "Exit assistant" : "Open voice assistant"}</span>
      </button>

      {open && (
        <section
          id="kpriet-assistant"
          role="dialog"
          aria-label="KPRIET Lost and Found voice assistant"
          className="fade-up fixed bottom-24 right-3 z-50 flex max-h-[min(640px,calc(100dvh-7.5rem))] w-[calc(100vw-1.5rem)] max-w-md flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl sm:right-5"
        >
          <header className="flex items-center gap-3 bg-gradient-to-r from-indigo-600 to-indigo-500 px-4 py-3 text-white">
            <span className={cn("grid h-10 w-10 place-items-center rounded-full bg-white/15 text-lg", (speaking || listening) && "animate-pulse")}>🤖</span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">KPRIET Assist</p>
              <p className="text-[11px] text-[#e0e7ff]">
                {listening ? "Listening… speak now" : speaking ? "Speaking…" : busy ? "Searching reports…" : "Lost & Found voice assistant"}
              </p>
            </div>
            {speaking && (
              <button type="button" onClick={() => { window.speechSynthesis.cancel(); setSpeaking(false); }} className="rounded-md bg-white/15 px-2 py-1 text-[11px] font-semibold hover:bg-white/25">
                Stop
              </button>
            )}
            <button
              type="button"
              onClick={() => { setVoiceOn((v) => !v); window.speechSynthesis?.cancel(); }}
              aria-pressed={voiceOn}
              title={voiceOn ? "Mute spoken replies" : "Turn on spoken replies"}
              className="grid h-8 w-8 place-items-center rounded-full bg-white/15 hover:bg-white/25"
            >
              {voiceOn ? "🔊" : "🔇"}
            </button>
          </header>

          <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto bg-slate-50 p-4" aria-live="polite">
            {messages.map((m) => (
              <div key={m.id} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
                <div className={cn("max-w-[88%] space-y-2", m.role === "user" && "text-right")}>
                  <p
                    className={cn(
                      "inline-block whitespace-pre-line rounded-2xl px-3.5 py-2 text-left text-sm leading-relaxed",
                      m.role === "user" ? "rounded-br-md bg-indigo-600 text-white" : "rounded-bl-md border border-slate-200 bg-white text-slate-800",
                    )}
                  >
                    {m.text}
                  </p>
                  {m.role === "bot" && m.text.length > 0 && m.id > 0 && (
                    <button type="button" onClick={() => speak(m.text)} className="block text-[11px] font-medium text-slate-400 hover:text-indigo-600">
                      🔈 Replay
                    </button>
                  )}
                  {m.matches?.map((x) => (
                    <Link
                      key={x.id}
                      href={`/posts/${x.id}`}
                      onClick={() => setOpen(false)}
                      className="flex gap-3 rounded-xl border border-slate-200 bg-white p-2 text-left transition hover:border-indigo-300 hover:shadow-sm"
                    >
                      {x.imageUrl ? (
                        <ZoomableImage src={x.imageUrl} alt={`Photo of ${x.title}`} className="h-16 w-16 flex-none rounded-lg object-cover" />
                      ) : (
                        <span className="grid h-16 w-16 flex-none place-items-center rounded-lg bg-slate-100 text-2xl">📦</span>
                      )}
                      <span className="min-w-0 text-xs">
                        <span className="flex items-center gap-1.5">
                          <span className={cn("rounded px-1.5 py-0.5 text-[10px] font-bold uppercase", x.type === "found" ? "bg-teal-50 text-teal-700" : "bg-rose-50 text-rose-700")}>
                            {x.type}
                          </span>
                          <span className="text-slate-400">{x.statusLabel} · {x.when}</span>
                        </span>
                        <span className="mt-0.5 block truncate text-sm font-semibold text-slate-900">{x.title}</span>
                        <span className="block truncate text-slate-500">📍 {x.location}{x.locationDetail ? ` · ${x.locationDetail}` : ""}</span>
                        {x.reporterName && (
                          <span className="block truncate text-slate-500">
                            👤 {x.reporterName}{x.reporterClass ? ` · ${x.reporterClass}` : ""}{x.reporterPhone ? ` · 📞 ${x.reporterPhone}` : ""}
                          </span>
                        )}
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            ))}
            {busy && (
              <div className="flex gap-1 px-2" aria-label="Assistant is typing">
                {[0, 1, 2].map((i) => (
                  <span key={i} className="h-2 w-2 animate-bounce rounded-full bg-indigo-400" style={{ animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            )}
          </div>

          <div className="border-t border-slate-200 bg-white p-3">
            <div className="mb-2 flex gap-1.5 overflow-x-auto pb-1">
              {suggestions.map((s) => (
                <button key={s} type="button" disabled={busy} onClick={() => ask(s)} className="whitespace-nowrap rounded-full border border-indigo-100 bg-indigo-50 px-2.5 py-1 text-[11px] font-medium text-indigo-700 hover:bg-indigo-100 disabled:opacity-50">
                  {s}
                </button>
              ))}
            </div>
            {notice && <p className="mb-2 rounded-lg bg-amber-50 px-2.5 py-1.5 text-[11px] text-amber-800" role="alert">{notice}</p>}
            <form
              className="flex items-center gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                void ask(input);
              }}
            >
              <button
                type="button"
                onClick={toggleMic}
                aria-pressed={listening}
                title={micSupported ? (listening ? "Stop listening" : "Speak your question") : "Voice input not supported in this browser"}
                className={cn(
                  "relative grid h-10 w-10 flex-none place-items-center rounded-full transition",
                  listening ? "bg-rose-500 text-white" : micSupported ? "bg-indigo-600 text-white hover:bg-indigo-500" : "bg-slate-200 text-slate-500",
                )}
              >
                {listening && <span className="absolute inset-0 animate-ping rounded-full bg-rose-400/60" />}
                <MicIcon className="relative h-5 w-5" />
                <span className="sr-only">{listening ? "Stop listening" : "Start voice input"}</span>
              </button>
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                maxLength={500}
                placeholder={listening ? "Listening…" : "Type or tap the mic to ask…"}
                aria-label="Ask the assistant"
                className="input !rounded-full"
              />
              <button type="submit" disabled={busy || !input.trim()} className="btn-primary !h-10 !rounded-full !px-4">
                Ask
              </button>
            </form>
          </div>
        </section>
      )}
    </>
  );
}

function MicIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
      <rect x="9" y="3" width="6" height="11" rx="3" />
      <path d="M5 11a7 7 0 0 0 14 0M12 18v3" />
    </svg>
  );
}
