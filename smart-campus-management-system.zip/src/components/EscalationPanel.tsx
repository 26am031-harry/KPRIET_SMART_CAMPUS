"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { COLLEGE_CONTACTS } from "@/lib/college";
import type { EscalationCheck } from "@/lib/escalation";
import { cn, formatDate } from "@/lib/utils";

export type EscalationCheckDTO = Omit<EscalationCheck, "eligibleFrom" | "existing"> & {
  eligibleFrom: string;
  existing?: { id: number; reference: string; status: string; reason: string; createdAt: string; handledAt: string | null; handledNote: string | null } | null;
};

type Props = {
  postId: number;
  title: string;
  location: string;
  createdAt: string;
  upvotes: number;
  isAdmin: boolean;
  canEscalate: boolean;
  check: EscalationCheckDTO;
};

const STATUS_STYLE: Record<string, string> = {
  submitted: "bg-rose-500/15 text-rose-200 ring-rose-400/40",
  acknowledged: "bg-amber-500/15 text-amber-200 ring-amber-400/40",
  closed: "bg-emerald-500/15 text-emerald-200 ring-emerald-400/40",
};

function contactLinks(reference: string, title: string, location: string, createdAt: string, reason: string, waitingDays: number, upvotes: number, postId: number) {
  const subject = `Escalation ${reference}: No action on KPRIET campus report`;
  const body = [
    "Respected Sir/Madam,",
    "",
    `I am escalating the following KPRIET Smart Campus report because no action has been taken for ${waitingDays} day(s).`,
    "",
    `Reference: ${reference}`,
    `Report: ${title}`,
    `Campus location: ${location}`,
    `Reported on: ${formatDate(createdAt)}`,
    `Community upvotes: ${upvotes}`,
    `Portal link: ${typeof window !== "undefined" ? window.location.origin : ""}/posts/${postId}`,
    "",
    "Reason:",
    reason,
    "",
    "Kindly look into this and advise the concerned department.",
    "",
    "Thank you,",
    "KPRIET student/staff",
  ].join("\n");
  return {
    href: `mailto:${COLLEGE_CONTACTS.ceoOffice.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`,
    tel: `tel:${COLLEGE_CONTACTS.ceoOffice.tel}`,
    whatsapp: `https://wa.me/${COLLEGE_CONTACTS.ceoOffice.tel.replace("+", "")}?text=${encodeURIComponent(`${subject}\n\n${body}`)}`,
  };
}

export function EscalationPanel({ postId, title, location, createdAt, upvotes, isAdmin, canEscalate, check }: Props) {
  const router = useRouter();
  const [reason, setReason] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [created, setCreated] = useState<{ reference: string; waitingDays: number; reason: string } | null>(null);

  const existing = created
    ? { reference: created.reference, status: "submitted", reason: created.reason, createdAt: new Date().toISOString(), handledAt: null, handledNote: null, waitingDays: check.waitingDays }
    : check.existing
      ? { ...check.existing, waitingDays: check.waitingDays }
      : null;

  async function submit() {
    setBusy(true);
    setError(null);
    const res = await fetch(`/api/posts/${postId}/escalate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reason, confirmed }),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string; escalation?: { reference: string; waitingDays: number } };
    setBusy(false);
    if (!res.ok || !data.escalation) {
      setError(data.error ?? "Escalation failed. Please try again.");
      return;
    }
    setCreated({ reference: data.escalation.reference, waitingDays: data.escalation.waitingDays, reason });
    router.refresh();
  }

  return (
    <section aria-label="Escalate to CEO's Office" className="card overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-gradient-to-r from-rose-600/20 to-transparent px-5 py-4">
        <div>
          <h2 className="flex items-center gap-2 font-semibold text-slate-900">
            🏛️ Escalate to the CEO&apos;s Office
          </h2>
          <p className="mt-0.5 text-xs text-slate-500">
            Only allowed after the portal verifies that <strong className="text-slate-700">no action</strong> has been taken on this report.
          </p>
        </div>
        {existing && (
          <span className={cn("rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-wide ring-1", STATUS_STYLE[existing.status] ?? STATUS_STYLE.submitted)}>
            {existing.status}
          </span>
        )}
      </div>

      <div className="space-y-4 p-5">
        {/* 1. Already escalated */}
        {existing ? (
          <>
            <div className="rounded-xl border border-white/15 bg-white/5 p-4">
              <p className="text-xs uppercase tracking-wide text-slate-400">Escalation reference</p>
              <p className="mt-1 font-mono text-lg font-bold text-slate-900">{existing.reference}</p>
              <p className="mt-1 text-xs text-slate-500">
                Raised {formatDate(existing.createdAt)} after {existing.waitingDays} day(s) without action · Status: {existing.status}
              </p>
              {existing.handledNote && (
                <p className="mt-2 rounded-lg bg-indigo-500/15 px-3 py-2 text-xs text-indigo-200">
                  <strong>College office:</strong> {existing.handledNote}
                  {existing.handledAt ? ` (${formatDate(existing.handledAt)})` : ""}
                </p>
              )}
              <p className="mt-2 text-xs leading-relaxed text-slate-500">“{existing.reason}”</p>
            </div>

            <div className="rounded-xl border border-emerald-400/30 bg-emerald-500/10 p-4">
              <p className="text-xs font-bold uppercase tracking-wide text-emerald-200">Verified — contact the CEO&apos;s Office directly</p>
              <p className="mt-1 text-xs text-emerald-100/80">{COLLEGE_CONTACTS.ceoOffice.label} · {COLLEGE_CONTACTS.ceoOffice.phone}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                <a href={contactLinks(existing.reference, title, location, createdAt, existing.reason, existing.waitingDays, upvotes, postId).href} className="btn-primary !px-3 !py-1.5 !text-xs">
                  ✉️ Email with reference
                </a>
                <a href={contactLinks(existing.reference, title, location, createdAt, existing.reason, existing.waitingDays, upvotes, postId).tel} className="btn-secondary !px-3 !py-1.5 !text-xs">
                  📞 Call office
                </a>
                <a
                  href={contactLinks(existing.reference, title, location, createdAt, existing.reason, existing.waitingDays, upvotes, postId).whatsapp}
                  target="_blank"
                  rel="noreferrer"
                  className="btn-success !px-3 !py-1.5 !text-xs"
                >
                  💬 WhatsApp
                </a>
              </div>
              <p className="mt-2 text-[11px] text-emerald-100/70">Quote reference <strong>{existing.reference}</strong> so the office can trace this report.</p>
            </div>
          </>
        ) : check.eligible && canEscalate ? (
          /* 2. Verified eligible → escalation form */
          <>
            <div className="flex items-start gap-3 rounded-xl border border-emerald-400/30 bg-emerald-500/10 p-4 text-sm text-emerald-100">
              <span className="text-lg" aria-hidden>✅</span>
              <div>
                <p className="font-semibold text-emerald-200">Verification passed</p>
                <p className="mt-0.5 text-xs text-emerald-100/80">{check.message}</p>
              </div>
            </div>
            <div>
              <label className="label" htmlFor="esc-reason">Why should the CEO&apos;s Office look into this?</label>
              <textarea
                id="esc-reason"
                className="input min-h-[90px]"
                required
                minLength={20}
                maxLength={1500}
                disabled={busy}
                placeholder="e.g. This has been reported for 5 days, it affects 40 students during lab hours, and no department has responded."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
              />
              <p className="mt-1 text-[11px] text-slate-400">{reason.trim().length}/20 characters minimum</p>
            </div>
            <label className="flex items-start gap-2.5 rounded-xl border border-white/15 bg-white/5 p-3 text-xs text-slate-300">
              <input type="checkbox" checked={confirmed} disabled={busy} onChange={(e) => setConfirmed(e.target.checked)} className="mt-0.5 h-4 w-4 accent-indigo-500" />
              <span>
                I confirm that no action has been taken on this report — no status update, no official note and no reply from the college office
                {isAdmin && " (escalating on the student's behalf as campus admin)"}.
              </span>
            </label>
            {error && <p className="rounded-lg bg-rose-500/15 px-3 py-2 text-sm text-rose-200" role="alert">{error}</p>}
            <button type="button" onClick={submit} disabled={busy || !confirmed || reason.trim().length < 20} className="btn-primary w-full">
              {busy ? "Verifying & escalating…" : "🏛️ Escalate to the CEO's Office"}
            </button>
            <p className="text-center text-[11px] text-slate-400">
              One escalation per report. After escalating you get the CEO&apos;s Office contact details with your reference number.
            </p>
          </>
        ) : (
          /* 3. Not eligible → show the verification result, no direct contact */
          <>
            <div
              className={cn(
                "flex items-start gap-3 rounded-xl border p-4 text-sm",
                check.code === "waiting" ? "border-amber-400/30 bg-amber-500/10 text-amber-100" : "border-white/15 bg-white/5 text-slate-300",
              )}
            >
              <span className="text-lg" aria-hidden>{check.code === "waiting" ? "⏳" : check.code === "action_taken" ? "🛑" : "🔒"}</span>
              <div className="min-w-0">
                <p className="font-semibold">
                  {check.code === "waiting" && "Not yet eligible — waiting period"}
                  {check.code === "action_taken" && "Not eligible — action was taken"}
                  {check.code === "not_your_report" && "Not eligible — not your report"}
                  {check.code === "already_escalated" && "Already escalated"}
                  {check.code === "not_found" && "Report unavailable"}
                </p>
                <p className="mt-1 text-xs leading-relaxed opacity-90">{check.message}</p>
                {check.actionEvidence.length > 0 && (
                  <ul className="mt-2 space-y-1 text-xs opacity-90">
                    {check.actionEvidence.map((e) => (
                      <li key={e} className="flex items-start gap-1.5">
                        <span aria-hidden>•</span>
                        {e}
                      </li>
                    ))}
                  </ul>
                )}
                {check.code === "waiting" && (
                  <div className="mt-3">
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-black/30">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-amber-400 to-rose-400 transition-all"
                        style={{ width: `${Math.min(100, Math.round((check.waitingDays / check.requiredDays) * 100))}%` }}
                      />
                    </div>
                    <p className="mt-1.5 text-[11px] opacity-80">
                      {check.waitingDays} of {check.requiredDays} day(s) waited · eligible from {formatDate(check.eligibleFrom)}
                    </p>
                  </div>
                )}
              </div>
            </div>
            <p className="rounded-lg bg-white/5 px-3 py-2 text-[11px] leading-relaxed text-slate-400">
              Direct CEO&apos;s Office contact is released only after verification passes. Meanwhile you can follow up in the report
              discussion, upvote it, or contact the {COLLEGE_CONTACTS.office.label} ({COLLEGE_CONTACTS.office.phone}) for general enquiries.
            </p>
          </>
        )}

        <ol className="grid gap-2 border-t border-white/10 pt-4 text-[11px] text-slate-400 sm:grid-cols-3">
          <li className="rounded-lg bg-white/5 p-2.5"><strong className="block text-slate-300">1. Report & wait</strong>{check.requiredDays} day(s) with no action.</li>
          <li className="rounded-lg bg-white/5 p-2.5"><strong className="block text-slate-300">2. Auto-verification</strong>Checks status, office notes, updates and replies.</li>
          <li className="rounded-lg bg-white/5 p-2.5"><strong className="block text-slate-300">3. CEO&apos;s Office</strong>Reference number + direct contact released.</li>
        </ol>
      </div>
    </section>
  );
}
