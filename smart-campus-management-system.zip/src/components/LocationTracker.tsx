"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

type Props = {
  destLat: number;
  destLng: number;
  /** true when the reporter pinned an exact GPS spot; false = campus-level fallback */
  precise: boolean;
  accuracy: number | null;
  placeLabel: string;
  reporterName: string | null;
};

type Me = { lat: number; lng: number; accuracy: number; at: number };

const toRad = (d: number) => (d * Math.PI) / 180;

function distanceMeters(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371000;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

function bearingDeg(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const y = Math.sin(toRad(b.lng - a.lng)) * Math.cos(toRad(b.lat));
  const x = Math.cos(toRad(a.lat)) * Math.sin(toRad(b.lat)) - Math.sin(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.cos(toRad(b.lng - a.lng));
  return ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;
}

const COMPASS = ["North", "North-East", "East", "South-East", "South", "South-West", "West", "North-West"];
const compassName = (deg: number) => COMPASS[Math.round(deg / 45) % 8];

function formatDistance(m: number) {
  return m < 1000 ? `${Math.round(m)} m` : `${(m / 1000).toFixed(m < 10000 ? 2 : 1)} km`;
}

export function LocationTracker({ destLat, destLng, precise, accuracy, placeLabel, reporterName }: Props) {
  const [me, setMe] = useState<Me | null>(null);
  const [tracking, setTracking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [heading, setHeading] = useState<number | null>(null);
  const watchRef = useRef<number | null>(null);
  const dest = { lat: destLat, lng: destLng };

  useEffect(() => () => stop(), []); // eslint-disable-line react-hooks/exhaustive-deps

  function onOrientation(e: DeviceOrientationEvent & { webkitCompassHeading?: number }) {
    if (typeof e.webkitCompassHeading === "number") setHeading(e.webkitCompassHeading);
    else if (e.absolute && typeof e.alpha === "number") setHeading((360 - e.alpha) % 360);
  }

  async function start() {
    setError(null);
    if (!window.isSecureContext || !("geolocation" in navigator)) {
      setError("Location tracking needs a secure (https) page and a browser with GPS support.");
      return;
    }
    // iOS requires explicit permission for the compass; optional elsewhere.
    const DOE = DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> };
    try {
      if (typeof DOE?.requestPermission === "function") {
        if ((await DOE.requestPermission()) === "granted") window.addEventListener("deviceorientation", onOrientation as EventListener);
      } else {
        window.addEventListener("deviceorientationabsolute", onOrientation as EventListener);
        window.addEventListener("deviceorientation", onOrientation as EventListener);
      }
    } catch {
      /* compass is optional */
    }
    setTracking(true);
    watchRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        setMe({ lat: pos.coords.latitude, lng: pos.coords.longitude, accuracy: pos.coords.accuracy, at: Date.now() });
        setError(null);
      },
      (err) => {
        setError(
          err.code === err.PERMISSION_DENIED
            ? "Location permission was denied. Allow location access for this site (or open the portal in a new browser tab) to start tracking."
            : err.code === err.TIMEOUT
              ? "Getting your location is taking too long. Move to an open area — still trying…"
              : "Your location is unavailable right now. Check that GPS/location services are on.",
        );
        if (err.code === err.PERMISSION_DENIED) stop();
      },
      { enableHighAccuracy: true, maximumAge: 3000, timeout: 20000 },
    );
  }

  function stop() {
    if (watchRef.current !== null) navigator.geolocation.clearWatch(watchRef.current);
    watchRef.current = null;
    window.removeEventListener("deviceorientationabsolute", onOrientation as EventListener);
    window.removeEventListener("deviceorientation", onOrientation as EventListener);
    setTracking(false);
  }

  const dist = me ? distanceMeters(me, dest) : null;
  const bearing = me ? bearingDeg(me, dest) : null;
  const arrow = bearing === null ? 0 : heading === null ? bearing : (bearing - heading + 360) % 360;
  const arrived = dist !== null && dist <= Math.max(20, (me?.accuracy ?? 0) * 0.6);
  const etaMin = dist !== null ? Math.max(1, Math.round(dist / 1.3 / 60)) : null;

  // Map viewport: destination, expanded to include the user when known (if reasonably near).
  const pts = [dest, ...(me && dist !== null && dist < 20000 ? [me] : [])];
  const pad = 0.0025;
  const bbox = [
    Math.min(...pts.map((p) => p.lng)) - pad,
    Math.min(...pts.map((p) => p.lat)) - pad,
    Math.max(...pts.map((p) => p.lng)) + pad,
    Math.max(...pts.map((p) => p.lat)) + pad,
  ].map((n) => n.toFixed(6));
  const mapSrc = `https://www.openstreetmap.org/export/embed.html?bbox=${bbox.join("%2C")}&layer=mapnik&marker=${destLat}%2C${destLng}`;
  const directions = `https://www.google.com/maps/dir/?api=1${me ? `&origin=${me.lat},${me.lng}` : ""}&destination=${destLat},${destLng}&travelmode=walking`;

  return (
    <section aria-label="Location tracker" className="card overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 px-5 py-4">
        <div>
          <h2 className="font-semibold text-slate-900">🧭 Location tracker</h2>
          <p className="text-xs text-slate-500">
            {precise
              ? `Exact spot pinned by ${reporterName ?? "the reporter"}${accuracy ? ` (±${Math.round(accuracy)} m)` : ""} · ${placeLabel}`
              : `${placeLabel} · reporter didn't pin GPS, so this points to the KPRIET campus`}
          </p>
        </div>
        {tracking ? (
          <button type="button" onClick={stop} className="btn-danger !px-3 !py-1.5 !text-xs">Stop tracking</button>
        ) : (
          <button type="button" onClick={start} className="btn-primary !px-3 !py-1.5 !text-xs">📡 Track from my location</button>
        )}
      </div>

      <div className="grid gap-0 md:grid-cols-5">
        <div className="relative h-64 bg-[#0b1324] md:col-span-3 md:h-auto md:min-h-72">
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 text-center text-xs text-slate-400" aria-hidden>
            <span className="text-2xl">🗺️</span>
            Loading map of {placeLabel}…
          </div>
          <iframe
            title={`Map of ${placeLabel}`}
            src={mapSrc}
            className="absolute inset-0 h-full w-full border-0 [filter:invert(0.9)_hue-rotate(180deg)_saturate(0.8)]"
            loading="lazy"
            referrerPolicy="no-referrer"
          />
        </div>

        <div className="flex flex-col items-center justify-center gap-3 p-5 text-center md:col-span-2" aria-live="polite">
          {!me ? (
            <>
              <div className="grid h-24 w-24 place-items-center rounded-full border-2 border-dashed border-white/15 text-3xl">{tracking ? "📡" : "🧭"}</div>
              <p className="text-sm text-slate-600">
                {tracking ? "Finding your location…" : "Tap Track from my location to see live distance and direction to this spot."}
              </p>
            </>
          ) : arrived ? (
            <>
              <div className="grid h-24 w-24 place-items-center rounded-full bg-emerald-50 text-4xl ring-4 ring-emerald-200">🎯</div>
              <p className="text-lg font-bold text-emerald-700">You&apos;ve arrived!</p>
              <p className="text-xs text-slate-500">You are within {formatDistance(dist ?? 0)} of the {precise ? "pinned spot" : "campus point"}.</p>
            </>
          ) : (
            <>
              <div className="relative grid h-28 w-28 place-items-center rounded-full border border-white/15 bg-white/5">
                {["N", "E", "S", "W"].map((d, i) => (
                  <span key={d} className="absolute text-[10px] font-bold text-slate-400" style={{ transform: `rotate(${i * 90}deg) translateY(-46px) rotate(${-i * 90}deg)` }}>
                    {d}
                  </span>
                ))}
                <svg viewBox="0 0 24 24" className="h-14 w-14 text-indigo-400 drop-shadow-[0_0_10px_rgba(129,140,248,0.7)] transition-transform duration-500" style={{ transform: `rotate(${arrow}deg)` }} aria-hidden>
                  <path fill="currentColor" d="M12 2 19 21l-7-4-7 4 7-19Z" />
                </svg>
              </div>
              <p className="text-3xl font-extrabold text-slate-900">{formatDistance(dist ?? 0)}</p>
              <p className="text-sm text-slate-600">
                Head <strong className="text-slate-800">{compassName(bearing ?? 0)}</strong> ({Math.round(bearing ?? 0)}°) · ~{etaMin} min walk
              </p>
              <p className={cn("text-[11px]", heading === null ? "text-slate-400" : "text-emerald-700")}>
                {heading === null ? "Arrow points relative to North" : "Arrow follows your phone's compass"} · your GPS ±{Math.round(me.accuracy)} m
              </p>
            </>
          )}
          {error && <p className="rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-800" role="alert">{error}</p>}
          <a href={directions} target="_blank" rel="noreferrer" className="btn-secondary w-full !text-xs">
            🗺️ Walking directions in Google Maps
          </a>
        </div>
      </div>
    </section>
  );
}
