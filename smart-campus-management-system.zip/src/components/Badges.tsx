import type { PostStatus, PostType, Priority } from "@/db/schema";
import { PRIORITY_META, STATUS_META, TYPE_META } from "@/lib/constants";
import { cn } from "@/lib/utils";

export function TypeBadge({ type, className }: { type: PostType; className?: string }) {
  const meta = TYPE_META[type];
  return (
    <span className={cn("chip", meta.classes, className)}>
      <span aria-hidden>{meta.icon}</span>
      {meta.label}
    </span>
  );
}

export function StatusBadge({ status, className }: { status: PostStatus; className?: string }) {
  const meta = STATUS_META[status];
  return (
    <span className={cn("chip", meta.classes, className)}>
      <span className={cn("h-1.5 w-1.5 rounded-full", meta.dot)} />
      {meta.label}
    </span>
  );
}

export function PriorityBadge({ priority, className }: { priority: Priority; className?: string }) {
  const meta = PRIORITY_META[priority];
  return (
    <span className={cn("inline-flex rounded-md px-2 py-0.5 text-xs font-semibold", meta.classes, className)}>
      {meta.label} priority
    </span>
  );
}

export function RoleBadge({ role }: { role: string }) {
  const classes =
    role === "admin"
      ? "bg-indigo-600 text-white"
      : role === "staff"
        ? "bg-teal-100 text-teal-800"
        : "bg-slate-100 text-slate-700";
  return (
    <span className={cn("rounded-md px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide", classes)}>
      {role}
    </span>
  );
}
