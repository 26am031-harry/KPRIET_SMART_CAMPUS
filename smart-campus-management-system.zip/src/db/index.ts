import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { sql } from "drizzle-orm";
import { Pool } from "pg";
import * as schema from "./schema";

type Db = NodePgDatabase<typeof schema>;

/** Never throw at module import time — callers always fail gracefully instead. */
export function isDbConfigured(): boolean {
  return Boolean(process.env.DATABASE_URL?.trim());
}

let pool: Pool | null = null;
let client: Db | null = null;

export function getDb(): Db {
  const url = process.env.DATABASE_URL?.trim();
  if (!url) {
    throw new DbError(
      "DATABASE_URL is not set",
      "Create a .env file with: DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db",
    );
  }
  if (!client) {
    pool = new Pool({ connectionString: url, max: 5, connectionTimeoutMillis: 4000, idleTimeoutMillis: 10_000 });
    client = drizzle(pool, { schema });
  }
  return client;
}

// Lazily-initialized drizzle client with the same shape as before.
export const db = new Proxy({} as Db, {
  get(_target, prop, receiver) {
    const real = getDb() as unknown as Record<PropertyKey, unknown>;
    const value = Reflect.get(real, prop, receiver);
    return typeof value === "function" ? value.bind(real) : value;
  },
});

export class DbError extends Error {
  /** Human-friendly setup instructions shown to the visitor. */
  help: string;
  constructor(message: string, help: string) {
    super(message);
    this.name = "DbError";
    this.help = help;
  }
}

function collectMessages(err: unknown, depth = 0): string {
  if (depth > 6) return "";
  if (err instanceof Error) {
    const parts = [err.message];
    if (err.cause) parts.push(collectMessages(err.cause, depth + 1));
    return parts.filter(Boolean).join(" ");
  }
  return String(err ?? "");
}

export function dbErrorHelp(err: unknown): string {
  if (err instanceof DbError) return err.help;
  const msg = collectMessages(err);
  if (/ECONNREFUSED|ENOTFOUND|ETIMEDOUT|EHOSTUNREACH|getaddrinfo|connection refused|socket|timeout/i.test(msg)) {
    return "PostgreSQL is not reachable at the host in DATABASE_URL. Start PostgreSQL and make sure the database URL in .env matches it (see README.md).";
  }
  if (/password|authentication failed|no pg_hba|ssl|certificate/i.test(msg)) {
    return "PostgreSQL authentication failed. Check the username and password in DATABASE_URL (default user: postgres, password: postgres).";
  }
  if (/relation .* does not exist|database .* does not exist|schema .* does not exist|not a valid identifier/i.test(msg)) {
    return "The database or tables are missing. Create the database, then run: npx drizzle-kit push  (then restart the server).";
  }
  return "See the server log for details and the README.md setup steps.";
}

/** Cheap health probe used by the banner/notice; never throws. */
export async function probeDatabase(): Promise<{ ok: boolean; message?: string }> {
  if (!isDbConfigured()) return { ok: false, message: "DATABASE_URL is not set." };
  try {
    await getDb().execute(sql`select 1`);
    return { ok: true };
  } catch (err) {
    return { ok: false, message: dbErrorHelp(err) };
  }
}
