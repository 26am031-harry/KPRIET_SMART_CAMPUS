import { sql } from "drizzle-orm";
import { db } from "@/db";
import { users, posts, upvotes, claims, comments, activity, escalations } from "@/db/schema";
import { hashPassword } from "@/lib/auth";

let seedPromise: Promise<void> | null = null;

export function ensureSeeded() {
  if (!seedPromise) {
    seedPromise = (async () => {
      const { isDbConfigured } = await import("@/db");
      if (!isDbConfigured()) return; // let the setup notice explain the missing URL
      try {
        await seed();
      } catch (err) {
        seedPromise = null;
        console.error("Seed failed (database unreachable or schema not applied):", err instanceof Error ? err.message : err);
      }
    })();
  }
  return seedPromise;
}

const hoursAgo = (h: number) => new Date(Date.now() - h * 60 * 60 * 1000);

async function seed() {
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(users);
  if (count > 0) return;

  const password = hashPassword("password123");

  const [admin, priya, arun, lakshmi, karthik, divya] = await db
    .insert(users)
    .values([
      { name: "KPRIET Campus Admin", email: "admin@kpriet.ac.in", passwordHash: password, role: "admin", department: "Estate & Facilities Office" },
      { name: "Priya Sharma", email: "priya@kpriet.ac.in", passwordHash: password, role: "student", department: "CSE" },
      { name: "Arun Kumar", email: "arun@kpriet.ac.in", passwordHash: password, role: "student", department: "Mechanical" },
      { name: "Dr. Lakshmi Narayanan", email: "lakshmi@kpriet.ac.in", passwordHash: password, role: "staff", department: "ECE" },
      { name: "Karthik Raja", email: "karthik@kpriet.ac.in", passwordHash: password, role: "student", department: "IT" },
      { name: "Divya Ramesh", email: "divya@kpriet.ac.in", passwordHash: password, role: "student", department: "AI & DS" },
    ])
    .returning();

  const R = {
    priya: { reporterName: priya.name, reporterPhone: "9876543210", reporterEmail: priya.email, reporterYear: "III Year", reporterDepartment: "CSE", reporterSection: "B" },
    arun: { reporterName: arun.name, reporterPhone: "9843012345", reporterEmail: arun.email, reporterYear: "II Year", reporterDepartment: "Mechanical", reporterSection: "A" },
    lakshmi: { reporterName: lakshmi.name, reporterPhone: "9944556677", reporterEmail: lakshmi.email, reporterYear: "Faculty / Staff", reporterDepartment: "ECE", reporterSection: null },
    karthik: { reporterName: karthik.name, reporterPhone: "9791234567", reporterEmail: karthik.email, reporterYear: "IV Year", reporterDepartment: "IT", reporterSection: "C" },
    divya: { reporterName: divya.name, reporterPhone: "9500123456", reporterEmail: divya.email, reporterYear: "I Year", reporterDepartment: "AI & DS", reporterSection: "D" },
  };

  const inserted = await db
    .insert(posts)
    .values([
      {
        type: "lost", title: "Black Sony WH-1000XM4 headphones",
        description: "Left them on a reading table on the 1st floor of the Central Library near the quiet study area around 4 pm. Small cat sticker on the right ear cup.",
        category: "Electronics", location: "Central Library", locationDetail: "1st floor, quiet study area",
        status: "open", authorId: priya.id, ...R.priya, imageUrl: "/images/items/headphones.jpg",
        occurredAt: hoursAgo(30), upvoteCount: 3, createdAt: hoursAgo(28), updatedAt: hoursAgo(28),
      },
      {
        type: "found", title: "Student ID card on blue lanyard",
        description: "Found a KPRIET student ID card on a blue lanyard near the entrance of AC Dining after lunch. Handed it to the AC Dining counter — ask there with proof of identity.",
        category: "ID / Cards", location: "AC Dining", locationDetail: "Main entrance",
        status: "open", authorId: arun.id, ...R.arun, imageUrl: "/images/items/id-card.jpg",
        occurredAt: hoursAgo(10), upvoteCount: 1, createdAt: hoursAgo(9), updatedAt: hoursAgo(9),
      },
      {
        type: "issue", title: "Wi-Fi keeps dropping in B Block 2nd floor classrooms",
        description: "During the 10 am and 2 pm classes the campus Wi-Fi drops every few minutes in rooms B-201 to B-206. Online quizzes are nearly impossible.",
        category: "Wi-Fi / Network", location: "B Block · 2nd Floor Classrooms", locationDetail: "B-201 to B-206",
        status: "in_progress", priority: "high", authorId: lakshmi.id, ...R.lakshmi,
        adminNote: "IT team identified a faulty access point. Replacement scheduled for Thursday.",
        upvoteCount: 14, createdAt: hoursAgo(72), updatedAt: hoursAgo(20),
      },
      {
        type: "issue", title: "Leaking water purifier at Sports Arena",
        description: "The drinking water purifier next to the Sports Arena entrance is leaking and the tap is stuck. Water pools on the floor and is a slip hazard.",
        category: "Plumbing", location: "Sports Arena", locationDetail: "Near main entrance",
        status: "open", priority: "medium", authorId: arun.id, ...R.arun,
        upvoteCount: 7, createdAt: hoursAgo(50), updatedAt: hoursAgo(50),
      },
      {
        type: "found", title: "Blue insulated water bottle",
        description: "Found a blue steel water bottle with a hiking sticker on the bench after the evening workout at the Gym. It's with me — happy to hand it over.",
        category: "Water Bottles", location: "Gym", locationDetail: "Bench near the treadmills",
        status: "claimed", authorId: karthik.id, ...R.karthik, imageUrl: "/images/items/water-bottle.jpg",
        occurredAt: hoursAgo(96), upvoteCount: 2, createdAt: hoursAgo(90), updatedAt: hoursAgo(40),
      },
      {
        type: "lost", title: "Set of keys with a red carabiner",
        description: "Three keys and a small bike-lock key on a red carabiner. Probably dropped between Royal Kitchen and Mini Mario on Tuesday evening.",
        category: "Keys", location: "Royal Kitchen",
        status: "open", authorId: karthik.id, ...R.karthik, imageUrl: "/images/items/keys.jpg",
        occurredAt: hoursAgo(40), upvoteCount: 0, createdAt: hoursAgo(38), updatedAt: hoursAgo(38),
      },
      {
        type: "issue", title: "Flickering tube lights in C Block ground floor",
        description: "Two tube lights in the back row of room C-004 flicker constantly, causing headaches during long lab-record sessions.",
        category: "Electrical", location: "C Block · Ground Floor Classrooms", locationDetail: "Room C-004",
        status: "resolved", priority: "low", authorId: priya.id, ...R.priya,
        adminNote: "Chokes replaced by the electrical team on Monday.", resolvedAt: hoursAgo(12),
        upvoteCount: 5, createdAt: hoursAgo(120), updatedAt: hoursAgo(12),
      },
      {
        type: "issue", title: "Overflowing dustbins near Tasty Time",
        description: "The bins beside the Tasty Time seating area haven't been emptied since yesterday and are attracting crows and flies.",
        category: "Cleanliness", location: "Tasty Time",
        status: "open", priority: "medium", authorId: divya.id, ...R.divya,
        upvoteCount: 9, createdAt: hoursAgo(18), updatedAt: hoursAgo(18),
      },
      {
        type: "lost", title: "Grey backpack with Dell laptop",
        description: "Left my grey backpack in A Block 3rd floor room A-305 after the morning class. It contains a Dell laptop and lab records. Very urgent.",
        category: "Bags & Wallets", location: "A Block · 3rd Floor Classrooms", locationDetail: "Room A-305",
        status: "resolved", authorId: arun.id, ...R.arun, imageUrl: "/images/items/backpack.jpg",
        occurredAt: hoursAgo(150), resolvedAt: hoursAgo(100), adminNote: "Returned to owner via the Security Office.",
        upvoteCount: 4, createdAt: hoursAgo(148), updatedAt: hoursAgo(100),
      },
      {
        type: "issue", title: "Broken seat in Sanskriti Auditorium (row F)",
        description: "One of the fold-down seats in row F is broken and the metal edge is exposed. Someone could get hurt during the next event.",
        category: "Furniture", location: "Sanskriti Auditorium", locationDetail: "Row F, seat 12",
        status: "open", priority: "high", authorId: lakshmi.id, ...R.lakshmi,
        upvoteCount: 6, createdAt: hoursAgo(6), updatedAt: hoursAgo(6),
      },
      {
        type: "found", title: "Engineering Mathematics textbook",
        description: "Found a thick Engineering Mathematics textbook with a green cover and the name 'R. Patel' written inside, left at a table in Campus Kitchen. Left it at the counter.",
        category: "Books & Notes", location: "Campus Kitchen",
        status: "open", authorId: priya.id, ...R.priya, imageUrl: "/images/items/textbook.jpg",
        occurredAt: hoursAgo(4), upvoteCount: 0, createdAt: hoursAgo(3), updatedAt: hoursAgo(3),
      },
      {
        type: "found", title: "Grey scientific calculator",
        description: "Found a grey scientific calculator on a seat armrest in Raagam Hall after the seminar. It has initials scratched on the back — tell me what they are to claim it.",
        category: "Electronics", location: "Raagam Hall",
        status: "open", authorId: divya.id, ...R.divya, imageUrl: "/images/items/calculator.jpg",
        occurredAt: hoursAgo(7), upvoteCount: 1, createdAt: hoursAgo(6), updatedAt: hoursAgo(6),
      },
      {
        type: "lost", title: "Brown leather wallet",
        description: "Lost my brown leather bifold wallet at Saaral Bakery while buying puffs around 11 am. It has my bus pass and some cash.",
        category: "Bags & Wallets", location: "Saaral Bakery", locationDetail: "Billing counter",
        status: "open", authorId: divya.id, ...R.divya, imageUrl: "/images/items/wallet.jpg",
        occurredAt: hoursAgo(5), upvoteCount: 2, createdAt: hoursAgo(5), updatedAt: hoursAgo(5),
      },
      {
        type: "issue", title: "AC not cooling in Dhanam Hall",
        description: "The air conditioning in Dhanam Hall has been blowing warm air for a week. It gets unbearable during afternoon sessions.",
        category: "HVAC / Climate", location: "Dhanam Hall",
        status: "in_progress", priority: "medium", authorId: karthik.id, ...R.karthik,
        adminNote: "Technician visit booked for tomorrow morning.",
        upvoteCount: 11, createdAt: hoursAgo(60), updatedAt: hoursAgo(8),
      },
    ])
    .returning();

  const byTitle = (t: string) => inserted.find((p) => p.title.startsWith(t))!;
  const wifi = byTitle("Wi-Fi keeps");
  const purifier = byTitle("Leaking water purifier");
  const bottle = byTitle("Blue insulated");
  const lights = byTitle("Flickering tube");
  const bins = byTitle("Overflowing dustbins");
  const backpack = byTitle("Grey backpack");
  const seat = byTitle("Broken seat");
  const ac = byTitle("AC not cooling");
  const headphones = byTitle("Black Sony");

  await db.insert(upvotes).values([
    { postId: wifi.id, userId: priya.id }, { postId: wifi.id, userId: arun.id }, { postId: wifi.id, userId: karthik.id },
    { postId: purifier.id, userId: priya.id }, { postId: purifier.id, userId: lakshmi.id },
    { postId: bins.id, userId: priya.id }, { postId: bins.id, userId: arun.id },
    { postId: ac.id, userId: priya.id }, { postId: ac.id, userId: arun.id }, { postId: ac.id, userId: lakshmi.id },
    { postId: seat.id, userId: priya.id }, { postId: lights.id, userId: arun.id },
    { postId: headphones.id, userId: arun.id }, { postId: headphones.id, userId: karthik.id },
  ]);

  await db.insert(claims).values([
    {
      postId: bottle.id, claimantId: priya.id,
      message: "That's mine! It has a mountain sticker and a dent near the bottom. I left it after my workout on Friday.",
      status: "approved", reviewedById: admin.id, reviewedAt: hoursAgo(40), createdAt: hoursAgo(60),
    },
    {
      postId: byTitle("Student ID card").id, claimantId: karthik.id,
      message: "Could be my classmate Aishwarya's card — she lost hers yesterday at lunch. I can bring her by.",
      status: "pending", createdAt: hoursAgo(5),
    },
  ]);

  await db.insert(comments).values([
    { postId: wifi.id, authorId: arun.id, body: "Same problem in B-204 during the 2 pm hour. It's been like this all week.", createdAt: hoursAgo(60) },
    { postId: wifi.id, authorId: admin.id, body: "Thanks all — IT is replacing the access point on Thursday. We'll update here once done.", isOfficial: true, createdAt: hoursAgo(20) },
    { postId: purifier.id, authorId: lakshmi.id, body: "A 'Wet floor' board was placed this morning, but it's still leaking.", createdAt: hoursAgo(30) },
    { postId: headphones.id, authorId: arun.id, body: "I was in the library around 5 pm. Didn't see them, but check the library front desk.", createdAt: hoursAgo(20) },
    { postId: ac.id, authorId: admin.id, body: "Work order #4471 created. Technician visit tomorrow 9 am.", isOfficial: true, createdAt: hoursAgo(8) },
  ]);

  await db.insert(activity).values([
    ...inserted.map((p) => ({ postId: p.id, actorId: p.authorId, action: "created", toStatus: "open", createdAt: p.createdAt })),
    { postId: wifi.id, actorId: admin.id, action: "status_changed", fromStatus: "open", toStatus: "in_progress", note: "IT identified a faulty access point.", createdAt: hoursAgo(20) },
    { postId: lights.id, actorId: admin.id, action: "status_changed", fromStatus: "open", toStatus: "resolved", note: "Chokes replaced.", createdAt: hoursAgo(12) },
    { postId: bottle.id, actorId: priya.id, action: "claim_submitted", createdAt: hoursAgo(60) },
    { postId: bottle.id, actorId: admin.id, action: "claim_approved", fromStatus: "open", toStatus: "claimed", createdAt: hoursAgo(40) },
    { postId: backpack.id, actorId: admin.id, action: "status_changed", fromStatus: "open", toStatus: "resolved", note: "Returned via Security Office.", createdAt: hoursAgo(100) },
    { postId: ac.id, actorId: admin.id, action: "status_changed", fromStatus: "open", toStatus: "in_progress", note: "Technician booked.", createdAt: hoursAgo(8) },
  ]);

  // One long-ignored report with a verified escalation to the CEO's Office.
  const [oldReport] = await db
    .insert(posts)
    .values([
      {
        type: "issue", title: "Street light out on the hostel road",
        description: "The street light near the hostel road junction has been out for over a week. Students walking back after night classes pass through complete darkness.",
        category: "Electrical", location: "Sports Arena", locationDetail: "Hostel road junction",
        status: "open", priority: "high", authorId: karthik.id, ...R.karthik,
        reportLat: 11.0762, reportLng: 77.1432, reportAccuracy: 15,
        upvoteCount: 12, createdAt: hoursAgo(24 * 6), updatedAt: hoursAgo(24 * 6),
      },
    ])
    .returning();

  const [escalation] = await db
    .insert(escalations)
    .values({
      reference: "KP-ESC-0001", postId: oldReport.id, requesterId: karthik.id,
      reason: "Reported 6 days ago with 12 upvotes and no response. Students are walking in the dark after night classes and it is a safety risk.",
      status: "submitted", waitingDays: 6, upvoteCount: 12, postStatus: "open", createdAt: hoursAgo(24 * 2), updatedAt: hoursAgo(24 * 2),
    })
    .returning();

  await db.insert(activity).values([
    { postId: oldReport.id, actorId: karthik.id, action: "created", toStatus: "open", createdAt: hoursAgo(24 * 6) },
    { postId: oldReport.id, actorId: karthik.id, action: "escalated_to_ceo", note: `${escalation.reference}: escalated to the CEO's Office after 6 day(s) without action.`, createdAt: hoursAgo(24 * 2) },
  ]);

  await db.execute(sql`
    update posts p set upvote_count = greatest(p.upvote_count, (select count(*) from upvotes u where u.post_id = p.id))
  `);
}
