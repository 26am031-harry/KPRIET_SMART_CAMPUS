import {
  pgTable,
  serial,
  text,
  varchar,
  timestamp,
  integer,
  boolean,
  pgEnum,
  uniqueIndex,
  index,
  uuid,
  doublePrecision,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

export const userRoleEnum = pgEnum("user_role", ["student", "staff", "admin"]);
export const postTypeEnum = pgEnum("post_type", ["lost", "found", "issue"]);
export const postStatusEnum = pgEnum("post_status", [
  "open",
  "in_progress",
  "claimed",
  "resolved",
  "closed",
]);
export const priorityEnum = pgEnum("priority", ["low", "medium", "high"]);
export const claimStatusEnum = pgEnum("claim_status", [
  "pending",
  "approved",
  "rejected",
]);

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 200 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: userRoleEnum("role").notNull().default("student"),
  department: varchar("department", { length: 120 }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const posts = pgTable(
  "posts",
  {
    id: serial("id").primaryKey(),
    type: postTypeEnum("type").notNull(),
    title: varchar("title", { length: 160 }).notNull(),
    description: text("description").notNull(),
    category: varchar("category", { length: 60 }).notNull(),
    location: varchar("location", { length: 160 }).notNull(),
    status: postStatusEnum("status").notNull().default("open"),
    priority: priorityEnum("priority").notNull().default("medium"),
    imageUrl: text("image_url"),
    contactInfo: varchar("contact_info", { length: 200 }),
    locationDetail: varchar("location_detail", { length: 120 }),
    // Optional GPS pin shared by the reporter when submitting (for the location tracker).
    reportLat: doublePrecision("report_lat"),
    reportLng: doublePrecision("report_lng"),
    reportAccuracy: doublePrecision("report_accuracy"),
    reporterName: varchar("reporter_name", { length: 120 }),
    reporterPhone: varchar("reporter_phone", { length: 20 }),
    reporterEmail: varchar("reporter_email", { length: 200 }),
    reporterYear: varchar("reporter_year", { length: 30 }),
    reporterDepartment: varchar("reporter_department", { length: 60 }),
    reporterSection: varchar("reporter_section", { length: 10 }),
    authorId: integer("author_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    upvoteCount: integer("upvote_count").notNull().default(0),
    adminNote: text("admin_note"),
    occurredAt: timestamp("occurred_at", { withTimezone: true }),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [
    index("posts_type_idx").on(t.type),
    index("posts_status_idx").on(t.status),
    index("posts_category_idx").on(t.category),
    index("posts_created_idx").on(t.createdAt),
  ],
);

// Photos are stored in PostgreSQL so uploads survive deployments/restarts.
// Base64 text keeps the existing node-postgres connection portable.
export const photos = pgTable("photos", {
  id: uuid("id").primaryKey().defaultRandom(),
  postId: integer("post_id")
    .notNull()
    .references(() => posts.id, { onDelete: "cascade" }),
  uploaderId: integer("uploader_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  contentType: varchar("content_type", { length: 30 }).notNull(),
  data: text("data").notNull(),
  byteSize: integer("byte_size").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const upvotes = pgTable(
  "upvotes",
  {
    id: serial("id").primaryKey(),
    postId: integer("post_id")
      .notNull()
      .references(() => posts.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("upvotes_post_user_idx").on(t.postId, t.userId)],
);

export const claims = pgTable(
  "claims",
  {
    id: serial("id").primaryKey(),
    postId: integer("post_id")
      .notNull()
      .references(() => posts.id, { onDelete: "cascade" }),
    claimantId: integer("claimant_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    message: text("message").notNull(),
    status: claimStatusEnum("status").notNull().default("pending"),
    reviewedById: integer("reviewed_by_id").references(() => users.id),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("claims_post_idx").on(t.postId)],
);

export const comments = pgTable(
  "comments",
  {
    id: serial("id").primaryKey(),
    postId: integer("post_id")
      .notNull()
      .references(() => posts.id, { onDelete: "cascade" }),
    authorId: integer("author_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    body: text("body").notNull(),
    isOfficial: boolean("is_official").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("comments_post_idx").on(t.postId)],
);

export const activity = pgTable(
  "activity",
  {
    id: serial("id").primaryKey(),
    postId: integer("post_id")
      .notNull()
      .references(() => posts.id, { onDelete: "cascade" }),
    actorId: integer("actor_id").references(() => users.id, {
      onDelete: "set null",
    }),
    action: varchar("action", { length: 60 }).notNull(),
    fromStatus: varchar("from_status", { length: 30 }),
    toStatus: varchar("to_status", { length: 30 }),
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("activity_post_idx").on(t.postId)],
);

// CEO's-office escalation: allowed only after the portal verifies that the
// report received no action (see src/lib/escalation.ts).
export const escalationStatusEnum = pgEnum("escalation_status", [
  "submitted",
  "acknowledged",
  "closed",
]);

export const escalations = pgTable(
  "escalations",
  {
    id: serial("id").primaryKey(),
    reference: varchar("reference", { length: 30 }).notNull().unique(),
    postId: integer("post_id")
      .notNull()
      .references(() => posts.id, { onDelete: "cascade" }),
    requesterId: integer("requester_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    reason: text("reason").notNull(),
    status: escalationStatusEnum("status").notNull().default("submitted"),
    // Evidence snapshot captured when the escalation was verified & created.
    waitingDays: integer("waiting_days").notNull(),
    upvoteCount: integer("upvote_count").notNull(),
    postStatus: varchar("post_status", { length: 30 }).notNull(),
    handledById: integer("handled_by_id").references(() => users.id),
    handledNote: text("handled_note"),
    handledAt: timestamp("handled_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("escalations_post_idx").on(t.postId), index("escalations_status_idx").on(t.status)],
);

export const usersRelations = relations(users, ({ many }) => ({
  posts: many(posts),
  claims: many(claims),
  comments: many(comments),
  escalations: many(escalations),
}));

export const postsRelations = relations(posts, ({ one, many }) => ({
  author: one(users, { fields: [posts.authorId], references: [users.id] }),
  upvotes: many(upvotes),
  claims: many(claims),
  comments: many(comments),
  activity: many(activity),
  escalations: many(escalations),
}));

export const claimsRelations = relations(claims, ({ one }) => ({
  post: one(posts, { fields: [claims.postId], references: [posts.id] }),
  claimant: one(users, { fields: [claims.claimantId], references: [users.id] }),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  post: one(posts, { fields: [comments.postId], references: [posts.id] }),
  author: one(users, { fields: [comments.authorId], references: [users.id] }),
}));

export const escalationsRelations = relations(escalations, ({ one }) => ({
  post: one(posts, { fields: [escalations.postId], references: [posts.id] }),
  requester: one(users, { fields: [escalations.requesterId], references: [users.id] }),
  handledBy: one(users, { fields: [escalations.handledById], references: [users.id] }),
}));

export const activityRelations = relations(activity, ({ one }) => ({
  post: one(posts, { fields: [activity.postId], references: [posts.id] }),
  actor: one(users, { fields: [activity.actorId], references: [users.id] }),
}));

export type User = typeof users.$inferSelect;
export type Post = typeof posts.$inferSelect;
export type Claim = typeof claims.$inferSelect;
export type Comment = typeof comments.$inferSelect;
export type Activity = typeof activity.$inferSelect;
export type Escalation = typeof escalations.$inferSelect;
export type EscalationStatus = Escalation["status"];
export type PostType = Post["type"];
export type PostStatus = Post["status"];
export type Priority = Post["priority"];
