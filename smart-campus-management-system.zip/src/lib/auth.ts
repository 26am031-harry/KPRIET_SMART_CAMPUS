import { cookies } from "next/headers";
import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { eq } from "drizzle-orm";
import { db, DbError, dbErrorHelp } from "@/db";
import { users, type User } from "@/db/schema";

const COOKIE_NAME = "campus_session";
const SESSION_DAYS = 7;

function secret() {
  return process.env.SESSION_SECRET ?? "campus-portal-dev-secret-change-me";
}

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return candidate.length === expected.length && timingSafeEqual(candidate, expected);
}

function sign(payload: string) {
  return createHmac("sha256", secret()).update(payload).digest("base64url");
}

export function createSessionToken(userId: number): string {
  const expires = Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000;
  const payload = `${userId}.${expires}`;
  return `${payload}.${sign(payload)}`;
}

export function parseSessionToken(token: string | undefined): number | null {
  if (!token) return null;
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const [userId, expires, sig] = parts;
  const payload = `${userId}.${expires}`;
  const expected = sign(payload);
  if (sig.length !== expected.length) return null;
  if (!timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  if (Number(expires) < Date.now()) return null;
  const id = Number(userId);
  return Number.isFinite(id) ? id : null;
}

export async function setSessionCookie(userId: number) {
  const store = await cookies();
  store.set(COOKIE_NAME, createSessionToken(userId), {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_DAYS * 24 * 60 * 60,
  });
}

export async function clearSessionCookie() {
  const store = await cookies();
  store.set(COOKIE_NAME, "", { httpOnly: true, path: "/", maxAge: 0 });
}

export type SafeUser = Omit<User, "passwordHash">;

export function toSafeUser(user: User): SafeUser {
  const { passwordHash: _ignored, ...rest } = user;
  void _ignored;
  return rest;
}

export async function getCurrentUser(): Promise<SafeUser | null> {
  const store = await cookies();
  const userId = parseSessionToken(store.get(COOKIE_NAME)?.value);
  if (!userId) return null;
  try {
    const user = await db.query.users.findFirst({ where: eq(users.id, userId) });
    return user ? toSafeUser(user) : null;
  } catch (err) {
    // A missing/unreachable database must never take the whole page down.
    console.error("getCurrentUser failed:", err instanceof Error ? err.message : err);
    return null;
  }
}

export async function requireUser(): Promise<SafeUser> {
  const user = await getCurrentUser();
  if (!user) throw new AuthError("Please sign in to continue.", 401);
  return user;
}

export async function requireAdmin(): Promise<SafeUser> {
  const user = await requireUser();
  if (user.role !== "admin") throw new AuthError("Admin access required.", 403);
  return user;
}

export class AuthError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

export function errorResponse(err: unknown) {
  if (err instanceof AuthError) {
    return Response.json({ error: err.message }, { status: err.status });
  }
  if (err instanceof DbError) {
    return Response.json({ error: "Database unavailable", detail: err.help }, { status: 503 });
  }
  const help = /ECONNREFUSED|ENOTFOUND|ETIMEDOUT|password|authentication|relation .* does not exist|connection|Failed query/i.test(
    err instanceof Error ? err.message : String(err),
  )
    ? dbErrorHelp(err)
    : null;
  if (help) {
    console.error(help);
    return Response.json({ error: "Database unavailable", detail: help }, { status: 503 });
  }
  console.error(err);
  return Response.json({ error: "Something went wrong." }, { status: 500 });
}
