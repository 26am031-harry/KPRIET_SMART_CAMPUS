import { and, asc, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { posts, users, upvotes, claims, type PostStatus, type PostType } from "@/db/schema";

export type PostFilters = {
  type?: string | null;
  status?: string | null;
  category?: string | null;
  location?: string | null;
  q?: string | null;
  sort?: string | null;
  authorId?: number | null;
  limit?: number;
};

const VALID_TYPES: PostType[] = ["lost", "found", "issue"];
const VALID_STATUSES: PostStatus[] = ["open", "in_progress", "claimed", "resolved", "closed"];

export type PostListItem = {
  id: number;
  type: PostType;
  title: string;
  description: string;
  category: string;
  location: string;
  status: PostStatus;
  priority: "low" | "medium" | "high";
  imageUrl: string | null;
  upvoteCount: number;
  createdAt: Date;
  updatedAt: Date;
  authorName: string;
  authorId: number;
  locationDetail: string | null;
  reporterName: string | null;
  reporterYear: string | null;
  reporterDepartment: string | null;
  reporterSection: string | null;
  commentCount: number;
  claimCount: number;
  pendingClaims: number;
  viewerUpvoted: boolean;
};

export async function listPosts(
  filters: PostFilters,
  viewerId?: number | null,
): Promise<PostListItem[]> {
  const where: SQL[] = [];
  if (filters.type && VALID_TYPES.includes(filters.type as PostType)) {
    where.push(eq(posts.type, filters.type as PostType));
  }
  if (filters.status && VALID_STATUSES.includes(filters.status as PostStatus)) {
    where.push(eq(posts.status, filters.status as PostStatus));
  } else if (filters.status === "active") {
    where.push(or(eq(posts.status, "open"), eq(posts.status, "in_progress"))!);
  }
  if (filters.category) {
    where.push(eq(posts.category, filters.category));
  }
  if (filters.location) {
    where.push(eq(posts.location, filters.location));
  }
  if (filters.q && filters.q.trim()) {
    const like = `%${filters.q.trim()}%`;
    where.push(
      or(ilike(posts.title, like), ilike(posts.description, like), ilike(posts.location, like))!,
    );
  }
  if (filters.authorId) {
    where.push(eq(posts.authorId, filters.authorId));
  }

  const orderBy =
    filters.sort === "top"
      ? [desc(posts.upvoteCount), desc(posts.createdAt)]
      : filters.sort === "oldest"
        ? [asc(posts.createdAt)]
        : [desc(posts.createdAt)];

  const viewer = viewerId ?? -1;

  const rows = await db
    .select({
      id: posts.id,
      type: posts.type,
      title: posts.title,
      description: posts.description,
      category: posts.category,
      location: posts.location,
      status: posts.status,
      priority: posts.priority,
      imageUrl: posts.imageUrl,
      upvoteCount: posts.upvoteCount,
      createdAt: posts.createdAt,
      updatedAt: posts.updatedAt,
      authorName: users.name,
      authorId: posts.authorId,
      locationDetail: posts.locationDetail,
      reporterName: posts.reporterName,
      reporterYear: posts.reporterYear,
      reporterDepartment: posts.reporterDepartment,
      reporterSection: posts.reporterSection,
      commentCount: sql<number>`(select count(*)::int from comments c where c.post_id = ${posts.id})`,
      claimCount: sql<number>`(select count(*)::int from claims cl where cl.post_id = ${posts.id})`,
      pendingClaims: sql<number>`(select count(*)::int from claims cl where cl.post_id = ${posts.id} and cl.status = 'pending')`,
      viewerUpvoted: sql<boolean>`exists(select 1 from upvotes u where u.post_id = ${posts.id} and u.user_id = ${viewer})`,
    })
    .from(posts)
    .innerJoin(users, eq(users.id, posts.authorId))
    .where(where.length ? and(...where) : undefined)
    .orderBy(...orderBy)
    .limit(filters.limit ?? 100);

  return rows;
}

export async function getPostDetail(id: number, viewerId?: number | null) {
  const post = await db.query.posts.findFirst({
    where: eq(posts.id, id),
    with: {
      author: { columns: { id: true, name: true, role: true, department: true } },
      comments: {
        with: { author: { columns: { id: true, name: true, role: true } } },
        orderBy: (c, { asc }) => [asc(c.createdAt)],
      },
      claims: {
        with: { claimant: { columns: { id: true, name: true, role: true } } },
        orderBy: (c, { desc }) => [desc(c.createdAt)],
      },
      activity: {
        with: { actor: { columns: { id: true, name: true, role: true } } },
        orderBy: (a, { desc }) => [desc(a.createdAt)],
      },
      escalations: { orderBy: (e, { desc }) => [desc(e.createdAt)] },
    },
  });
  if (!post) return null;

  let viewerUpvoted = false;
  if (viewerId) {
    const row = await db.query.upvotes.findFirst({
      where: and(eq(upvotes.postId, id), eq(upvotes.userId, viewerId)),
    });
    viewerUpvoted = !!row;
  }
  return { ...post, viewerUpvoted };
}

export async function getStats() {
  const [row] = await db
    .select({
      total: sql<number>`count(*)::int`,
      lost: sql<number>`count(*) filter (where type = 'lost')::int`,
      found: sql<number>`count(*) filter (where type = 'found')::int`,
      issues: sql<number>`count(*) filter (where type = 'issue')::int`,
      open: sql<number>`count(*) filter (where status in ('open','in_progress'))::int`,
      resolved: sql<number>`count(*) filter (where status in ('resolved','claimed'))::int`,
      highPriorityOpen: sql<number>`count(*) filter (where type = 'issue' and priority = 'high' and status in ('open','in_progress'))::int`,
    })
    .from(posts);
  const [claimRow] = await db
    .select({ pendingClaims: sql<number>`count(*)::int` })
    .from(claims)
    .where(eq(claims.status, "pending"));
  return { ...row, pendingClaims: claimRow.pendingClaims };
}
