import type { PostStatus, PostType, Priority } from "@/db/schema";

export const POST_TYPES: { value: PostType; label: string; icon: string; blurb: string }[] = [
  { value: "lost", label: "Lost Item", icon: "🔍", blurb: "I lost something on campus" },
  { value: "found", label: "Found Item", icon: "🎒", blurb: "I found something that isn't mine" },
  { value: "issue", label: "Maintenance Issue", icon: "🛠️", blurb: "Something on campus needs fixing" },
];

export const ITEM_CATEGORIES = [
  "Electronics",
  "ID / Cards",
  "Keys",
  "Bags & Wallets",
  "Clothing",
  "Books & Notes",
  "Water Bottles",
  "Jewelry & Accessories",
  "Other",
];

export const ISSUE_CATEGORIES = [
  "Electrical",
  "Plumbing",
  "Wi-Fi / Network",
  "Cleanliness",
  "Furniture",
  "HVAC / Climate",
  "Safety & Security",
  "Accessibility",
  "Other",
];

export const ALL_CATEGORIES = Array.from(
  new Set([...ITEM_CATEGORIES, ...ISSUE_CATEGORIES]),
);

export const CAMPUS_BLOCKS = ["A Block", "B Block", "C Block", "D Block"] as const;
export const CAMPUS_FLOORS = ["Ground Floor", "1st Floor", "2nd Floor", "3rd Floor"] as const;

export const LOCATION_GROUPS: { label: string; icon: string; locations: string[] }[] = [
  {
    label: "Food & Dining",
    icon: "🍽️",
    locations: ["AC Dining", "Saaral Bakery", "Royal Kitchen", "Mini Mario", "Campus Kitchen", "Tasty Time"],
  },
  {
    label: "Library, Halls & Auditorium",
    icon: "🏛️",
    locations: ["Central Library", "Raagam Hall", "Dhanam Hall", "Sanskriti Auditorium"],
  },
  { label: "Sports & Fitness", icon: "🏅", locations: ["Gym", "Sports Arena"] },
  ...CAMPUS_BLOCKS.map((block) => ({
    label: `${block} Classrooms`,
    icon: "🏫",
    locations: CAMPUS_FLOORS.map((floor) => `${block} · ${floor} Classrooms`),
  })),
];

export const CAMPUS_LOCATIONS = LOCATION_GROUPS.flatMap((g) => g.locations);

/** Spoken/typed shortcuts the voice assistant understands for each place. */
export const LOCATION_ALIASES: Record<string, string[]> = {
  "AC Dining": ["ac dining", "dining hall", "dining", "mess"],
  "Saaral Bakery": ["saaral", "bakery"],
  "Royal Kitchen": ["royal kitchen", "royal"],
  "Mini Mario": ["mini mario", "mario"],
  "Campus Kitchen": ["campus kitchen"],
  "Tasty Time": ["tasty time", "tasty"],
  "Central Library": ["central library", "library"],
  "Raagam Hall": ["raagam", "ragam"],
  "Dhanam Hall": ["dhanam", "thanam"],
  "Sanskriti Auditorium": ["sanskriti", "auditorium", "sanskrithi"],
  Gym: ["gym", "gymnasium", "fitness"],
  "Sports Arena": ["sports arena", "arena", "ground", "court", "sports"],
};

export const REPORTER_YEARS = ["I Year", "II Year", "III Year", "IV Year", "Faculty / Staff"];

export const DEPARTMENTS = [
  "CSE",
  "IT",
  "AI & DS",
  "CSE (AI & ML)",
  "CSE (Cyber Security)",
  "CSBS",
  "ECE",
  "EEE",
  "Mechanical",
  "Civil",
  "Chemical",
  "Biomedical",
  "MBA",
  "Science & Humanities",
  "Other",
];

export const SECTIONS = ["A", "B", "C", "D", "E", "F"];

export function formatClass(p: {
  reporterYear?: string | null;
  reporterDepartment?: string | null;
  reporterSection?: string | null;
}) {
  if (!p.reporterYear) return null;
  if (p.reporterYear === "Faculty / Staff") {
    return p.reporterDepartment ? `Faculty / Staff · ${p.reporterDepartment}` : "Faculty / Staff";
  }
  const cls = [p.reporterDepartment, p.reporterSection].filter(Boolean).join(" – ");
  return cls ? `${p.reporterYear} · ${cls}` : p.reporterYear;
}

export const STATUSES: PostStatus[] = [
  "open",
  "in_progress",
  "claimed",
  "resolved",
  "closed",
];

export const STATUS_META: Record<
  PostStatus,
  { label: string; classes: string; dot: string }
> = {
  open: {
    label: "Open",
    classes: "bg-sky-50 text-sky-700 ring-sky-200",
    dot: "bg-sky-500",
  },
  in_progress: {
    label: "In Progress",
    classes: "bg-amber-50 text-amber-700 ring-amber-200",
    dot: "bg-amber-500",
  },
  claimed: {
    label: "Claimed",
    classes: "bg-violet-50 text-violet-700 ring-violet-200",
    dot: "bg-violet-500",
  },
  resolved: {
    label: "Resolved",
    classes: "bg-emerald-50 text-emerald-700 ring-emerald-200",
    dot: "bg-emerald-500",
  },
  closed: {
    label: "Closed",
    classes: "bg-slate-100 text-slate-600 ring-slate-200",
    dot: "bg-slate-400",
  },
};

export const TYPE_META: Record<
  PostType,
  { label: string; icon: string; classes: string; accent: string }
> = {
  lost: {
    label: "Lost",
    icon: "🔍",
    classes: "bg-rose-50 text-rose-700 ring-rose-200",
    accent: "border-l-rose-400",
  },
  found: {
    label: "Found",
    icon: "🎒",
    classes: "bg-teal-50 text-teal-700 ring-teal-200",
    accent: "border-l-teal-400",
  },
  issue: {
    label: "Issue",
    icon: "🛠️",
    classes: "bg-indigo-50 text-indigo-700 ring-indigo-200",
    accent: "border-l-indigo-400",
  },
};

export const PRIORITY_META: Record<Priority, { label: string; classes: string }> = {
  low: { label: "Low", classes: "bg-slate-100 text-slate-600" },
  medium: { label: "Medium", classes: "bg-amber-100 text-amber-700" },
  high: { label: "High", classes: "bg-rose-100 text-rose-700" },
};

/** Which statuses make sense for which post type (used by admin controls). */
export function statusesForType(type: PostType): PostStatus[] {
  if (type === "issue") return ["open", "in_progress", "resolved", "closed"];
  return ["open", "claimed", "resolved", "closed"];
}

export function categoriesForType(type: PostType): string[] {
  return type === "issue" ? ISSUE_CATEGORIES : ITEM_CATEGORIES;
}
