export const MAX_PHOTO_BYTES = 5 * 1024 * 1024;
export const MAX_SOURCE_PHOTO_BYTES = 15 * 1024 * 1024;
export const PHOTO_ACCEPT = "image/jpeg,image/png,image/webp";
export const PHOTO_MIME_TYPES = ["image/jpeg", "image/png", "image/webp"];
