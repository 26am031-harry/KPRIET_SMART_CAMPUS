/** Website creator — shown on every page so users can report website issues. */
export const CREATOR = {
  name: "Haarish K",
  phone: "+91 90805 65571",
  tel: "+919080565571",
  email: "haarishhaary3@gmail.com",
} as const;
