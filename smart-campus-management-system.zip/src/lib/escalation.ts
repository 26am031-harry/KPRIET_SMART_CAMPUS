import { and, asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { activity, comments, escalations, posts, users } from "@/db/schema";
import type { SafeUser } from "@/lib/auth";
import { COLLEGE_CONTACTS, ESCALATION_WAIT_DAYS, ESCALATION_WAIT_DAYS_HIGH } from "@/lib/college";
import { formatDate } from "@/lib/utils";

export type EscalationCode =
  | "eligible"
  | "already_escalated"
  | "action_taken"
  | "waiting"
  | "not_your_report"
  | "not_found";

export type EscalationCheck = {
  code: EscalationCode;
  eligible: boolean;
  /** Human-readable verification result shown to the student. */
  message: string;
  waitingDays: number;
  requiredDays: number;
  eligibleFrom: Date;
  actionTaken: boolean;
  actionEvidence: string[];
  existing?: typeof escalations.$inferSelect;
};

const DAY = 24 * 60 * 60 * 1000;

function reference(id: number) {
  return `KP-ESC-${String(id).padStart(4, "0")}`;
}

/**
 * Verify a report before it may reach the CEO's Office.
 * A report qualifies only when it has had NO action (still "open", no status
 * change, no official reply) AND the waiting period has passed.
 */
export async function checkEscalation(postId: number, user: SafeUser): Promise<EscalationCheck> {
  const post = await db.query.posts.findFirst({ where: eq(posts.id, postId) });
  if (!post) {
    return {
      code: "not_found", eligible: false, message: "This report no longer exists.",
      waitingDays: 0, requiredDays: ESCALATION_WAIT_DAYS, eligibleFrom: new Date(), actionTaken: false, actionEvidence: [],
    };
  }

  const existing = await db.query.escalations.findFirst({ where: eq(escalations.postId, postId) });
  const requiredDays = post.type === "issue" && post.priority === "high" ? ESCALATION_WAIT_DAYS_HIGH : ESCALATION_WAIT_DAYS;
  const eligibleFrom = new Date(post.createdAt.getTime() + requiredDays * DAY);
  const waitingDays = Math.floor((Date.now() - post.createdAt.getTime()) / DAY);

  // Evidence that the college HAS acted — blocks escalation.
  const actionEvidence: string[] = [];
  if (post.status !== "open") actionEvidence.push(`Status is already "${post.status.replace("_", " ")}"`);
  if (post.adminNote) actionEvidence.push("The college office posted an official note");
  const [history] = await db
    .select({
      statusChanges: sql<number>`count(*) filter (where action = 'status_changed')::int`,
      officialReplies: sql<number>`count(*) filter (where action = 'note_updated' or action = 'claim_approved')::int`,
      lastActivity: sql<Date>`max(created_at)`,
    })
    .from(activity)
    .where(eq(activity.postId, postId));
  if ((history?.statusChanges ?? 0) > 0) actionEvidence.push(`${history?.statusChanges} status update(s) by the office`);
  const officialComments = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(comments)
    .where(and(eq(comments.postId, postId), eq(comments.isOfficial, true)));
  if ((officialComments[0]?.count ?? 0) > 0) actionEvidence.push("An official reply was posted on the report");
  const actionTaken = actionEvidence.length > 0;

  const isAdmin = user.role === "admin";
  const base = { waitingDays, requiredDays, eligibleFrom, actionTaken, actionEvidence, existing };

  if (existing) {
    return {
      ...base,
      code: "already_escalated",
      eligible: false,
      message: `This report was already escalated to the CEO's Office on ${formatDate(existing.createdAt)} under reference ${existing.reference}. You cannot escalate it twice.`,
    };
  }
  if (actionTaken) {
    return {
      ...base,
      code: "action_taken",
      eligible: false,
      message: `Verification failed: the college has already acted on this report (${actionEvidence.join("; ").toLowerCase()}). Escalation is only for reports with no action taken.`,
    };
  }
  if (!isAdmin && post.authorId !== user.id) {
    return {
      ...base,
      code: "not_your_report",
      eligible: false,
      message: "Only the person who submitted this report (or a campus admin) can escalate it.",
    };
  }
  // Admins may escalate immediately on the student's behalf after verifying inaction.
  if (!isAdmin && Date.now() < eligibleFrom.getTime()) {
    return {
      ...base,
      code: "waiting",
      eligible: false,
      message: `Verification pending: the report must stay without action for ${requiredDays} day${requiredDays > 1 ? "s" : ""}. You can escalate from ${formatDate(eligibleFrom)} (in ${Math.ceil((eligibleFrom.getTime() - Date.now()) / DAY)} day(s)).`,
    };
  }
  return {
    ...base,
    code: "eligible",
    eligible: true,
    message: `Verification passed: no action has been taken for ${waitingDays} day(s) and the report is still open. You may now contact the CEO's Office.`,
  };
}

/** Create a verified escalation and log it on the report timeline. */
export async function createEscalation(postId: number, user: SafeUser, reason: string) {
  const check = await checkEscalation(postId, user);
  if (!check.eligible) return { ok: false as const, check };

  const post = await db.query.posts.findFirst({ where: eq(posts.id, postId) });
  if (!post) return { ok: false as const, check };

  // Allocate the row id first so the human reference (KP-ESC-0001) is final on insert.
  const seq = await db.execute<{ next_id: string | number }>(
    sql`select nextval(pg_get_serial_sequence('escalations','id')) as next_id`,
  );
  const id = Number(seq.rows[0]?.next_id);
  if (!Number.isFinite(id)) throw new Error("Could not allocate an escalation reference.");

  const [updated] = await db
    .insert(escalations)
    .values({
      id,
      reference: reference(id),
      postId,
      requesterId: user.id,
      reason,
      waitingDays: check.waitingDays,
      upvoteCount: post.upvoteCount,
      postStatus: post.status,
    })
    .returning();

  await db.insert(activity).values({
    postId,
    actorId: user.id,
    action: "escalated_to_ceo",
    note: `${updated.reference}: escalated to the CEO's Office after ${updated.waitingDays} day(s) without action.`,
  });

  return { ok: true as const, check, escalation: updated };
}

export async function listEscalations(status?: string) {
  const rows = await db
    .select({
      id: escalations.id,
      reference: escalations.reference,
      postId: escalations.postId,
      postTitle: posts.title,
      postType: posts.type,
      location: posts.location,
      postStatus: posts.status,
      status: escalations.status,
      reason: escalations.reason,
      waitingDays: escalations.waitingDays,
      upvoteCount: escalations.upvoteCount,
      requesterName: users.name,
      createdAt: escalations.createdAt,
      handledAt: escalations.handledAt,
      handledNote: escalations.handledNote,
    })
    .from(escalations)
    .innerJoin(posts, eq(posts.id, escalations.postId))
    .innerJoin(users, eq(users.id, escalations.requesterId))
    .orderBy(asc(escalations.status), sql`${escalations.createdAt} desc`)
    .limit(100);
  return status ? rows.filter((r) => r.status === status) : rows;
}

/** Build the message the student's email app sends to the CEO's Office. */
export function escalationEmail(p: { reference: string; title: string; location: string; createdAt: Date; reason: string; waitingDays: number; upvotes: number; postId: number }) {
  const subject = `Escalation ${p.reference}: No action on KPRIET campus report`;
  const body = [
    "Respected Sir/Madam,",
    "",
    `I am escalating the following KPRIET Smart Campus report because no action has been taken for ${p.waitingDays} day(s).`,
    "",
    `Reference: ${p.reference}`,
    `Report: ${p.title}`,
    `Campus location: ${p.location}`,
    `Reported on: ${formatDate(p.createdAt)}`,
    `Community upvotes: ${p.upvotes}`,
    `Portal link: /posts/${p.postId}`,
    "",
    "Reason:",
    p.reason,
    "",
    "Kindly look into this and advise the concerned department.",
    "",
    "Thank you,",
    "KPRIET student/staff",
  ].join("\n");
  return { to: COLLEGE_CONTACTS.ceoOffice.email, subject, body };
}
