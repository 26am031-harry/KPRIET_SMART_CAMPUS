import { AuthError } from "@/lib/auth";
import { MAX_PHOTO_BYTES } from "@/lib/photo-config";

/** Check actual file signatures; never trust the browser-supplied file type. */
export async function validatePhoto(file: File) {
  if (!file.size || file.size > MAX_PHOTO_BYTES) {
    throw new AuthError("Please use a photo smaller than 5 MB.", 413);
  }

  const bytes = Buffer.from(await file.arrayBuffer());
  let contentType: string | null = null;
  if (bytes.length > 12 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
    contentType = "image/jpeg";
  } else if (bytes.length > 24 && bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) {
    contentType = "image/png";
  } else if (bytes.length > 12 && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP") {
    contentType = "image/webp";
  }

  if (!contentType) {
    throw new AuthError("That file is not a supported photo. Please choose a JPEG, PNG or WebP image.", 400);
  }

  return { contentType, data: bytes.toString("base64"), byteSize: bytes.length };
}
