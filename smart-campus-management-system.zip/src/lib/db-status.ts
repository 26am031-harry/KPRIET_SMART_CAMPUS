import { probeDatabase, isDbConfigured } from "@/db";

export type DbStatus = { ok: boolean; configured: boolean; message?: string };

let cachedAt = 0;
let cached: DbStatus | null = null;
const TTL_MS = 15_000;

/** Memoized, short-timeout database probe so a dead DB can't hang every page forever. */
export async function getDbStatus(): Promise<DbStatus> {
  const now = Date.now();
  if (cached && now - cachedAt < TTL_MS) return cached;
  if (!isDbConfigured()) {
    cached = { ok: false, configured: false, message: "DATABASE_URL is not set." };
    cachedAt = now;
    return cached;
  }
  try {
    const result = await probeDatabase();
    cached = { ok: result.ok, configured: true, message: result.message };
  } catch (err) {
    cached = { ok: false, configured: true, message: err instanceof Error ? err.message : String(err) };
  }
  cachedAt = now;
  return cached;
}

/** Clear the memo (e.g. after a restart or a retry). */
export function resetDbStatusCache() {
  cached = null;
  cachedAt = 0;
}
