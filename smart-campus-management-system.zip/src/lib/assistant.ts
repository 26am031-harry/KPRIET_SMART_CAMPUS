import { and, desc, inArray, ne } from "drizzle-orm";
import { db } from "@/db";
import { posts, type PostType } from "@/db/schema";
import type { SafeUser } from "@/lib/auth";
import { CAMPUS_LOCATIONS, LOCATION_ALIASES, LOCATION_GROUPS, STATUS_META, formatClass } from "@/lib/constants";
import { timeAgo } from "@/lib/utils";

export type AssistantMatch = {
  id: number;
  type: PostType;
  title: string;
  location: string;
  locationDetail: string | null;
  status: string;
  statusLabel: string;
  imageUrl: string | null;
  when: string;
  reporterName: string | null;
  reporterClass: string | null;
  reporterPhone: string | null;
  reporterEmail: string | null;
};

export type AssistantReply = { reply: string; matches: AssistantMatch[]; suggestions: string[] };

/** Groups of words that mean the same thing for lost & found searches. */
const CONCEPTS: string[][] = [
  ["phone", "mobile", "cellphone", "iphone", "smartphone", "android", "samsung", "redmi", "oneplus"],
  ["headphone", "headset", "earphone", "earbud", "airpod", "earpod", "buds", "sony", "boat"],
  ["charger", "cable", "adapter", "powerbank", "power bank"],
  ["laptop", "macbook", "dell", "hp laptop", "lenovo"],
  ["calculator", "calci", "casio", "scientific calculator"],
  ["watch", "smartwatch", "band"],
  ["bottle", "flask", "tumbler", "sipper", "water bottle"],
  ["id", "id card", "identity", "lanyard", "idcard", "student card"],
  ["key", "keychain", "carabiner", "bike key"],
  ["bag", "backpack", "handbag", "pouch", "school bag"],
  ["wallet", "purse", "money", "cash", "bus pass"],
  ["book", "textbook", "notes", "notebook", "record", "observation"],
  ["umbrella"],
  ["jacket", "hoodie", "sweater", "coat", "sweatshirt"],
  ["spectacles", "glasses", "specs", "sunglasses"],
  ["ring", "chain", "bracelet", "earring", "jewel", "jewelry", "jewellery", "anklet"],
];

const COLORS = ["black", "white", "blue", "red", "green", "grey", "gray", "brown", "pink", "yellow", "silver", "gold", "orange", "purple", "violet"];

const STOPWORDS = new Set(
  "i me my mine we our you your he she it its they them a an the is am are was were be been being have has had do does did of at in on to for from with near by and or but so if then that this these those there here what which who whom where when why how any some someone somebody anyone anything something can could would should will shall may might must please help find search look looking lost lose losing missing misplaced found find finding left leave dropped drop item items thing things report reported reports campus kpriet college today yesterday morning evening afternoon night tell know about see seen hi hello hey vanakkam ok okay thanks thank just also very really one got get".split(
    " ",
  ),
);

const term = (t: string) => new RegExp(`\\b${t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(s|es)?\\b`, "i");
const has = (text: string, t: string) => term(t).test(text);

function detectLocations(text: string) {
  const found = new Set<string>();
  for (const loc of CAMPUS_LOCATIONS) {
    if (!loc.includes("Classrooms") && text.includes(loc.toLowerCase())) found.add(loc);
  }
  for (const [loc, aliases] of Object.entries(LOCATION_ALIASES)) {
    if (aliases.some((a) => has(text, a))) found.add(loc);
  }
  const block = text.match(/\b([abcd])\s*-?\s*block\b|\bblock\s*-?\s*([abcd])\b/i);
  const floor = text.match(/\b(ground|first|1st|second|2nd|third|3rd)\s*floor\b/i);
  const blockName = block ? `${(block[1] ?? block[2]).toUpperCase()} Block` : null;
  const floorName = floor
    ? ({ ground: "Ground Floor", first: "1st Floor", "1st": "1st Floor", second: "2nd Floor", "2nd": "2nd Floor", third: "3rd Floor", "3rd": "3rd Floor" } as Record<string, string>)[floor[1].toLowerCase()]
    : null;
  return { places: [...found], blockName, floorName };
}

function stripPlaceWords(text: string) {
  let t = text;
  for (const aliases of Object.values(LOCATION_ALIASES)) for (const a of aliases) t = t.replace(term(a), " ");
  return t.replace(/\b[abcd]\s*-?\s*block\b|\bblock\s*-?\s*[abcd]\b|\b(ground|first|1st|second|2nd|third|3rd)\s*floor\b|\bclass ?rooms?\b|\bhall\b/gi, " ");
}

const SUGGESTIONS = [
  "I lost my headphones in the library",
  "Was any water bottle found at the Gym?",
  "What was found at Raagam Hall?",
  "How do I report a lost item?",
];

export async function askAssistant(message: string, viewer: SafeUser | null): Promise<AssistantReply> {
  const text = message.toLowerCase().replace(/[^\p{L}\p{N}\s-]/gu, " ").replace(/\s+/g, " ").trim();
  if (!text) return { reply: "Please tell me what you lost or found, and where.", matches: [], suggestions: SUGGESTIONS };

  // ---- Simple intents ----
  if (/\b(how|where)\b.*\b(report|submit|post|add)\b/.test(text)) {
    return {
      reply:
        "To report an item, tap the Report button at the top, choose Lost Item or Found Item, take or upload a photo, pick the KPRIET location such as Central Library or B Block 2nd floor, and fill in your name, mobile number, year and section. The campus community and admins will see it right away.",
      matches: [],
      suggestions: ["I lost my wallet at Saaral Bakery", "Show items found today"],
    };
  }
  if (/\bhow\b.*\b(claim|get (it|my item) back|collect)\b/.test(text)) {
    return {
      reply:
        "To claim an item, open the found-item report and tap Claim this item. Describe details only the owner would know, like stickers, scratches or contents. A campus admin verifies your claim, and you can also call the finder using the contact details on the report after signing in.",
      matches: [],
      suggestions: ["Show items found today", ...SUGGESTIONS.slice(0, 2)],
    };
  }
  if (/\b(what|which)\b.*\b(location|places)\b|\blist (of )?(locations|places)\b/.test(text)) {
    return {
      reply: `You can report from these KPRIET places: ${LOCATION_GROUPS.slice(0, 3)
        .map((g) => g.locations.join(", "))
        .join("; ")}, and classrooms on all four floors of A, B, C and D blocks.`,
      matches: [],
      suggestions: SUGGESTIONS,
    };
  }
  if (/\bmy (reports?|posts?|items?)\b|\bstatus of my\b/.test(text)) {
    if (!viewer) return { reply: "Please sign in first, then I can tell you the status of your reports.", matches: [], suggestions: SUGGESTIONS };
  }

  const greetingOnly = /^(hi|hello|hey|vanakkam|good (morning|afternoon|evening)|help|what can you do)( there)?$/.test(text);
  if (greetingOnly) {
    return {
      reply:
        "Vanakkam! I'm the KPRIET Lost and Found assistant. Tell me what you lost or found and where — for example, I lost my black headphones in the Central Library — and I'll search all reports for you.",
      matches: [],
      suggestions: SUGGESTIONS,
    };
  }

  // ---- Search intent ----
  // Questions ("what was found at…", "any bottle found?", "show lost items") ask about a report type.
  const isQuestion = /^(what|which|show|list|any|anyone|anybody|is|was|were|has|have|did|are)\b/.test(text);
  const askType: PostType | null = isQuestion ? (/\bfound\b/.test(text) ? "found" : /\b(lost|missing)\b/.test(text) ? "lost" : null) : null;
  const saysLost = !askType && /\b(lost|lose|losing|missing|misplaced|can ?t find|cannot find|left my|dropped my|forgot my)\b/.test(text);
  const saysFound = !askType && /\b(found|picked up|someone left|i have (a|an|someone)|got (a|an))\b/.test(text) && !saysLost;
  const mine = /\bmy (reports?|posts?|items?)\b|\bstatus of my\b/.test(text);
  const recentOnly = /\b(today|recent|latest|new)\b/.test(text);

  const { places, blockName, floorName } = detectLocations(text);
  const remaining = stripPlaceWords(text);

  const concepts: string[][] = CONCEPTS.filter((group) => group.some((t) => has(remaining, t)));
  const used = new Set(concepts.flat().flatMap((t) => t.split(" ")));
  for (const tok of remaining.split(" ")) {
    const w = tok.replace(/(es|s)$/, "");
    if (tok.length >= 3 && !STOPWORDS.has(tok) && !used.has(tok) && !used.has(w) && !/^\d+$/.test(tok)) {
      concepts.push([tok]);
      used.add(tok);
    }
  }
  const colorConcepts = concepts.filter((c) => c.length === 1 && COLORS.includes(c[0]));
  const itemConcepts = concepts.filter((c) => !colorConcepts.includes(c));

  if (!mine && itemConcepts.length === 0 && colorConcepts.length === 0 && places.length === 0 && !blockName && !recentOnly) {
    return {
      reply: "Could you tell me a bit more? Say what the item is, its colour, and where you lost or found it — for example, a blue water bottle at the Gym.",
      matches: [],
      suggestions: SUGGESTIONS,
    };
  }

  // Lost → look for "found" reports first; Found → look for owners' "lost" reports.
  const preferred: PostType[] = saysLost ? ["found"] : saysFound ? ["lost"] : ["found", "lost"];

  const rows = await db
    .select()
    .from(posts)
    .where(and(inArray(posts.type, ["lost", "found"]), ne(posts.status, "closed")))
    .orderBy(desc(posts.createdAt))
    .limit(300);

  const scored = rows
    .filter((p) => (mine ? p.authorId === viewer?.id : true))
    .filter((p) => (askType ? p.type === askType : true))
    .map((p) => {
      const title = p.title.toLowerCase();
      const body = `${p.description} ${p.category}`.toLowerCase();
      let score = 0;
      let itemHits = 0;
      for (const c of itemConcepts) {
        if (c.some((t) => has(title, t))) { score += 4; itemHits++; }
        else if (c.some((t) => has(body, t))) { score += 2; itemHits++; }
      }
      for (const c of colorConcepts) if (has(`${title} ${body}`, c[0])) score += 2;
      if (places.includes(p.location)) score += 3;
      if (blockName && p.location.startsWith(blockName)) score += floorName && p.location.includes(floorName) ? 3 : 2;
      if (preferred.includes(p.type)) score += 1;
      if (recentOnly && Date.now() - p.createdAt.getTime() < 36 * 3600 * 1000) score += 2;
      if (mine) score += 5;
      // If the user named an item, require at least one item word to match.
      const ok = itemConcepts.length === 0 || itemHits > 0;
      return { p, score: ok ? score : 0 };
    })
    .filter((s) => s.score >= 3)
    .sort((a, b) => b.score - a.score || b.p.createdAt.getTime() - a.p.createdAt.getTime())
    .slice(0, 4);

  const matches: AssistantMatch[] = scored.map(({ p }) => ({
    id: p.id,
    type: p.type,
    title: p.title,
    location: p.location,
    locationDetail: p.locationDetail,
    status: p.status,
    statusLabel: STATUS_META[p.status].label,
    imageUrl: p.imageUrl,
    when: timeAgo(p.createdAt),
    reporterName: p.reporterName,
    reporterClass: formatClass(p),
    reporterPhone: viewer ? p.reporterPhone : null,
    reporterEmail: viewer ? p.reporterEmail : null,
  }));

  const reply =
    (await llmReply(message, matches, !!viewer, saysLost)) ?? templateReply(matches, !!viewer, saysLost, saysFound, places, blockName, askType);
  return {
    reply,
    matches,
    suggestions: matches.length ? ["How do I claim an item?", "Show items found today"] : ["How do I report a lost item?", ...SUGGESTIONS.slice(1, 3)],
  };
}

function describe(x: AssistantMatch, i: number) {
  const by = x.reporterName ? ` by ${x.reporterName}${x.reporterClass ? `, ${x.reporterClass}` : ""}` : "";
  return `${i + 1}. ${x.type === "found" ? "Found" : "Lost"}: ${x.title} at ${x.location}${x.locationDetail ? `, ${x.locationDetail}` : ""}, reported ${x.when}${by}. Status: ${x.statusLabel}.`;
}

function templateReply(
  m: AssistantMatch[],
  signedIn: boolean,
  saysLost: boolean,
  saysFound: boolean,
  places: string[],
  blockName: string | null,
  askType: PostType | null,
) {
  const where = places[0] ?? blockName;
  const signIn = signedIn ? "" : " Sign in to see their phone number.";
  if (m.length === 0 && askType) {
    return `There are no ${askType} item reports${where ? ` at ${where}` : ""} matching that right now. Try another place or item name.`;
  }
  // Owner is searching, but only other people's *lost* reports match.
  if (saysLost && m.length > 0 && m.every((x) => x.type === "lost")) {
    return `Nobody has reported finding it yet. I did see a similar lost report: ${m
      .slice(0, 2)
      .map(describe)
      .join(" ")} If this is your own report, keep an eye on it. Otherwise, submit a Lost Item report with a photo so finders can contact you.${signIn}`;
  }
  if (m.length === 0) {
    if (saysLost) {
      return `I couldn't find a matching found-item report${where ? ` near ${where}` : ""} yet. Please submit a Lost Item report with a photo and your contact details, so the finder can reach you. Also check with the counter or security desk nearby.`;
    }
    if (saysFound) {
      return "Nobody has reported losing something like that yet. Thank you for helping! Please submit a Found Item report with a photo so the owner can find it.";
    }
    return `I couldn't find any matching lost or found reports${where ? ` at ${where}` : ""}. Try different words, like the colour or brand.`;
  }
  const shown = saysLost ? m.filter((x) => x.type === "found") : m;
  const intro = saysLost
    ? `Good news! I found ${shown.length} found-item report${shown.length > 1 ? "s" : ""} that may match what you lost.`
    : saysFound && shown[0]?.type === "lost"
      ? `Great — someone is looking for that! I found ${shown.length} matching lost report${shown.length > 1 ? "s" : ""}.`
      : `I found ${shown.length} matching report${shown.length > 1 ? "s" : ""}.`;
  const lines = shown.slice(0, 3).map(describe);
  const next =
    shown[0].type === "found" && shown[0].status === "open"
      ? " Open the report and tap Claim this item, or contact the finder directly."
      : shown[0].type === "lost" && saysFound
        ? " Please contact the owner or submit a Found Item report."
        : " Open a report to see full details and photos.";
  return `${intro} ${lines.join(" ")}${next}${signIn}`;
}

/** Optional: if an OpenAI key is configured, phrase the answer with an LLM (grounded in matches only). */
async function llmReply(question: string, matches: AssistantMatch[], signedIn: boolean, saysLost: boolean) {
  const key = process.env.OPENAI_API_KEY;
  if (!key) return null;
  try {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      signal: AbortSignal.timeout(8000),
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        temperature: 0.3,
        max_tokens: 220,
        messages: [
          {
            role: "system",
            content:
              "You are the friendly voice assistant of the KPR Institute of Engineering and Technology (KPRIET) Lost & Found portal. Answer in under 90 words, in plain spoken English suitable for text-to-speech (no markdown, no emojis). Only use the reports provided; never invent items. Mention item, place, when, reporter name/class and status. If no reports match, suggest submitting a report with a photo." +
              (signedIn ? "" : " The user is not signed in, so do not give phone numbers; tell them to sign in to see contact details."),
          },
          { role: "user", content: `Question: ${question}\nUser is ${saysLost ? "looking for a lost item" : "asking"}.\nMatching reports JSON: ${JSON.stringify(matches)}` },
        ],
      }),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    return data.choices?.[0]?.message?.content?.trim() || null;
  } catch {
    return null;
  }
}
