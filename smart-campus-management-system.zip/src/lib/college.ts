export const COLLEGE = {
  name: "KPR Institute of Engineering and Technology",
  shortName: "KPRIET",
  location: "Arasur, Coimbatore",
  emailDomain: "kpriet.ac.in",
  campusImage: "/images/kpriet-campus.jpg",
  photoSource: "https://commons.wikimedia.org/wiki/File:KPRIET.jpg",
  photoAuthor: "KPRIET / Kprient",
  photoLicense: "https://creativecommons.org/licenses/by-sa/4.0/",
  /** KPRIET campus, Avinashi Road, Arasur (OpenStreetMap). */
  center: { lat: 11.0764689, lng: 77.1420187 },
  address: "KPR Knowledge Campus, Avinashi Road, Arasur, Coimbatore – 641 407, Tamil Nadu",
} as const;

/** Verified contacts published by the college (kpriet.ac.in / AICTE disclosure). */
export const COLLEGE_CONTACTS = {
  office: { label: "College Office", phone: "0422 2635600", tel: "+914222635600", email: "info@kpriet.ac.in" },
  principal: { label: "Principal's Office", phone: "0422 2635600", tel: "+914222635600", email: "principal@kpriet.ac.in" },
  helpline: { label: "Admissions Helpline", phone: "+91 75488 88444", tel: "+917548888444", email: "admission@kpriet.ac.in" },
  ceoOffice: {
    label: "CEO's Office — KPR Institutions",
    phone: "0422 2635600 (College Office, ask for the CEO's Office)",
    tel: "+914222635600",
    email: "info@kpriet.ac.in",
    note: "Escalations are logged with a reference number and routed to the CEO's Office through the College Office.",
  },
  hours: "Mon – Fri, 9:00 am – 6:00 pm",
  fax: "0422 2635666",
} as const;

/** Days a report must wait with no action before it can be escalated. */
export const ESCALATION_WAIT_DAYS = Number(process.env.ESCALATION_WAIT_DAYS ?? 3);
export const ESCALATION_WAIT_DAYS_HIGH = Number(process.env.ESCALATION_WAIT_DAYS_HIGH ?? 1);

/** Rough check that a GPS pin is on/near the KPRIET campus (within ~3 km). */
export function isNearCampus(lat: number, lng: number) {
  return Math.abs(lat - COLLEGE.center.lat) < 0.03 && Math.abs(lng - COLLEGE.center.lng) < 0.03;
}

/** This is a single-college portal; new accounts use the college email domain. */
export function isCollegeEmail(email: string) {
  const domain = email.trim().toLowerCase().split("@")[1];
  return !!domain && (domain === COLLEGE.emailDomain || domain.endsWith(`.${COLLEGE.emailDomain}`));
}
