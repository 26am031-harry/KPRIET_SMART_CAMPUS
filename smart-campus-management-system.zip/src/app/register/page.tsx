import { Suspense } from "react";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/AuthForm";
import { ExitArrow } from "@/components/ExitArrow";
import { getCurrentUser } from "@/lib/auth";

export default async function RegisterPage() {
  const user = await getCurrentUser();
  if (user) redirect("/");
  return (
    <Suspense>
      <div className="space-y-4"><ExitArrow href="/" label="Exit registration" /></div>
      <AuthForm mode="register" />
    </Suspense>
  );
}
