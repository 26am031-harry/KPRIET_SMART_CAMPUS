import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Navbar } from "@/components/Navbar";
import { VoiceAssistant } from "@/components/VoiceAssistant";
import { SupportDock } from "@/components/SupportDock";
import { CREATOR } from "@/lib/creator";
import { ensureSeeded } from "@/db/seed";
import { COLLEGE, COLLEGE_CONTACTS } from "@/lib/college";
import { getDbStatus } from "@/lib/db-status";
import { SetupNotice } from "@/components/SetupNotice";

export const metadata: Metadata = {
  title: "KPRIET Smart Campus — Issues & Lost-and-Found",
  description: `The Smart Campus Issue & Lost-and-Found Portal for ${COLLEGE.name}, ${COLLEGE.location}. Report items, take photos, and track campus maintenance updates.`,
};

export const dynamic = "force-dynamic";

export default async function RootLayout({ children }: { children: ReactNode }) {
  // Never block or crash the page on database trouble — the site stays up with a notice.
  const dbStatus = await getDbStatus();
  if (dbStatus.ok) await ensureSeeded();
  return (
    <html lang="en">
      <body className="text-slate-900 antialiased">
        <Navbar />
        <main className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6">
          {!dbStatus.ok && <SetupNotice message={dbStatus.message} />}
          {children}
        </main>
        <footer className="mt-16 border-t border-white/10 bg-slate-950/70 pb-36 backdrop-blur sm:pb-28">
          <div className="mx-auto flex max-w-7xl flex-col justify-between gap-8 px-4 py-8 text-xs text-slate-400 lg:flex-row sm:px-6">
            {/* Left side bottom: COLLEGE MANAGEMENT · ENQUIRIES & HELPLINE */}
            <div className="w-full max-w-2xl rounded-2xl border border-white/10 bg-white/5 p-5 text-left shadow-lg shadow-black/20">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-3">
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-wider text-slate-200">
                    College management · enquiries &amp; helpline
                  </p>
                  <p className="mt-0.5 text-xs font-semibold text-slate-100">{COLLEGE.name}</p>
                </div>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="/images/kpriet-logo-full.png"
                  alt="KPR Institute of Engineering and Technology logo"
                  className="h-7 w-auto rounded bg-[#fff] px-2 py-0.5"
                />
              </div>

              <p className="mt-2.5 text-[11px] leading-relaxed text-slate-400">{COLLEGE.address}</p>

              <ul className="mt-3 grid gap-2 sm:grid-cols-2 text-[11px]">
                {[COLLEGE_CONTACTS.office, COLLEGE_CONTACTS.principal, COLLEGE_CONTACTS.helpline].map((c) => (
                  <li key={c.label} className="rounded-lg border border-white/5 bg-black/20 p-2.5">
                    <span className="block font-semibold text-slate-200">{c.label}</span>
                    <a href={`tel:${c.tel}`} className="mt-0.5 block font-medium text-indigo-300 hover:underline">
                      📞 {c.phone}
                    </a>
                    <a href={`mailto:${c.email}`} className="block break-all text-indigo-300 hover:underline">
                      ✉️ {c.email}
                    </a>
                  </li>
                ))}
              </ul>

              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-white/10 pt-3 text-[10px] text-slate-400">
                <span>Office hours: {COLLEGE_CONTACTS.hours} · Fax: {COLLEGE_CONTACTS.fax}</span>
                <span>© {new Date().getFullYear()} KPRIET campus community project</span>
              </div>
              <p className="mt-1.5 text-[10px] leading-relaxed text-slate-500">
                Student grievances not acted upon can be escalated to the {COLLEGE_CONTACTS.ceoOffice.label} from the report page after verification.
              </p>
            </div>

            {/* Right side bottom: Website Issue Reporting & Portal Info */}
            <div className="flex w-full flex-col justify-between gap-6 lg:max-w-sm lg:text-right">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-left lg:text-right">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Report a website issue</p>
                <p className="mt-1 text-sm font-semibold text-slate-100">
                  Name: {CREATOR.name}
                </p>
                <p className="mt-0.5 text-xs text-slate-300">
                  Contact no:{" "}
                  <a href={`tel:${CREATOR.tel}`} className="font-semibold text-indigo-300 hover:underline">
                    {CREATOR.phone}
                  </a>
                </p>
                <p className="mt-0.5 break-all text-xs text-slate-300">
                  Email:{" "}
                  <a href={`mailto:${CREATOR.email}`} className="font-semibold text-indigo-300 hover:underline">
                    {CREATOR.email}
                  </a>
                </p>
                <p className="mt-2 text-[11px] text-slate-400">
                  Found a bug or issue in the portal? Contact the creator directly via phone or WhatsApp.
                </p>
              </div>

              <div className="space-y-2 text-[11px] text-slate-400">
                <p>For KPRIET students &amp; staff. Demo logins are available on the sign-in page.</p>
                <p className="text-[10px] text-slate-500">
                  Campus photo:{" "}
                  <a href={COLLEGE.photoSource} target="_blank" rel="noreferrer" className="underline hover:text-slate-400">
                    {COLLEGE.photoAuthor}
                  </a>{" "}
                  ·{" "}
                  <a href={COLLEGE.photoLicense} target="_blank" rel="noreferrer" className="underline hover:text-slate-400">
                    CC BY-SA 4.0
                  </a>{" "}
                  · Cropped with a visual overlay.
                </p>
              </div>
            </div>
          </div>
        </footer>
        <SupportDock />
        <VoiceAssistant />
      </body>
    </html>
  );
}
