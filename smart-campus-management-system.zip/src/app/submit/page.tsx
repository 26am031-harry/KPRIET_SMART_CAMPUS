import { redirect } from "next/navigation";
import { ExitArrow } from "@/components/ExitArrow";
import { SubmitForm } from "@/components/SubmitForm";
import { getCurrentUser } from "@/lib/auth";
import type { PostType } from "@/db/schema";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function SubmitPage({ searchParams }: { searchParams: SearchParams }) {
  const sp = await searchParams;
  const rawType = Array.isArray(sp.type) ? sp.type[0] : sp.type;
  const user = await getCurrentUser();
  if (!user) {
    redirect(`/login?next=${encodeURIComponent(`/submit${rawType ? `?type=${rawType}` : ""}`)}`);
  }
  const initialType: PostType = rawType === "found" || rawType === "issue" ? rawType : "lost";

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <ExitArrow href="/browse" label="Exit without submitting" />
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Submit a report</h1>
        <p className="text-sm text-slate-500">
          Posting as <span className="font-medium text-slate-700">{user.name}</span> for the KPRIET campus. Take a photo or upload one to help others identify your item.
        </p>
      </div>
      <SubmitForm initialType={initialType} reporter={{ name: user.name, email: user.email, department: user.department }} />
    </div>
  );
}
