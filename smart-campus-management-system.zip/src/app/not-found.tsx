import Link from "next/link";
import { ExitArrow } from "@/components/ExitArrow";

export default function NotFound() {
  return (
    <div className="card mx-auto max-w-md p-10 text-center">
      <span className="text-4xl">🧭</span>
      <h1 className="mt-3 text-xl font-bold text-slate-900">Page not found</h1>
      <p className="mt-1 text-sm text-slate-500">That report may have been deleted or the link is wrong.</p>
      <Link href="/browse" className="btn-primary mt-5">Browse reports</Link>
      <div className="mt-3 flex justify-center"><ExitArrow href="/" label="Exit to dashboard" /></div>
    </div>
  );
}
