import { and, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { posts, claims, activity } from "@/db/schema";
import { errorResponse, requireAdmin } from "@/lib/auth";
import { parseId } from "@/lib/route-params";

type Ctx = { params: Promise<{ id: string }> };

/** Admin: approve or reject a claim. Approving marks the post as claimed and rejects the other pending claims. */
export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const admin = await requireAdmin();
    const { id } = await ctx.params;
    const claimId = parseId(id);
    if (!claimId) return Response.json({ error: "Invalid claim id." }, { status: 400 });
    const claim = await db.query.claims.findFirst({ where: eq(claims.id, claimId) });
    if (!claim) return Response.json({ error: "Not found." }, { status: 404 });

    const body = (await req.json().catch(() => ({}))) as { status?: string };
    if (body.status !== "approved" && body.status !== "rejected") {
      return Response.json({ error: "Status must be approved or rejected." }, { status: 400 });
    }

    const [updated] = await db
      .update(claims)
      .set({ status: body.status, reviewedById: admin.id, reviewedAt: new Date() })
      .where(eq(claims.id, claimId))
      .returning();

    if (body.status === "approved") {
      const post = await db.query.posts.findFirst({ where: eq(posts.id, claim.postId) });
      await db
        .update(claims)
        .set({ status: "rejected", reviewedById: admin.id, reviewedAt: new Date() })
        .where(and(eq(claims.postId, claim.postId), ne(claims.id, claimId), eq(claims.status, "pending")));
      await db
        .update(posts)
        .set({ status: "claimed", updatedAt: new Date() })
        .where(eq(posts.id, claim.postId));
      await db.insert(activity).values({
        postId: claim.postId,
        actorId: admin.id,
        action: "claim_approved",
        fromStatus: post?.status ?? null,
        toStatus: "claimed",
      });
    } else {
      await db.insert(activity).values({
        postId: claim.postId,
        actorId: admin.id,
        action: "claim_rejected",
      });
    }

    return Response.json({ claim: updated });
  } catch (err) {
    return errorResponse(err);
  }
}
