import { ensureSeeded } from "@/db/seed";
import { errorResponse, getCurrentUser } from "@/lib/auth";
import { askAssistant } from "@/lib/assistant";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const body = (await req.json().catch(() => ({}))) as { message?: unknown };
    const message = typeof body.message === "string" ? body.message.trim() : "";
    if (!message) return Response.json({ error: "Please ask a question." }, { status: 400 });
    if (message.length > 500) return Response.json({ error: "Please keep your question under 500 characters." }, { status: 400 });
    const viewer = await getCurrentUser();
    return Response.json(await askAssistant(message, viewer));
  } catch (err) {
    return errorResponse(err);
  }
}
