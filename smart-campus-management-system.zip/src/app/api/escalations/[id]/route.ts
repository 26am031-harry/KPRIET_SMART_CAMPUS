import { eq } from "drizzle-orm";
import { db } from "@/db";
import { activity, escalations } from "@/db/schema";
import { errorResponse, requireAdmin } from "@/lib/auth";
import { parseId } from "@/lib/route-params";

type Ctx = { params: Promise<{ id: string }> };

/** Admin: acknowledge or close an escalation to the CEO's Office. */
export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const admin = await requireAdmin();
    const { id } = await ctx.params;
    const escalationId = parseId(id);
    if (!escalationId) return Response.json({ error: "Invalid escalation id." }, { status: 400 });
    const existing = await db.query.escalations.findFirst({ where: eq(escalations.id, escalationId) });
    if (!existing) return Response.json({ error: "Not found." }, { status: 404 });

    const body = (await req.json().catch(() => ({}))) as { status?: string; note?: string };
    if (body.status !== "acknowledged" && body.status !== "closed") {
      return Response.json({ error: "Status must be acknowledged or closed." }, { status: 400 });
    }
    const note = body.note?.trim() ?? "";

    const [updated] = await db
      .update(escalations)
      .set({
        status: body.status,
        handledById: admin.id,
        // Keep the previously saved office note when closing without a new one.
        handledNote: note || existing.handledNote,
        handledAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(escalations.id, escalationId))
      .returning();

    await db.insert(activity).values({
      postId: existing.postId,
      actorId: admin.id,
      action: body.status === "closed" ? "escalation_closed" : "escalation_acknowledged",
      note: `${existing.reference}${note ? `: ${note}` : ""}`,
    });

    return Response.json({ escalation: updated });
  } catch (err) {
    return errorResponse(err);
  }
}
