import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { errorResponse, setSessionCookie, toSafeUser, verifyPassword } from "@/lib/auth";
import { ensureSeeded } from "@/db/seed";

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const body = (await req.json().catch(() => ({}))) as {
      email?: string;
      password?: string;
    };
    const email = body.email?.trim().toLowerCase();
    const password = body.password ?? "";
    if (!email || !password) {
      return Response.json({ error: "Email and password are required." }, { status: 400 });
    }
    const user = await db.query.users.findFirst({ where: eq(users.email, email) });
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return Response.json({ error: "Invalid email or password." }, { status: 401 });
    }
    await setSessionCookie(user.id);
    return Response.json({ user: toSafeUser(user) });
  } catch (err) {
    return errorResponse(err);
  }
}
