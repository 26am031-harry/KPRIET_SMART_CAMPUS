import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { errorResponse, hashPassword, setSessionCookie, toSafeUser } from "@/lib/auth";
import { ensureSeeded } from "@/db/seed";
import { COLLEGE, isCollegeEmail } from "@/lib/college";

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const body = (await req.json().catch(() => ({}))) as {
      name?: string;
      email?: string;
      password?: string;
      department?: string;
      role?: string;
    };
    const name = body.name?.trim();
    const email = body.email?.trim().toLowerCase();
    const password = body.password ?? "";
    if (!name || !email || password.length < 6) {
      return Response.json(
        { error: "Name, email and a password of at least 6 characters are required." },
        { status: 400 },
      );
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      return Response.json({ error: "Please enter a valid email." }, { status: 400 });
    }
    if (!isCollegeEmail(email)) {
      return Response.json(
        { error: `This portal is for KPRIET students and staff. Please register with your @${COLLEGE.emailDomain} college email address.` },
        { status: 400 },
      );
    }
    const existing = await db.query.users.findFirst({ where: eq(users.email, email) });
    if (existing) {
      return Response.json({ error: "An account with this email already exists." }, { status: 409 });
    }
    // Demo convenience: allow self-registering as staff; admin is never self-assignable.
    const role = body.role === "staff" ? "staff" : "student";
    const [user] = await db
      .insert(users)
      .values({
        name,
        email,
        passwordHash: hashPassword(password),
        role,
        department: body.department?.trim() || null,
      })
      .returning();
    await setSessionCookie(user.id);
    return Response.json({ user: toSafeUser(user) }, { status: 201 });
  } catch (err) {
    return errorResponse(err);
  }
}
