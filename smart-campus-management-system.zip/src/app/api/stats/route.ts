import { ensureSeeded } from "@/db/seed";
import { errorResponse } from "@/lib/auth";
import { getStats } from "@/lib/posts";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();
    return Response.json(await getStats());
  } catch (err) {
    return errorResponse(err);
  }
}
