import { eq } from "drizzle-orm";
import { db } from "@/db";
import { photos } from "@/db/schema";
import { errorResponse } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) {
      return new Response("Photo not found", { status: 404 });
    }
    const [photo] = await db.select().from(photos).where(eq(photos.id, id)).limit(1);
    if (!photo) return new Response("Photo not found", { status: 404 });

    const bytes = Buffer.from(photo.data, "base64");
    return new Response(new Uint8Array(bytes), {
      headers: {
        "Content-Type": photo.contentType,
        "Content-Length": String(bytes.length),
        "Content-Disposition": "inline",
        "Cache-Control": "public, max-age=86400",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch (err) {
    return errorResponse(err);
  }
}
