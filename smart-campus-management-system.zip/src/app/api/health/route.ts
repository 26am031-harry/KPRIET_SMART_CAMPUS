import { isDbConfigured, probeDatabase } from "@/db";

export const dynamic = "force-dynamic";

export async function GET() {
  const probe = await probeDatabase();
  if (!probe.ok) {
    const set = isDbConfigured();
    return Response.json(
      {
        ok: false,
        configured: set,
        reason: probe.message ?? (set ? "Database unreachable" : "DATABASE_URL is not set"),
      },
      { status: 503 },
    );
  }
  return Response.json({ ok: true, configured: true, reason: null });
}
