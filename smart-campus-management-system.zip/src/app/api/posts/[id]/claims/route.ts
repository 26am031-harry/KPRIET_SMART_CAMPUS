import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { posts, claims, activity } from "@/db/schema";
import { errorResponse, requireUser } from "@/lib/auth";
import { parseId } from "@/lib/route-params";

type Ctx = { params: Promise<{ id: string }> };

/** Submit a claim ("this is mine" for found items, "I have this" for lost items). */
export async function POST(req: Request, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const postId = parseId(id);
    if (!postId) return Response.json({ error: "Invalid report id." }, { status: 400 });
    const post = await db.query.posts.findFirst({ where: eq(posts.id, postId) });
    if (!post) return Response.json({ error: "Not found." }, { status: 404 });
    if (post.type === "issue") {
      return Response.json({ error: "Maintenance issues cannot be claimed." }, { status: 400 });
    }
    if (post.authorId === user.id) {
      return Response.json({ error: "You cannot claim your own post." }, { status: 400 });
    }
    if (!["open"].includes(post.status)) {
      return Response.json({ error: "This post is no longer accepting claims." }, { status: 400 });
    }
    const body = (await req.json().catch(() => ({}))) as { message?: string };
    const message = body.message?.trim() ?? "";
    if (message.length < 10) {
      return Response.json(
        { error: "Please describe the item in at least 10 characters so we can verify." },
        { status: 400 },
      );
    }
    const existing = await db.query.claims.findFirst({
      where: and(eq(claims.postId, postId), eq(claims.claimantId, user.id), eq(claims.status, "pending")),
    });
    if (existing) {
      return Response.json({ error: "You already have a pending claim on this post." }, { status: 409 });
    }
    const [claim] = await db
      .insert(claims)
      .values({ postId, claimantId: user.id, message })
      .returning();
    await db.insert(activity).values({ postId, actorId: user.id, action: "claim_submitted" });
    return Response.json({ claim }, { status: 201 });
  } catch (err) {
    return errorResponse(err);
  }
}
