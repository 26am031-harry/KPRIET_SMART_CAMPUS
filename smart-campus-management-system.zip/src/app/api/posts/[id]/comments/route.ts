import { eq } from "drizzle-orm";
import { db } from "@/db";
import { posts, comments } from "@/db/schema";
import { errorResponse, requireUser } from "@/lib/auth";
import { parseId } from "@/lib/route-params";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: Request, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const postId = parseId(id);
    if (!postId) return Response.json({ error: "Invalid report id." }, { status: 400 });
    const post = await db.query.posts.findFirst({ where: eq(posts.id, postId) });
    if (!post) return Response.json({ error: "Not found." }, { status: 404 });
    const body = (await req.json().catch(() => ({}))) as { body?: string };
    const text = body.body?.trim() ?? "";
    if (!text) return Response.json({ error: "Comment cannot be empty." }, { status: 400 });
    if (text.length > 2000) return Response.json({ error: "Comment is too long." }, { status: 400 });
    const [comment] = await db
      .insert(comments)
      .values({ postId, authorId: user.id, body: text, isOfficial: user.role === "admin" })
      .returning();
    return Response.json({ comment }, { status: 201 });
  } catch (err) {
    return errorResponse(err);
  }
}
