import { errorResponse, requireUser } from "@/lib/auth";
import { createEscalation } from "@/lib/escalation";
import { parseId } from "@/lib/route-params";

type Ctx = { params: Promise<{ id: string }> };

/** Escalate a report to the CEO's Office — only after verification of inaction. */
export async function POST(req: Request, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const postId = parseId(id);
    if (!postId) return Response.json({ error: "Invalid report id." }, { status: 400 });
    if (!Number.isFinite(postId)) return Response.json({ error: "Invalid report." }, { status: 400 });

    const body = (await req.json().catch(() => ({}))) as { reason?: unknown; confirmed?: unknown };
    const reason = typeof body.reason === "string" ? body.reason.trim() : "";
    if (reason.length < 20 || reason.length > 1500) {
      return Response.json(
        { error: "Please explain in 20–1500 characters why the CEO's Office should look into this." },
        { status: 400 },
      );
    }
    if (body.confirmed !== true) {
      return Response.json({ error: "Please confirm that no action has been taken on this report." }, { status: 400 });
    }

    const result = await createEscalation(postId, user, reason);
    if (!result.ok) {
      return Response.json({ error: result.check.message, code: result.check.code }, { status: 409 });
    }
    return Response.json({ escalation: result.escalation, message: result.check.message }, { status: 201 });
  } catch (err) {
    return errorResponse(err);
  }
}
