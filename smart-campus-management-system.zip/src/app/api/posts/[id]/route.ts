import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { posts, activity, escalations, type PostStatus } from "@/db/schema";
import { errorResponse, getCurrentUser, requireAdmin, requireUser } from "@/lib/auth";
import { STATUSES } from "@/lib/constants";
import { getPostDetail } from "@/lib/posts";
import { parseId } from "@/lib/route-params";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const postId = parseId(id);
    if (!postId) return Response.json({ error: "Invalid report id." }, { status: 400 });
    const viewer = await getCurrentUser();
    const post = await getPostDetail(postId, viewer?.id);
    if (!post) return Response.json({ error: "Not found." }, { status: 404 });
    return Response.json({ post });
  } catch (err) {
    return errorResponse(err);
  }
}

/** Admin: update status, priority, admin note. */
export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const admin = await requireAdmin();
    const { id } = await ctx.params;
    const postId = parseId(id);
    if (!postId) return Response.json({ error: "Invalid report id." }, { status: 400 });
    const existing = await db.query.posts.findFirst({ where: eq(posts.id, postId) });
    if (!existing) return Response.json({ error: "Not found." }, { status: 404 });

    const body = (await req.json().catch(() => ({}))) as {
      status?: string;
      priority?: string;
      adminNote?: string;
    };

    const updates: Partial<typeof posts.$inferInsert> = { updatedAt: new Date() };
    let statusChanged = false;

    if (body.status !== undefined) {
      if (!STATUSES.includes(body.status as PostStatus)) {
        return Response.json({ error: "Invalid status." }, { status: 400 });
      }
      if (body.status !== existing.status) {
        updates.status = body.status as PostStatus;
        statusChanged = true;
        updates.resolvedAt = ["resolved", "closed"].includes(body.status) ? new Date() : null;
      }
    }
    if (body.priority !== undefined) {
      if (!["low", "medium", "high"].includes(body.priority)) {
        return Response.json({ error: "Invalid priority." }, { status: 400 });
      }
      updates.priority = body.priority as "low" | "medium" | "high";
    }
    if (body.adminNote !== undefined) {
      updates.adminNote = body.adminNote.trim() || null;
    }

    const [updated] = await db.update(posts).set(updates).where(eq(posts.id, postId)).returning();

    if (statusChanged) {
      await db.insert(activity).values({
        postId,
        actorId: admin.id,
        action: "status_changed",
        fromStatus: existing.status,
        toStatus: updated.status,
        note: body.adminNote?.trim() || null,
      });
    } else if (body.adminNote !== undefined && body.adminNote.trim() !== (existing.adminNote ?? "")) {
      await db.insert(activity).values({
        postId,
        actorId: admin.id,
        action: "note_updated",
        note: body.adminNote.trim() || null,
      });
    }

    return Response.json({ post: updated });
  } catch (err) {
    return errorResponse(err);
  }
}

/** Author or admin can delete. */
export async function DELETE(_req: Request, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const postId = parseId(id);
    if (!postId) return Response.json({ error: "Invalid report id." }, { status: 400 });
    const existing = await db.query.posts.findFirst({ where: eq(posts.id, postId) });
    if (!existing) return Response.json({ error: "Not found." }, { status: 404 });
    if (existing.authorId !== user.id && user.role !== "admin") {
      return Response.json({ error: "You can only delete your own posts." }, { status: 403 });
    }
    // Never silently destroy an in-flight CEO's Office escalation.
    const openEscalation = await db.query.escalations.findFirst({
      where: and(eq(escalations.postId, postId), sql`${escalations.status} != 'closed'`),
    });
    if (openEscalation) {
      return Response.json(
        { error: `This report has an open escalation (${openEscalation.reference}) to the CEO's Office. Close the escalation from the admin dashboard first.` },
        { status: 409 },
      );
    }
    await db.delete(posts).where(eq(posts.id, postId));
    return Response.json({ ok: true });
  } catch (err) {
    return errorResponse(err);
  }
}
