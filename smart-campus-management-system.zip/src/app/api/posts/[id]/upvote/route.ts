import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { posts, upvotes } from "@/db/schema";
import { errorResponse, requireUser } from "@/lib/auth";
import { parseId } from "@/lib/route-params";

type Ctx = { params: Promise<{ id: string }> };

/** Toggle an upvote for the current user. */
export async function POST(_req: Request, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const postId = parseId(id);
    if (!postId) return Response.json({ error: "Invalid report id." }, { status: 400 });
    const post = await db.query.posts.findFirst({ where: eq(posts.id, postId) });
    if (!post) return Response.json({ error: "Not found." }, { status: 404 });

    const existing = await db.query.upvotes.findFirst({
      where: and(eq(upvotes.postId, postId), eq(upvotes.userId, user.id)),
    });

    let upvoted: boolean;
    if (existing) {
      await db.delete(upvotes).where(eq(upvotes.id, existing.id));
      await db
        .update(posts)
        .set({ upvoteCount: sql`greatest(${posts.upvoteCount} - 1, 0)` })
        .where(eq(posts.id, postId));
      upvoted = false;
    } else {
      await db.insert(upvotes).values({ postId, userId: user.id });
      await db
        .update(posts)
        .set({ upvoteCount: sql`${posts.upvoteCount} + 1` })
        .where(eq(posts.id, postId));
      upvoted = true;
    }
    const [{ upvoteCount }] = await db
      .select({ upvoteCount: posts.upvoteCount })
      .from(posts)
      .where(eq(posts.id, postId));
    return Response.json({ upvoted, upvoteCount });
  } catch (err) {
    return errorResponse(err);
  }
}
