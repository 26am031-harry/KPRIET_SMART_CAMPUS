import { eq } from "drizzle-orm";
import { db } from "@/db";
import { posts, activity, photos } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { AuthError, errorResponse, getCurrentUser, requireUser } from "@/lib/auth";
import { CAMPUS_LOCATIONS, DEPARTMENTS, REPORTER_YEARS, SECTIONS, categoriesForType } from "@/lib/constants";
import { listPosts } from "@/lib/posts";
import { MAX_PHOTO_BYTES } from "@/lib/photo-config";
import { validatePhoto } from "@/lib/photos";
import { isNearCampus } from "@/lib/college";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    await ensureSeeded();
    const { searchParams } = new URL(req.url);
    const viewer = await getCurrentUser();
    const items = await listPosts(
      {
        type: searchParams.get("type"),
        status: searchParams.get("status"),
        category: searchParams.get("category"),
        q: searchParams.get("q"),
        sort: searchParams.get("sort"),
        limit: Math.min(Number(searchParams.get("limit") ?? 100) || 100, 200),
      },
      viewer?.id,
    );
    return Response.json({ posts: items });
  } catch (err) {
    return errorResponse(err);
  }
}

export async function POST(req: Request) {
  try {
    const user = await requireUser();
    // Bound the multipart request, including field/header overhead.
    const maxBodyBytes = MAX_PHOTO_BYTES + 128 * 1024;
    if (Number(req.headers.get("content-length")) > maxBodyBytes) {
      throw new AuthError("The photo is too large. Please use a photo smaller than 5 MB.", 413);
    }

    let body: Record<string, unknown>;
    let photo: File | null = null;
    if (req.headers.get("content-type")?.includes("multipart/form-data")) {
      // Read with a limit even when the client uses chunked transfer encoding.
      const reader = req.body?.getReader();
      if (!reader) throw new AuthError("No form data received.", 400);
      const chunks: Uint8Array[] = [];
      let size = 0;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > maxBodyBytes) {
          await reader.cancel();
          throw new AuthError("Please use a photo smaller than 5 MB.", 413);
        }
        chunks.push(value);
      }
      const rawBody = Buffer.concat(chunks);
      const multipart = new Request("http://localhost/form", {
        method: "POST",
        headers: { "content-type": req.headers.get("content-type")! },
        body: new Uint8Array(rawBody),
      });
      let form: FormData;
      try {
        form = await multipart.formData();
      } catch {
        throw new AuthError("Could not read your report. Please try again.", 400);
      }
      body = Object.fromEntries(Array.from(form.entries()).filter(([, value]) => typeof value === "string"));
      const file = form.get("photo");
      if (file instanceof File && file.size > 0) photo = file;
    } else {
      body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    }

    const type = body.type as "lost" | "found" | "issue";
    if (!["lost", "found", "issue"].includes(type)) {
      throw new AuthError("Invalid post type.", 400);
    }
    const title = String(body.title ?? "").trim();
    const description = String(body.description ?? "").trim();
    const category = String(body.category ?? "").trim();
    const location = String(body.location ?? "").trim();
    if (title.length < 4 || title.length > 160) {
      throw new AuthError("Title must be 4–160 characters.", 400);
    }
    if (description.length < 10 || description.length > 10000) {
      throw new AuthError("Please add a description between 10 and 10,000 characters.", 400);
    }
    if (!categoriesForType(type).includes(category)) {
      throw new AuthError("Please pick a valid category.", 400);
    }
    if (!CAMPUS_LOCATIONS.includes(location)) {
      throw new AuthError("Please choose a KPRIET campus location from the list.", 400);
    }
    const locationDetail = String(body.locationDetail ?? "").trim();
    if (locationDetail.length > 120) throw new AuthError("Exact spot must be 120 characters or fewer.", 400);

    // Optional GPS pin (only sent when the reporter explicitly chose to share it)
    let reportLat: number | null = null;
    let reportLng: number | null = null;
    let reportAccuracy: number | null = null;
    if (body.reportLat !== undefined && String(body.reportLat).trim() !== "") {
      const lat = Number(body.reportLat);
      const lng = Number(body.reportLng);
      const acc = Number(body.reportAccuracy);
      if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
        throw new AuthError("The shared GPS location is invalid. Please pin it again.", 400);
      }
      if (!isNearCampus(lat, lng)) {
        throw new AuthError("The pinned location is outside the KPRIET campus. Remove the pin or pin it while on campus.", 400);
      }
      reportLat = lat;
      reportLng = lng;
      reportAccuracy = Number.isFinite(acc) && acc > 0 ? Math.min(acc, 5000) : null;
    }

    // Reporter details
    const reporterName = String(body.reporterName ?? "").trim();
    const reporterPhone = String(body.reporterPhone ?? "").replace(/[\s-]/g, "");
    const reporterEmail = String(body.reporterEmail ?? "").trim().toLowerCase();
    const reporterYear = String(body.reporterYear ?? "").trim();
    const reporterDepartment = String(body.reporterDepartment ?? "").trim();
    const reporterSection = String(body.reporterSection ?? "").trim();
    const isStaff = reporterYear === "Faculty / Staff";
    if (reporterName.length < 2 || reporterName.length > 120) {
      throw new AuthError("Please enter the reporter's full name.", 400);
    }
    if (!/^(\+91)?[6-9]\d{9}$/.test(reporterPhone)) {
      throw new AuthError("Please enter a valid 10-digit mobile number.", 400);
    }
    if (reporterEmail && (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(reporterEmail) || reporterEmail.length > 200)) {
      throw new AuthError("Please enter a valid email address.", 400);
    }
    if (!REPORTER_YEARS.includes(reporterYear)) {
      throw new AuthError("Please select the studying year.", 400);
    }
    if (!DEPARTMENTS.includes(reporterDepartment)) {
      throw new AuthError("Please select the department.", 400);
    }
    if (!isStaff && !SECTIONS.includes(reporterSection)) {
      throw new AuthError("Please select the class section.", 400);
    }
    const priority = ["low", "medium", "high"].includes(String(body.priority))
      ? (body.priority as "low" | "medium" | "high")
      : "medium";
    const imageUrl = String(body.imageUrl ?? "").trim();
    const contactInfo = String(body.contactInfo ?? "").trim();
    if (contactInfo.length > 200) throw new AuthError("Contact info must be 200 characters or fewer.", 400);
    const occurredAtRaw = String(body.occurredAt ?? "").trim();
    const occurredAt = occurredAtRaw && !Number.isNaN(Date.parse(occurredAtRaw)) ? new Date(occurredAtRaw) : null;
    const validatedPhoto = photo ? await validatePhoto(photo) : null;

    const created = await db.transaction(async (tx) => {
      const [post] = await tx
        .insert(posts)
        .values({
          type,
          title,
          description,
          category,
          location,
          priority: type === "issue" ? priority : "medium",
          imageUrl: imageUrl && /^https?:\/\//.test(imageUrl) ? imageUrl : null,
          contactInfo: contactInfo || null,
          locationDetail: locationDetail || null,
          reportLat,
          reportLng,
          reportAccuracy,
          reporterName,
          reporterPhone,
          reporterEmail: reporterEmail || user.email,
          reporterYear,
          reporterDepartment,
          reporterSection: isStaff ? null : reporterSection,
          occurredAt,
          authorId: user.id,
        })
        .returning();

      if (validatedPhoto) {
        const [saved] = await tx
          .insert(photos)
          .values({ postId: post.id, uploaderId: user.id, ...validatedPhoto })
          .returning({ id: photos.id });
        post.imageUrl = `/api/photos/${saved.id}`;
        await tx.update(posts).set({ imageUrl: post.imageUrl }).where(eq(posts.id, post.id));
      }

      await tx.insert(activity).values({ postId: post.id, actorId: user.id, action: "created", toStatus: "open" });
      return post;
    });

    return Response.json({ post: created }, { status: 201 });
  } catch (err) {
    return errorResponse(err);
  }
}
