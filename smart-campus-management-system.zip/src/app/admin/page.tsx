import Link from "next/link";
import { redirect } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { claims } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { getStats, listPosts } from "@/lib/posts";
import { PriorityBadge, TypeBadge } from "@/components/Badges";
import { AdminQuickStatus } from "@/components/AdminQuickStatus";
import { ClaimReviewButtons } from "@/components/PostActions";
import { ExitArrow } from "@/components/ExitArrow";
import { EscalationQueue } from "@/components/EscalationQueue";
import { listEscalations } from "@/lib/escalation";
import { cn, timeAgo } from "@/lib/utils";
import { COLLEGE } from "@/lib/college";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;
const first = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? null;

export default async function AdminPage({ searchParams }: { searchParams: SearchParams }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/admin");
  if (user.role !== "admin") {
    return (
      <div className="mx-auto max-w-lg space-y-4">
      <ExitArrow href="/" label="Exit admin area" />
      <div className="card p-10 text-center">
        <span className="text-4xl">🔒</span>
        <h1 className="mt-3 text-xl font-bold text-slate-900">Admin access required</h1>
        <p className="mt-1 text-sm text-slate-500">
          You&apos;re signed in as <strong>{user.name}</strong> ({user.role}). Sign out and use the admin demo account to see the dashboard.
        </p>
        <Link href="/" className="btn-secondary mt-5">Back to home</Link>
      </div>
      </div>
    );
  }

  const sp = await searchParams;
  const typeFilter = first(sp.type);
  const statusFilter = first(sp.status) ?? "active";

  let stats = { total: 0, lost: 0, found: 0, issues: 0, open: 0, resolved: 0, highPriorityOpen: 0, pendingClaims: 0 };
  let items: Awaited<ReturnType<typeof listPosts>> = [];
  let pendingClaims: { id: number; status: string; post: { id: number; type: "lost"|"found"|"issue"; title: string; location: string }; claimant: { id: number; name: string; email: string }; createdAt: Date; message: string }[] = [];
  let escalations: Awaited<ReturnType<typeof listEscalations>> = [];
  try {
    [stats, items, pendingClaims, escalations] = await Promise.all([
      getStats(),
      listPosts({ type: typeFilter, status: statusFilter === "all" ? null : statusFilter, sort: "top", limit: 200 }, user.id),
      db.query.claims.findMany({
        where: eq(claims.status, "pending"),
        with: { post: true, claimant: { columns: { id: true, name: true, email: true } } },
        orderBy: [desc(claims.createdAt)],
      }),
      listEscalations(),
    ]);
  } catch {
    // DB is down — layout shows the setup notice.
  }

  const tabLink = (params: Record<string, string | null>) => {
    const q = new URLSearchParams();
    const merged = { type: typeFilter, status: statusFilter, ...params };
    for (const [k, v] of Object.entries(merged)) if (v) q.set(k, v);
    return `/admin?${q.toString()}`;
  };

  return (
    <div className="space-y-8">
      <ExitArrow href="/" label="Exit admin area" />
      <div className="relative isolate flex flex-wrap items-end justify-between gap-5 overflow-hidden rounded-2xl bg-slate-950 px-6 py-8 text-white sm:px-8">
        <div className="absolute inset-0 -z-20 bg-cover bg-center" style={{ backgroundImage: `url(${COLLEGE.campusImage})` }} />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-slate-950/95 via-slate-950/80 to-slate-950/30" />
        <div>
          <p className="max-w-xl text-xs font-semibold uppercase tracking-wide text-[#c7d2fe]">{COLLEGE.name}</p>
          <h1 className="mt-3 text-2xl font-bold tracking-tight">KPRIET admin dashboard</h1>
          <p className="mt-1 text-sm text-white/80">Triage campus reports, verify claims and publish status updates.</p>
        </div>
        <span className="rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-bold uppercase tracking-wide text-white backdrop-blur">Admin · {user.name}</span>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        <Tile label="Total reports" value={stats.total} />
        <Tile label="Active (open + in progress)" value={stats.open} tone="text-sky-700" />
        <Tile label="High-priority open issues" value={stats.highPriorityOpen} tone="text-rose-700" />
        <Tile label="Pending claims" value={stats.pendingClaims} tone="text-violet-700" />
        <Tile label="Resolved / claimed" value={stats.resolved} tone="text-emerald-700" />
      </div>

      {/* Pending claims queue */}
      <section className="card overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
          <h2 className="font-semibold text-slate-900">
            Claims awaiting verification <span className="text-slate-400">({pendingClaims.length})</span>
          </h2>
        </div>
        {pendingClaims.length === 0 ? (
          <p className="p-5 text-sm text-slate-500">All caught up — no pending claims. 🎉</p>
        ) : (
          <ul className="divide-y divide-slate-100">
            {pendingClaims.map((c) => (
              <li key={c.id} className="flex flex-col gap-3 p-5 sm:flex-row sm:items-start">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <TypeBadge type={c.post.type} />
                    <Link href={`/posts/${c.post.id}`} className="font-medium text-slate-900 hover:text-indigo-700">
                      {c.post.title}
                    </Link>
                    <span className="text-xs text-slate-400">· {c.post.location}</span>
                  </div>
                  <p className="mt-1 text-sm text-slate-600">
                    <span className="font-medium text-slate-800">{c.claimant.name}</span>{" "}
                    <span className="text-slate-400">({c.claimant.email})</span> says: “{c.message}”
                  </p>
                  <p className="text-xs text-slate-400">{timeAgo(c.createdAt)}</p>
                </div>
                <ClaimReviewButtons claimId={c.id} />
              </li>
            ))}
          </ul>
        )}
      </section>

      <EscalationQueue
        escalations={escalations.map((e) => ({
          ...e,
          createdAt: e.createdAt.toISOString(),
          handledAt: e.handledAt?.toISOString() ?? null,
        }))}
      />

      {/* Reports table */}
      <section className="card overflow-hidden">
        <div className="flex flex-wrap items-center gap-3 border-b border-slate-100 px-5 py-4">
          <h2 className="font-semibold text-slate-900">Reports</h2>
          <div className="flex rounded-lg bg-slate-100 p-1 text-xs">
            {[
              { v: null, l: "All types" },
              { v: "issue", l: "Issues" },
              { v: "lost", l: "Lost" },
              { v: "found", l: "Found" },
            ].map((t) => (
              <Link
                key={t.l}
                href={tabLink({ type: t.v })}
                className={cn("rounded-md px-2.5 py-1 font-medium", (typeFilter ?? null) === t.v ? "bg-white text-slate-900 shadow-sm" : "text-slate-600")}
              >
                {t.l}
              </Link>
            ))}
          </div>
          <div className="flex rounded-lg bg-slate-100 p-1 text-xs">
            {[
              { v: "active", l: "Active" },
              { v: "open", l: "Open" },
              { v: "in_progress", l: "In progress" },
              { v: "claimed", l: "Claimed" },
              { v: "resolved", l: "Resolved" },
              { v: "closed", l: "Closed" },
              { v: "all", l: "All" },
            ].map((t) => (
              <Link
                key={t.v}
                href={tabLink({ status: t.v })}
                className={cn("rounded-md px-2.5 py-1 font-medium", statusFilter === t.v ? "bg-white text-slate-900 shadow-sm" : "text-slate-600")}
              >
                {t.l}
              </Link>
            ))}
          </div>
          <span className="ml-auto text-xs text-slate-500">{items.length} shown · sorted by upvotes</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
              <tr>
                <th className="px-5 py-3">Report</th>
                <th className="px-3 py-3">Type</th>
                <th className="px-3 py-3">Location</th>
                <th className="px-3 py-3">Priority</th>
                <th className="px-3 py-3 text-center">▲</th>
                <th className="px-3 py-3">Status</th>
                <th className="px-3 py-3">Age</th>
                <th className="px-5 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {items.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/70">
                  <td className="max-w-xs px-5 py-3">
                    <Link href={`/posts/${p.id}`} className="line-clamp-1 font-medium text-slate-900 hover:text-indigo-700">
                      {p.title}
                    </Link>
                    <span className="text-xs text-slate-400">
                      #{p.id} · {p.category} · by {p.authorName}
                      {p.pendingClaims > 0 && <span className="ml-2 rounded bg-violet-50 px-1.5 text-violet-700">{p.pendingClaims} pending claim</span>}
                    </span>
                  </td>
                  <td className="px-3 py-3"><TypeBadge type={p.type} /></td>
                  <td className="px-3 py-3 text-slate-600">{p.location}</td>
                  <td className="px-3 py-3">{p.type === "issue" ? <PriorityBadge priority={p.priority} /> : <span className="text-slate-300">—</span>}</td>
                  <td className="px-3 py-3 text-center font-semibold text-indigo-700">{p.upvoteCount}</td>
                  <td className="px-3 py-3"><AdminQuickStatus postId={p.id} type={p.type} status={p.status} /></td>
                  <td className="px-3 py-3 text-xs text-slate-500">{timeAgo(p.createdAt)}</td>
                  <td className="px-5 py-3 text-right">
                    <Link href={`/posts/${p.id}`} className="text-xs font-medium text-indigo-600 hover:underline">Manage →</Link>
                  </td>
                </tr>
              ))}
              {items.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-5 py-10 text-center text-sm text-slate-500">No reports match this filter.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function Tile({ label, value, tone = "text-slate-900" }: { label: string; value: number; tone?: string }) {
  return (
    <div className="card p-4">
      <div className={cn("text-2xl font-extrabold", tone)}>{value}</div>
      <div className="text-xs font-medium text-slate-500">{label}</div>
    </div>
  );
}
