import { Suspense } from "react";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/AuthForm";
import { ExitArrow } from "@/components/ExitArrow";
import { getCurrentUser } from "@/lib/auth";

export default async function LoginPage() {
  const user = await getCurrentUser();
  if (user) redirect("/");
  return (
    <Suspense>
      <div className="space-y-4"><ExitArrow href="/" label="Exit sign-in" /></div>
      <AuthForm mode="login" />
    </Suspense>
  );
}
