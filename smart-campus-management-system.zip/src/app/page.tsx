import Link from "next/link";
import { CampusBackdrop } from "@/components/CampusBackdrop";
import { DashboardSearch } from "@/components/DashboardSearch";
import { getCurrentUser } from "@/lib/auth";
import { getStats, listPosts } from "@/lib/posts";
import { PostCard } from "@/components/PostCard";
import { POST_TYPES } from "@/lib/constants";
import { COLLEGE } from "@/lib/college";

export default async function HomePage() {
  const user = await getCurrentUser();
  let stats = { total: 0, lost: 0, found: 0, issues: 0, open: 0, resolved: 0, highPriorityOpen: 0, pendingClaims: 0 };
  let recent: Awaited<ReturnType<typeof listPosts>> = [];
  let trending: Awaited<ReturnType<typeof listPosts>> = [];
  try {
    [stats, recent, trending] = await Promise.all([
      getStats(),
      listPosts({ limit: 6 }, user?.id),
      listPosts({ sort: "top", status: "active", limit: 4 }, user?.id),
    ]);
  } catch {
    // Database is down — the layout already shows the setup notice.
  }

  return (
    <div className="space-y-10">
      <section
        aria-label="KPR Institute of Engineering and Technology campus dashboard"
        className="relative isolate -mt-8 ml-[calc(50%-50vw)] w-screen overflow-hidden text-white"
      >
        <CampusBackdrop />
        <span className="sr-only">Background: animated photo of the KPR Institute of Engineering and Technology campus, Coimbatore.</span>
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-wrap items-center justify-between gap-3 pt-6">
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#99f6e4]/90">
            KPRIET · Smart Campus — {user ? `Welcome back, ${user.name.split(" ")[0]}` : "Welcome, KPRIETian"}
          </p>
          <span className="inline-flex items-center gap-2 rounded-full border border-emerald-300/40 bg-emerald-400/15 px-3 py-1.5 text-xs font-medium text-[#d1fae5] backdrop-blur">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
            {stats.open} active campus reports
          </span>
        </div>
        <div className="grid min-h-[380px] gap-8 py-8 lg:grid-cols-5 lg:py-10">
          <div className="hero-rise self-center lg:col-span-3">
            <span className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/10 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider backdrop-blur">
              <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true">
                <path d="m12 3 9 4v5c0 5-9 9-9 9S3 17 3 12V7l9-4Z" />
                <path d="m8 12 3 3 5-6" />
              </svg>
              Exclusively for the KPRIET community
            </span>
            <h1 className="mt-5 max-w-2xl text-3xl font-bold leading-tight tracking-tight drop-shadow-[0_2px_12px_rgba(0,0,0,0.6)] sm:text-5xl">
              KPR Institute of<br className="hidden sm:block" /> Engineering and Technology
            </h1>
            <p className="mt-3 text-lg font-semibold text-[#99f6e4] sm:text-xl">Your campus. Connected.</p>
            <p className="mt-3 max-w-lg text-sm leading-relaxed text-white/80 sm:text-base">
              Lost it? Found it? Something needs fixing? Help make our KPRIET campus a better place—one report at a time.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/submit" className="btn-primary !bg-white !text-slate-950 hover:!bg-white/90">
                + Submit a report
              </Link>
              <Link href="/browse" className="btn-secondary !border-white/30 !bg-white/10 !text-white backdrop-blur hover:!bg-white/20">
                Browse campus reports →
              </Link>
            </div>
          </div>
          <div className="flex items-end justify-end lg:col-span-2">
            <div className="rounded-xl border border-white/25 bg-slate-950/40 px-4 py-3 backdrop-blur-md">
              <p className="text-sm font-semibold">KPR Knowledge Campus</p>
              <p className="mt-0.5 flex items-center gap-1.5 text-xs text-white/80">
                <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true">
                  <path d="M20 10c0 6-8 11-8 11S4 16 4 10a8 8 0 1 1 16 0Z" />
                  <circle cx="12" cy="10" r="2.5" />
                </svg>
                {COLLEGE.location}
              </p>
            </div>
          </div>
        </div>
        <div className="mb-8 grid grid-cols-2 divide-x divide-white/10 overflow-hidden rounded-2xl border border-white/15 bg-white/5 backdrop-blur-md md:grid-cols-4">
          <Stat label="Lost items" value={stats.lost} icon="🔍" />
          <Stat label="Found items" value={stats.found} icon="🎒" />
          <Stat label="Campus issues" value={stats.issues} icon="🛠️" />
          <Stat label="Resolved / returned" value={stats.resolved} icon="✓" />
        </div>
        </div>
      </section>

      {/* Search application */}
      <section aria-label="Search campus reports" className="fade-up relative">
        <div className="absolute inset-0 -z-10 rounded-3xl bg-gradient-to-r from-indigo-600/20 via-slate-900 to-teal-500/10 blur-xl" />
        <div className="relative rounded-3xl border border-white/10 bg-slate-950/80 p-4 shadow-2xl shadow-black/40 backdrop-blur-md sm:p-6">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-xl font-bold tracking-tight text-white">Search the KPRIET portal</h2>
              <p className="mt-0.5 text-xs text-white/55">Find lost &amp; found items, issues and places across all four blocks, hostels and halls.</p>
            </div>
            <span className="hidden rounded-full border border-white/15 bg-white/5 px-3 py-1 text-[11px] font-semibold text-white/70 sm:inline">Live search</span>
          </div>
          <DashboardSearch />
        </div>
      </section>

      <section>
        <div className="flex flex-wrap items-end justify-between gap-2">
          <div>
            <h2 className="text-lg font-bold text-slate-900">How can we help?</h2>
            <p className="text-sm text-slate-500">A little help goes a long way on our campus.</p>
          </div>
          <span className="text-xs text-slate-500">📷 Take a photo or upload one with your report</span>
        </div>
        <div className="mt-4 grid gap-4 sm:grid-cols-3">
          {POST_TYPES.map((t) => (
            <Link
              key={t.value}
              href={`/submit?type=${t.value}`}
              className="card group flex items-center gap-4 p-5 transition hover:-translate-y-0.5 hover:border-indigo-300 hover:shadow-md"
            >
              <span className="grid h-12 w-12 flex-none place-items-center rounded-xl bg-slate-100 text-2xl transition group-hover:bg-indigo-50">
                {t.icon}
              </span>
              <span>
                <span className="block font-semibold text-slate-900">{t.label}</span>
                <span className="block text-sm text-slate-500">{t.blurb}</span>
              </span>
              <span className="ml-auto text-slate-300 transition group-hover:translate-x-1 group-hover:text-indigo-500">→</span>
            </Link>
          ))}
        </div>
      </section>

      <section className="grid gap-10 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="flex items-end justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Latest at KPRIET</h2>
              <p className="text-sm text-slate-500">Lost, found and maintenance reports from our campus.</p>
            </div>
            <Link href="/browse" className="text-sm font-medium text-indigo-600 hover:underline">View all →</Link>
          </div>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            {recent.map((p) => <PostCard key={p.id} post={p} isAuthed={!!user} />)}
          </div>
        </div>
        <aside>
          <h2 className="text-lg font-bold text-slate-900">🔥 Campus priorities</h2>
          <p className="text-sm text-slate-500">Active reports our community has upvoted.</p>
          <ol className="card mt-4 divide-y divide-slate-100">
            {trending.map((p, i) => (
              <li key={p.id}>
                <Link href={`/posts/${p.id}`} className="flex items-start gap-3 p-4 transition hover:bg-slate-50">
                  <span className="grid h-7 w-7 flex-none place-items-center rounded-full bg-indigo-50 text-xs font-bold text-indigo-700">{i + 1}</span>
                  <span className="min-w-0 flex-1">
                    <span className="line-clamp-1 text-sm font-semibold text-slate-900">{p.title}</span>
                    <span className="block text-xs text-slate-500">{p.location} · {p.category}</span>
                  </span>
                  <span className="flex-none text-sm font-bold text-indigo-600">▲ {p.upvoteCount}</span>
                </Link>
              </li>
            ))}
            {trending.length === 0 && <li className="p-4 text-sm text-slate-500">No active reports yet.</li>}
          </ol>
          {stats.highPriorityOpen > 0 && (
            <div className="mt-4 rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-800">
              <strong>{stats.highPriorityOpen}</strong> high-priority maintenance issue{stats.highPriorityOpen > 1 ? "s are" : " is"} still unresolved.{" "}
              <Link href="/browse?type=issue&status=active&sort=top" className="font-semibold underline">See them</Link>
            </div>
          )}
          <div className="mt-4 rounded-xl border border-slate-200 bg-white p-5 text-sm text-slate-600">
            <p className="font-semibold text-slate-900">A better campus starts with us</p>
            <ol className="mt-3 list-decimal space-y-2 pl-4 text-sm">
              <li>Report a lost item, something you found, or a campus issue. Add a photo for clarity.</li>
              <li>Upvote to help others notice, or submit a claim with identifying details.</li>
              <li>Campus admins review claims and share official progress updates.</li>
            </ol>
          </div>
        </aside>
      </section>
    </div>
  );
}

function Stat({ label, value, icon }: { label: string; value: number; icon: string }) {
  return (
    <div className="flex items-center gap-3 px-5 py-5 sm:px-8">
      <span className="hidden h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-lg sm:flex" aria-hidden="true">{icon}</span>
      <div>
        <div className="text-2xl font-bold">{value}</div>
        <div className="text-xs font-medium text-white/80">{label}</div>
      </div>
    </div>
  );
}
