import Link from "next/link";
import { notFound } from "next/navigation";
import { PriorityBadge, RoleBadge, StatusBadge, TypeBadge } from "@/components/Badges";
import { UpvoteButton } from "@/components/UpvoteButton";
import {
  AdminPanel,
  ClaimForm,
  ClaimReviewButtons,
  CommentForm,
  DeletePostButton,
} from "@/components/PostActions";
import { getCurrentUser } from "@/lib/auth";
import { LocationTracker } from "@/components/LocationTracker";
import { COLLEGE } from "@/lib/college";
import { getPostDetail } from "@/lib/posts";
import { STATUS_META, formatClass } from "@/lib/constants";
import { ExitArrow } from "@/components/ExitArrow";
import { ZoomableImage } from "@/components/ZoomableImage";
import { EscalationPanel, type EscalationCheckDTO } from "@/components/EscalationPanel";
import { checkEscalation } from "@/lib/escalation";
import { cn, formatDate, initials, timeAgo } from "@/lib/utils";

export default async function PostDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const postId = Number(id);
  if (!Number.isFinite(postId)) notFound();

  const user = await getCurrentUser();
  let post: Awaited<ReturnType<typeof getPostDetail>> = null;
  try {
    post = await getPostDetail(postId, user?.id);
  } catch {
    notFound(); // DB is down — the layout already shows the setup notice
  }
  if (!post) notFound();

  const isAdmin = user?.role === "admin";
  const isAuthor = user?.id === post.authorId;
  const isItem = post.type !== "issue";
  const myPendingClaim = user ? post.claims.find((c) => c.claimantId === user.id && c.status === "pending") : null;
  const canClaim = !!user && isItem && !isAuthor && post.status === "open" && !myPendingClaim;
  const visibleClaims = isAdmin || isAuthor ? post.claims : post.claims.filter((c) => c.claimantId === user?.id);
  let check: Awaited<ReturnType<typeof checkEscalation>> | null = null;
  if (user) {
    try {
      check = await checkEscalation(post.id, user);
    } catch {
      check = null; // escalation check is best-effort on this page
    }
  }
  const escalationDTO: EscalationCheckDTO | null = check
    ? {
        ...check,
        eligibleFrom: check.eligibleFrom.toISOString(),
        existing: check.existing
          ? {
              id: check.existing.id,
              reference: check.existing.reference,
              status: check.existing.status,
              reason: check.existing.reason,
              createdAt: check.existing.createdAt.toISOString(),
              handledAt: check.existing.handledAt?.toISOString() ?? null,
              handledNote: check.existing.handledNote,
            }
          : null,
      }
    : null;

  return (
    <div className="space-y-6">
      <nav className="flex flex-wrap items-center gap-3 text-sm text-slate-500">
        <ExitArrow href="/browse" label="Back to reports" />
        <Link href="/browse" className="hover:text-indigo-600">Browse</Link>
        <span className="mx-2">/</span>
        <Link href={`/browse?type=${post.type}`} className="hover:text-indigo-600 capitalize">{post.type}</Link>
        <span className="mx-2">/</span>
        <span className="text-slate-700">#{post.id}</span>
      </nav>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Main column */}
        <div className="space-y-6 lg:col-span-2">
          <article className="card overflow-hidden">
            {post.imageUrl && (
              <ZoomableImage src={post.imageUrl} alt={post.title} className="max-h-80 w-full cursor-zoom-in object-cover" />
            )}
            <div className="p-6">
              <div className="flex flex-wrap items-center gap-2">
                <TypeBadge type={post.type} />
                <StatusBadge status={post.status} />
                {post.type === "issue" && <PriorityBadge priority={post.priority} />}
                <span className="ml-auto text-xs text-slate-400">Posted {timeAgo(post.createdAt)}</span>
              </div>
              <h1 className="mt-3 text-2xl font-bold tracking-tight text-slate-900">{post.title}</h1>
              <p className="mt-3 whitespace-pre-line text-slate-700">{post.description}</p>

              <dl className="mt-5 grid grid-cols-2 gap-4 rounded-xl bg-slate-50 p-4 text-sm sm:grid-cols-4">
                <div>
                  <dt className="text-xs uppercase tracking-wide text-slate-400">Location</dt>
                  <dd className="font-medium text-slate-800">{post.location}</dd>
                  {post.locationDetail && <dd className="text-xs text-slate-500">{post.locationDetail}</dd>}
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-slate-400">Category</dt>
                  <dd className="font-medium text-slate-800">{post.category}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-slate-400">{isItem ? (post.type === "lost" ? "Lost on" : "Found on") : "Reported"}</dt>
                  <dd className="font-medium text-slate-800">{formatDate(post.occurredAt ?? post.createdAt)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-slate-400">{post.resolvedAt ? "Resolved" : "Last update"}</dt>
                  <dd className="font-medium text-slate-800">{formatDate(post.resolvedAt ?? post.updatedAt)}</dd>
                </div>
                {post.contactInfo && (
                  <div className="col-span-2">
                    <dt className="text-xs uppercase tracking-wide text-slate-400">Contact</dt>
                    <dd className="font-medium text-slate-800">{post.contactInfo}</dd>
                  </div>
                )}
              </dl>

              {post.reporterName && (
                <section aria-label="Reporter details" className="mt-4 rounded-xl border border-slate-200 p-4">
                  <p className="text-xs font-bold uppercase tracking-wide text-slate-400">Reported by</p>
                  <div className="mt-2 flex flex-wrap items-start gap-x-8 gap-y-3 text-sm">
                    <div className="flex items-center gap-3">
                      <span className="grid h-10 w-10 place-items-center rounded-full bg-indigo-100 text-sm font-bold text-indigo-700">{initials(post.reporterName)}</span>
                      <div>
                        <p className="font-semibold text-slate-900">{post.reporterName}</p>
                        <p className="text-xs text-slate-500">{formatClass(post) ?? "KPRIET member"}</p>
                      </div>
                    </div>
                    {user ? (
                      <div className="space-y-1">
                        {post.reporterPhone && (
                          <a href={`tel:${post.reporterPhone}`} className="flex items-center gap-2 font-medium text-indigo-700 hover:underline">📞 {post.reporterPhone}</a>
                        )}
                        {post.reporterEmail && (
                          <a href={`mailto:${post.reporterEmail}`} className="flex items-center gap-2 text-slate-600 hover:underline">✉️ {post.reporterEmail}</a>
                        )}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-500">
                        <Link href={`/login?next=/posts/${post.id}`} className="font-semibold text-indigo-600 hover:underline">Sign in</Link> to view phone & email.
                      </p>
                    )}
                  </div>
                </section>
              )}

              {post.adminNote && (
                <div className="mt-4 flex gap-3 rounded-xl border border-indigo-200 bg-indigo-50 p-4">
                  <span className="text-xl">📣</span>
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wide text-indigo-700">Official update</p>
                    <p className="mt-0.5 text-sm text-indigo-900">{post.adminNote}</p>
                  </div>
                </div>
              )}

              <div className="mt-5 flex flex-wrap items-center gap-3 border-t border-slate-100 pt-4">
                <UpvoteButton postId={post.id} initialCount={post.upvoteCount} initialUpvoted={post.viewerUpvoted} isAuthed={!!user} size="md" />
                <span className="text-sm text-slate-500">
                  {post.type === "issue" ? "Upvote to raise priority" : "Upvote to boost visibility"}
                </span>
                <div className="ml-auto flex items-center gap-2 text-sm">
                  <span className="grid h-8 w-8 place-items-center rounded-full bg-slate-200 text-xs font-bold text-slate-700">{initials(post.author.name)}</span>
                  <span>
                    <span className="block font-medium text-slate-800">{post.author.name}</span>
                    <span className="block text-xs text-slate-500">{post.author.department ?? post.author.role}</span>
                  </span>
                  <RoleBadge role={post.author.role} />
                </div>
              </div>
              {(isAuthor || isAdmin) && (
                <div className="mt-3 text-right">
                  <DeletePostButton postId={post.id} />
                </div>
              )}
            </div>
          </article>

          {escalationDTO ? (
            <EscalationPanel
              postId={post.id}
              title={post.title}
              location={`${post.location}${post.locationDetail ? ` · ${post.locationDetail}` : ""}`}
              createdAt={post.createdAt.toISOString()}
              upvotes={post.upvoteCount}
              isAdmin={isAdmin}
              canEscalate={isAdmin || isAuthor}
              check={escalationDTO}
            />
          ) : (
            <div className="rounded-xl border border-white/10 bg-white/5 p-4 text-sm text-slate-400">
              🏛️ Escalation to the CEO&apos;s Office is available to signed-in reporters whose report has had no action.{" "}
              <Link href={`/login?next=/posts/${post.id}`} className="font-semibold text-indigo-300 hover:underline">Sign in</Link> to check eligibility.
            </div>
          )}

          <LocationTracker
            destLat={post.reportLat ?? COLLEGE.center.lat}
            destLng={post.reportLng ?? COLLEGE.center.lng}
            precise={post.reportLat !== null && post.reportLng !== null}
            accuracy={post.reportAccuracy}
            placeLabel={`${post.location}${post.locationDetail ? ` · ${post.locationDetail}` : ""}`}
            reporterName={post.reporterName}
          />

          {/* Claim CTA */}
          {isItem && !user && post.status === "open" && (
            <div className="rounded-xl border border-violet-200 bg-violet-50 p-4 text-sm text-violet-900">
              {post.type === "found" ? "Is this yours?" : "Found this item?"}{" "}
              <Link href={`/login?next=/posts/${post.id}`} className="font-semibold underline">Sign in to claim it</Link>.
            </div>
          )}
          {canClaim && <ClaimForm postId={post.id} type={post.type} />}
          {myPendingClaim && (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
              ⏳ Your claim is pending admin review. Submitted {timeAgo(myPendingClaim.createdAt)}.
            </div>
          )}

          {/* Claims list */}
          {isItem && visibleClaims.length > 0 && (
            <section className="card p-6">
              <h2 className="font-semibold text-slate-900">
                Claims <span className="text-slate-400">({visibleClaims.length})</span>
              </h2>
              <ul className="mt-3 divide-y divide-slate-100">
                {visibleClaims.map((c) => (
                  <li key={c.id} className="flex flex-col gap-2 py-3 sm:flex-row sm:items-start">
                    <span className="grid h-8 w-8 flex-none place-items-center rounded-full bg-violet-100 text-xs font-bold text-violet-700">{initials(c.claimant.name)}</span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2 text-sm">
                        <span className="font-medium text-slate-800">{c.claimant.name}</span>
                        <span
                          className={cn(
                            "rounded-full px-2 py-0.5 text-[11px] font-semibold",
                            c.status === "approved" ? "bg-emerald-100 text-emerald-700" : c.status === "rejected" ? "bg-rose-100 text-rose-700" : "bg-amber-100 text-amber-700",
                          )}
                        >
                          {c.status}
                        </span>
                        <span className="text-xs text-slate-400">{timeAgo(c.createdAt)}</span>
                      </div>
                      <p className="mt-1 text-sm text-slate-600">{c.message}</p>
                    </div>
                    {isAdmin && c.status === "pending" && <ClaimReviewButtons claimId={c.id} />}
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* Comments */}
          <section className="card p-6">
            <h2 className="font-semibold text-slate-900">
              Discussion <span className="text-slate-400">({post.comments.length})</span>
            </h2>
            <ul className="mt-4 space-y-4">
              {post.comments.map((c) => (
                <li key={c.id} className={cn("flex gap-3", c.isOfficial && "rounded-xl border border-indigo-200 bg-indigo-50/60 p-3")}>
                  <span className={cn("grid h-8 w-8 flex-none place-items-center rounded-full text-xs font-bold", c.isOfficial ? "bg-indigo-600 text-white" : "bg-slate-200 text-slate-700")}>
                    {initials(c.author.name)}
                  </span>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2 text-sm">
                      <span className="font-medium text-slate-800">{c.author.name}</span>
                      {c.isOfficial && <span className="rounded bg-indigo-600 px-1.5 py-0.5 text-[10px] font-bold uppercase text-white">Official</span>}
                      <span className="text-xs text-slate-400">{timeAgo(c.createdAt)}</span>
                    </div>
                    <p className="mt-0.5 whitespace-pre-line text-sm text-slate-700">{c.body}</p>
                  </div>
                </li>
              ))}
              {post.comments.length === 0 && <li className="text-sm text-slate-500">No comments yet. Be the first to help.</li>}
            </ul>
            <div className="mt-5 border-t border-slate-100 pt-4">
              {user ? (
                <CommentForm postId={post.id} isAdmin={isAdmin} />
              ) : (
                <p className="text-sm text-slate-500">
                  <Link href={`/login?next=/posts/${post.id}`} className="font-medium text-indigo-600 hover:underline">Sign in</Link> to join the discussion.
                </p>
              )}
            </div>
          </section>
        </div>

        {/* Sidebar */}
        <aside className="space-y-6">
          {isAdmin && (
            <AdminPanel postId={post.id} type={post.type} status={post.status} priority={post.priority} adminNote={post.adminNote} />
          )}

          <section className="card p-5">
            <h2 className="font-semibold text-slate-900">Activity timeline</h2>
            <ol className="mt-4 space-y-4 border-l-2 border-slate-100 pl-4">
              {post.activity.map((a) => (
                <li key={a.id} className="relative">
                  <span
                    className={cn(
                      "absolute -left-[23px] top-1 h-3 w-3 rounded-full ring-4 ring-white",
                      a.toStatus ? STATUS_META[a.toStatus as keyof typeof STATUS_META]?.dot ?? "bg-slate-300" : "bg-slate-300",
                    )}
                  />
                  <p className="text-sm text-slate-800">
                    <span className="font-medium">{a.actor?.name ?? "System"}</span> {describeActivity(a.action, a.fromStatus, a.toStatus)}
                  </p>
                  {a.note && <p className="mt-0.5 text-xs text-slate-500">“{a.note}”</p>}
                  <p className="text-xs text-slate-400">{timeAgo(a.createdAt)}</p>
                </li>
              ))}
              {post.activity.length === 0 && <li className="text-sm text-slate-500">No activity recorded.</li>}
            </ol>
          </section>

          <section className="card p-5 text-sm text-slate-600">
            <h2 className="font-semibold text-slate-900">Status guide</h2>
            <ul className="mt-3 space-y-2">
              {(post.type === "issue"
                ? (["open", "in_progress", "resolved", "closed"] as const)
                : (["open", "claimed", "resolved", "closed"] as const)
              ).map((s) => (
                <li key={s} className="flex items-center gap-2">
                  <StatusBadge status={s} />
                  <span className="text-xs text-slate-500">{statusHelp(s, post.type)}</span>
                </li>
              ))}
            </ul>
          </section>
        </aside>
      </div>
    </div>
  );
}

function describeActivity(action: string, from: string | null, to: string | null) {
  const label = (s: string | null) => (s ? STATUS_META[s as keyof typeof STATUS_META]?.label ?? s : "");
  switch (action) {
    case "created":
      return "submitted this report";
    case "status_changed":
      return `changed status from ${label(from)} to ${label(to)}`;
    case "claim_submitted":
      return "submitted a claim";
    case "claim_approved":
      return "approved a claim — item marked as claimed";
    case "claim_rejected":
      return "rejected a claim";
    case "note_updated":
      return "posted an official note";
    case "escalated_to_ceo":
      return "escalated this report to the CEO's Office after no action was taken";
    case "escalation_acknowledged":
      return "acknowledged the CEO's Office escalation";
    case "escalation_closed":
      return "closed the CEO's Office escalation";
    default:
      return action.replace(/_/g, " ");
  }
}

function statusHelp(s: string, type: string) {
  const items: Record<string, string> = {
    open: type === "issue" ? "Reported, awaiting triage" : "Still looking / awaiting claims",
    in_progress: "Facilities team is working on it",
    claimed: "A claim has been verified by admin",
    resolved: type === "issue" ? "Fixed and verified" : "Item returned to owner",
    closed: "Closed without resolution",
  };
  return items[s] ?? "";
}
