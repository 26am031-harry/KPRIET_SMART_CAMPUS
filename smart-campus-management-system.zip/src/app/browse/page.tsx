import { Suspense } from "react";
import Link from "next/link";
import { ExitArrow } from "@/components/ExitArrow";
import { FilterBar } from "@/components/FilterBar";
import { PostCard } from "@/components/PostCard";
import { getCurrentUser } from "@/lib/auth";
import { listPosts, type PostListItem } from "@/lib/posts";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

const first = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? null;

async function listPostsSafe(
  filters: Parameters<typeof listPosts>[0],
  viewerId?: number | null,
): Promise<PostListItem[]> {
  try {
    return await listPosts(filters, viewerId);
  } catch {
    return []; // layout already surfaces the database setup notice
  }
}

export default async function BrowsePage({ searchParams }: { searchParams: SearchParams }) {
  const sp = await searchParams;
  const user = await getCurrentUser();
  const items = await listPostsSafe(
    {
      type: first(sp.type),
      status: first(sp.status),
      category: first(sp.category),
      location: first(sp.location),
      q: first(sp.q),
      sort: first(sp.sort),
    },
    user?.id,
  );

  return (
    <div className="space-y-6">
      <div className="space-y-3">
        <ExitArrow href="/" label="Exit to dashboard" />
      </div>

      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Browse reports</h1>
          <p className="text-sm text-slate-500">Filter by type, status and category. Upvote to raise visibility.</p>
        </div>
        <Link href="/submit" className="btn-primary">
          + New report
        </Link>
      </div>

      <Suspense fallback={<div className="card h-28 animate-pulse" />}>
        <FilterBar total={items.length} />
      </Suspense>

      {items.length === 0 ? (
        <div className="card flex flex-col items-center gap-3 px-6 py-16 text-center">
          <span className="text-4xl">🗂️</span>
          <p className="font-semibold text-slate-800">No reports match these filters.</p>
          <p className="text-sm text-slate-500">Try clearing filters, or be the first to report something.</p>
          <Link href="/submit" className="btn-secondary mt-2">
            Submit a report
          </Link>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {items.map((p) => (
            <PostCard key={p.id} post={p} isAuthed={!!user} />
          ))}
        </div>
      )}
    </div>
  );
}
