import Link from "next/link";
import { redirect } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { claims, upvotes } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { listPosts } from "@/lib/posts";
import { PostCard } from "@/components/PostCard";
import { StatusBadge, TypeBadge } from "@/components/Badges";
import { ExitArrow } from "@/components/ExitArrow";
import { cn, timeAgo } from "@/lib/utils";

export default async function MyPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/my");

  let myPosts: Awaited<ReturnType<typeof listPosts>> = [];
  let myClaims: Awaited<any>[] = [];
  let myUpvotes: Awaited<any>[] = [];
  try {
    [myPosts, myClaims, myUpvotes] = await Promise.all([
    listPosts({ authorId: user.id }, user.id),
    db.query.claims.findMany({
      where: eq(claims.claimantId, user.id),
      with: { post: true },
      orderBy: [desc(claims.createdAt)],
    }),
    db.query.upvotes.findMany({ where: eq(upvotes.userId, user.id) }),
    ]);
  } catch {
    // DB is down — layout shows the setup notice.
  }

  const active = myPosts.filter((p) => p.status === "open" || p.status === "in_progress").length;
  const resolved = myPosts.filter((p) => p.status === "resolved" || p.status === "claimed").length;

  return (
    <div className="space-y-8">
      <ExitArrow href="/" label="Exit to dashboard" />
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">My activity</h1>
        <p className="text-sm text-slate-500">
          Signed in as {user.name} ({user.email}) · {user.department ?? user.role}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Tile label="My reports" value={myPosts.length} />
        <Tile label="Active" value={active} tone="text-sky-700" />
        <Tile label="Resolved / claimed" value={resolved} tone="text-emerald-700" />
        <Tile label="Upvotes given" value={myUpvotes.length} tone="text-indigo-700" />
      </div>

      <section>
        <div className="flex items-end justify-between">
          <h2 className="text-lg font-bold text-slate-900">My reports</h2>
          <Link href="/submit" className="text-sm font-medium text-indigo-600 hover:underline">+ New report</Link>
        </div>
        {myPosts.length === 0 ? (
          <div className="card mt-4 p-8 text-center text-sm text-slate-500">
            You haven&apos;t submitted anything yet.{" "}
            <Link href="/submit" className="font-medium text-indigo-600 hover:underline">Report something</Link>.
          </div>
        ) : (
          <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {myPosts.map((p) => (
              <PostCard key={p.id} post={p} isAuthed />
            ))}
          </div>
        )}
      </section>

      <section>
        <h2 className="text-lg font-bold text-slate-900">My claims</h2>
        {myClaims.length === 0 ? (
          <div className="card mt-4 p-8 text-center text-sm text-slate-500">
            No claims yet. Browse{" "}
            <Link href="/browse?type=found" className="font-medium text-indigo-600 hover:underline">found items</Link>{" "}
            to see if anything is yours.
          </div>
        ) : (
          <ul className="card mt-4 divide-y divide-slate-100">
            {myClaims.map((c) => (
              <li key={c.id} className="flex flex-wrap items-center gap-3 p-4">
                <TypeBadge type={c.post.type} />
                <Link href={`/posts/${c.post.id}`} className="font-medium text-slate-900 hover:text-indigo-700">
                  {c.post.title}
                </Link>
                <StatusBadge status={c.post.status} />
                <span className="ml-auto flex items-center gap-3 text-xs text-slate-500">
                  <span
                    className={cn(
                      "rounded-full px-2 py-0.5 font-semibold",
                      c.status === "approved" ? "bg-emerald-100 text-emerald-700" : c.status === "rejected" ? "bg-rose-100 text-rose-700" : "bg-amber-100 text-amber-700",
                    )}
                  >
                    Claim {c.status}
                  </span>
                  {timeAgo(c.createdAt)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function Tile({ label, value, tone = "text-slate-900" }: { label: string; value: number; tone?: string }) {
  return (
    <div className="card p-4">
      <div className={cn("text-2xl font-extrabold", tone)}>{value}</div>
      <div className="text-xs font-medium text-slate-500">{label}</div>
    </div>
  );
}
