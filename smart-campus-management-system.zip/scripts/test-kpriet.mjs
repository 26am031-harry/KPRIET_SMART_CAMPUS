import { chromium, devices, expect } from "@playwright/test";
import { mkdir } from "node:fs/promises";

const baseURL = process.env.TEST_BASE_URL || "http://localhost:3000";
const browser = await chromium.launch({ args: ["--use-fake-device-for-media-stream", "--use-fake-ui-for-media-stream"] });
const context = await browser.newContext({ baseURL, viewport: { width: 1440, height: 1050 }, permissions: ["camera", "geolocation"], geolocation: { latitude: 11.0768, longitude: 77.1423, accuracy: 12 } });
const page = await context.newPage();
const errors = [];
const createdPosts = [];
page.on("pageerror", (err) => errors.push(err.message));
await mkdir("artifacts", { recursive: true });

async function fillReport(title, category) {
  await page.getByLabel(/What did you (find|lose)/).fill(title);
  await page.getByLabel("Description", { exact: true }).fill("A browser smoke-test report to verify persistent photos at the KPRIET campus.");
  await page.getByLabel("Category", { exact: true }).selectOption(category);
  await page.getByLabel("KPRIET campus location").selectOption("B Block · 2nd Floor Classrooms");
  await page.getByLabel("Exact spot or room number").fill("Room B-204");
  await page.getByLabel("Mobile number").fill("9876501234");
  await page.getByLabel("Studying year").selectOption("III Year");
  await page.getByLabel("Department").selectOption("CSE");
  await page.getByLabel("Section").selectOption("B");
}

async function submitAndCheckPhoto(buttonName) {
  const [response] = await Promise.all([
    page.waitForResponse((r) => r.url().endsWith("/api/posts") && r.request().method() === "POST"),
    page.getByRole("button", { name: buttonName, exact: true }).click(),
  ]);
  const body = await response.json();
  expect(response.status(), JSON.stringify(body)).toBe(201);
  createdPosts.push(body.post.id);
  expect(body.post.imageUrl).toMatch(/^\/api\/photos\/[0-9a-f-]+$/);
  await page.waitForURL(`**/posts/${body.post.id}`);
  const photo = await context.request.get(body.post.imageUrl);
  expect(photo.status()).toBe(200);
  expect(photo.headers()["content-type"]).toBe("image/jpeg");
  const bytes = await photo.body();
  expect(bytes[0]).toBe(0xff);
  expect(bytes[1]).toBe(0xd8);
  await expect(page.locator(`article img[src="${body.post.imageUrl}"]`)).toBeVisible();
  const reporter = page.getByRole("region", { name: "Reporter details" });
  await expect(reporter).toContainText("Priya Sharma");
  await expect(reporter).toContainText("III Year · CSE – B");
  await expect(reporter).toContainText("9876501234");
  await expect(page.locator("dd", { hasText: "Room B-204" })).toBeVisible();
  return body.post;
}

try {
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("KPR Institute of Engineering and Technology");
  const campusImage = page.locator("img.kenburns");
  await expect(campusImage).toBeVisible();
  expect(await campusImage.getAttribute("src")).toContain("kpriet-campus");
  await expect(campusImage).toHaveJSProperty("complete", true);
  expect(await campusImage.evaluate((img) => img.naturalWidth)).toBeGreaterThan(0);
  const anim = await page.locator(".kenburns").evaluate((el) => getComputedStyle(el).animationName);
  expect(anim).toBe("kenburns");
  await expect(page.locator(".dark-closure")).toHaveCount(1);
  // Every seeded lost/found card shows its item photo.
  const itemImgs = page.locator('a[href^="/posts/"] img[src^="/images/items/"]');
  expect(await itemImgs.count()).toBeGreaterThan(2);
  for (const img of await itemImgs.all()) expect(await img.evaluate((i) => i.complete && i.naturalWidth > 0)).toBe(true);
  await page.screenshot({ path: "artifacts/kpriet-dashboard-desktop.png" });
  console.log("PASS: animated KPRIET backdrop with dark closure, item photos on cards");

  // Dark theme + logo + creator contact
  expect(await page.evaluate(() => getComputedStyle(document.body).backgroundColor)).toBe("rgb(2, 6, 23)");
  expect(await page.evaluate(() => getComputedStyle(document.body, "::before").backgroundImage)).toContain("kpriet-emblem-large.png");
  const navLogo = page.getByRole("banner").getByAltText("KPRIET logo");
  await expect(navLogo).toBeVisible();
  expect(await navLogo.evaluate((i) => i.naturalWidth > 0)).toBe(true);
  const cardBg = await page.locator(".card").first().evaluate((el) => getComputedStyle(el).backgroundColor);
  expect(cardBg).not.toBe("rgb(255, 255, 255)");
  const creator = page.getByRole("complementary", { name: "Website creator contact" });
  await expect(creator).toContainText("Name: Haarish K");
  await expect(creator).toContainText("Contact no: +91 90805 65571");
  const box = await creator.boundingBox();
  expect(box.x).toBeLessThan(40);
  await creator.getByRole("button").click();
  await expect(creator.getByRole("link", { name: "📞 Call" })).toHaveAttribute("href", "tel:+919080565571");
  await expect(creator).toContainText("haarishhaary3@gmail.com");
  await expect(creator.getByRole("link", { name: /Email the creator/ })).toHaveAttribute("href", /mailto:haarishhaary3@gmail.com/);
  await creator.getByRole("button", { name: "Close creator contact" }).click();
  await expect(page.locator("footer")).toContainText("Haarish K");
  await expect(page.locator("footer")).toContainText("haarishhaary3@gmail.com");
  // Option B: college management details at the bottom-left of every page
  const mgmt = page.getByRole("complementary", { name: "College management contacts" });
  await expect(mgmt).toContainText("College management · Option B");
  const mgmtBox = await mgmt.boundingBox();
  expect(mgmtBox.x).toBeLessThan(40);
  const viewport = page.viewportSize();
  expect(mgmtBox.y + mgmtBox.height).toBeGreaterThan(viewport.height - 160);
  expect(mgmtBox.y).toBeLessThan(box.y); // sits directly above the creator panel
  await mgmt.getByRole("button").first().click();
  await expect(mgmt).toContainText("College management & helpline");
  await expect(mgmt).toContainText("0422 2635600");
  await expect(mgmt).toContainText("principal@kpriet.ac.in");
  await expect(mgmt).toContainText("+91 75488 88444");
  await expect(mgmt).toContainText("KPR Knowledge Campus, Avinashi Road, Arasur");
  await expect(mgmt.locator('a[href="tel:+914222635600"]').first()).toBeVisible();
  await expect(mgmt.locator('a[href="mailto:admission@kpriet.ac.in"]')).toBeVisible();
  await mgmt.getByRole("button", { name: "Exit college management contacts" }).click();
  await expect(mgmt).toContainText("Enquiries & helpline");
  await page.goto("/browse");
  await expect(page.getByRole("complementary", { name: "College management contacts" })).toBeVisible();
  await page.goto("/");
  console.log("PASS: dark theme with KPRIET logo background, navbar logo, creator contact bottom-left");
  console.log("PASS: Option B college management contacts at bottom-left on every page");

  // Voice assistant (typed path; speech APIs are browser features)
  await page.getByRole("button", { name: /Open voice assistant/ }).click();
  const dialog = page.getByRole("dialog", { name: /voice assistant/ });
  await dialog.getByLabel("Ask the assistant").fill("I lost my blue water bottle at the gym");
  await dialog.getByRole("button", { name: "Ask", exact: true }).click();
  await expect(dialog.getByText(/may match what you lost/)).toBeVisible();
  await expect(dialog.locator('a[href^="/posts/"]').first()).toContainText("water bottle");
  await dialog.getByLabel("Ask the assistant").fill("what was found at saaral bakery");
  await dialog.getByRole("button", { name: "Ask", exact: true }).click();
  await expect(dialog.getByText(/no found item reports at Saaral Bakery/)).toBeVisible();
  await dialog.getByRole("button", { name: "What was found at Raagam Hall?" }).click();
  await expect(dialog.locator('a[href^="/posts/"]').last()).toContainText("calculator");
  await page.screenshot({ path: "artifacts/kpriet-assistant.png" });
  await dialog.getByLabel("Ask the assistant").press("Escape");
  console.log("PASS: assistant answers lost-item questions from reported details");

  await page.goto("/login?next=%2Fsubmit%3Ftype%3Dfound");
  await page.getByRole("button", { name: /Student Priya Sharma/ }).click();
  await page.waitForURL("**/submit?type=found");
  await page.getByLabel("Upload a report photo", { exact: true }).setInputFiles("public/images/kpriet-campus.jpg");
  await expect(page.getByAltText("Preview of the photo attached to your report")).toBeVisible();
  await expect(page.getByRole("button", { name: "Submit Found Item", exact: true })).toBeEnabled();
  await fillReport("KPRIET browser test: found item with uploaded photo", "Electronics");
  await page.getByRole("button", { name: /Pin my current location/ }).click();
  await expect(page.getByText(/GPS pinned \(11\.0768/)).toBeVisible();
  await page.screenshot({ path: "artifacts/kpriet-found-photo-form.png", fullPage: true });
  const uploaded = await submitAndCheckPhoto("Submit Found Item");
  // Location tracker: start at the pinned spot, then walk ~400 m away.
  const tracker = page.getByRole("region", { name: "Location tracker" });
  await expect(tracker).toContainText("Exact spot pinned by Priya Sharma");
  await expect(tracker.locator("iframe")).toHaveAttribute("src", /openstreetmap\.org.*marker=11\.0768/);
  await tracker.getByRole("button", { name: /Track from my location/ }).click();
  await expect(tracker.getByText("You've arrived!")).toBeVisible();
  await context.setGeolocation({ latitude: 11.0732, longitude: 77.1405, accuracy: 10 });
  await expect(tracker.getByText(/^\d+ m$/)).toBeVisible({ timeout: 10000 });
  await expect(tracker).toContainText(/Head North-East/);
  await expect(tracker.getByRole("link", { name: /Walking directions/ })).toHaveAttribute("href", /origin=11\.0732,77\.1405&destination=11\.0768/);
  await page.screenshot({ path: "artifacts/kpriet-tracker.png", fullPage: true });
  await tracker.getByRole("button", { name: "Stop tracking" }).click();
  await context.setGeolocation({ latitude: 11.0768, longitude: 77.1423, accuracy: 12 });
  const offCampus = await context.request.post("/api/posts", { data: { type: "lost", title: "Off campus pin", description: "Pin far away from campus should fail.", category: "Keys", location: "Gym", reportLat: 13.08, reportLng: 80.27, reporterName: "Test", reporterPhone: "9876543210", reporterYear: "I Year", reporterDepartment: "IT", reporterSection: "A" } });
  expect((await offCampus.json()).error).toMatch(/outside the KPRIET campus/);
  console.log("PASS: GPS pin on report + live location tracker (distance, direction, arrival, directions link)");
  await page.reload();
  await expect(page.locator(`article img[src="${uploaded.imageUrl}"]`)).toBeVisible();
  console.log("PASS: upload, optimized preview, report creation and persistent photo retrieval");

  await page.goto("/submit?type=lost");
  await page.getByRole("button", { name: "Take photo", exact: true }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await expect(page.getByRole("button", { name: "Capture photo", exact: true })).toBeEnabled({ timeout: 20000 });
  await page.getByRole("button", { name: "Capture photo", exact: true }).click();
  await expect(page.getByAltText("Preview of the photo attached to your report")).toBeVisible();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  expect(await page.locator("video").evaluate((video) => video.srcObject === null)).toBe(true);
  await page.getByRole("button", { name: "Retake photo", exact: true }).click();
  await expect(page.getByRole("button", { name: "Capture photo", exact: true })).toBeEnabled();
  await page.getByRole("button", { name: "Capture photo", exact: true }).click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await expect(page.getByRole("button", { name: "Submit Lost Item", exact: true })).toBeEnabled();
  await expect(page.getByAltText("Preview of the photo attached to your report")).toBeVisible();
  await fillReport("KPRIET browser test: lost item with camera photo", "Keys");
  await submitAndCheckPhoto("Submit Lost Item");
  console.log("PASS: live camera, capture, retake, media-stream cleanup and camera-photo submission");

  await page.goto("/submit?type=found");
  await page.evaluate(() => {
    navigator.mediaDevices.getUserMedia = async () => { throw new DOMException("Permission denied", "NotAllowedError"); };
  });
  await page.getByRole("button", { name: "Take photo", exact: true }).click();
  await expect(page.getByText(/Camera access is not available/)).toBeVisible();
  await page.getByRole("button", { name: "Exit camera", exact: true }).click();
  await page.getByLabel("Upload a report photo", { exact: true }).setInputFiles("public/images/kpriet-campus.jpg");
  await expect(page.getByAltText("Preview of the photo attached to your report")).toBeVisible();
  await page.getByRole("button", { name: "Remove photo", exact: true }).click();
  await expect(page.getByAltText("Preview of the photo attached to your report")).not.toBeVisible();
  console.log("PASS: camera permission-denied fallback, upload alternative and remove photo");

  // Invalid files are rejected server-side even if a client bypasses the picker.
  const badUpload = await context.request.post("/api/posts", {
    multipart: {
      type: "found", title: "Invalid photo test", description: "This invalid image must not create a report.", category: "Keys", location: "Central Library",
      reporterName: "Test User", reporterPhone: "9876543210", reporterYear: "II Year", reporterDepartment: "IT", reporterSection: "A",
      photo: { name: "not-an-image.jpg", mimeType: "image/jpeg", buffer: Buffer.from("this is not an image") },
    },
  });
  expect(badUpload.status()).toBe(400);
  expect((await badUpload.json()).error).toMatch(/not a supported photo/);
  const missingReporter = await context.request.post("/api/posts", {
    data: { type: "lost", title: "No reporter test", description: "Missing the reporter's phone number entirely.", category: "Keys", location: "Gym", reporterName: "X Y" },
  });
  expect(missingReporter.status()).toBe(400);
  const badPlace = await context.request.post("/api/posts", {
    data: { type: "lost", title: "Bad place test", description: "Location is not a KPRIET campus place.", category: "Keys", location: "Main Library" },
  });
  expect((await badPlace.json()).error).toMatch(/KPRIET campus location/);
  const outsideRegistration = await context.request.post("/api/auth/register", { data: { name: "External test", email: "outside@example.com", password: "testpassword123" } });
  expect(outsideRegistration.status()).toBe(400);
  console.log("PASS: image signature validation and college-only registration");

  const mobile = await browser.newContext({ ...devices["iPhone 13"], baseURL, storageState: await context.storageState() });
  const mobilePage = await mobile.newPage();
  await mobilePage.goto("/submit?type=found");
  const chooserPromise = mobilePage.waitForEvent("filechooser");
  await mobilePage.getByRole("button", { name: "Take photo", exact: true }).click();
  const chooser = await chooserPromise;
  expect(await chooser.element().getAttribute("capture")).toBe("environment");
  await chooser.setFiles("public/images/kpriet-campus.jpg");
  await expect(mobilePage.getByAltText("Preview of the photo attached to your report")).toBeVisible();
  expect(await mobilePage.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await mobilePage.screenshot({ path: "artifacts/kpriet-mobile-photo-form.png", fullPage: true });
  await mobilePage.goto("/");
  await expect(mobilePage.getByRole("heading", { level: 1 })).toHaveText("KPR Institute of Engineering and Technology");
  expect(await mobilePage.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await mobilePage.screenshot({ path: "artifacts/kpriet-dashboard-mobile.png", fullPage: true });
  await mobile.close();
  console.log("PASS: mobile rear-camera input and responsive dashboard/form");


  // ---------- exit arrows on every opened page ----------
  for (const [url, name] of [["/browse", /Exit to dashboard/], ["/my", /Exit to dashboard/], ["/submit?type=lost", /Exit without submitting/], ["/admin", /Exit admin area/]]) {
    await page.goto(url);
    await expect(page.getByRole("link", { name })).toBeVisible();
  }
  const { posts: lostPosts } = await (await context.request.get("/api/posts?type=lost&limit=50")).json();
  const withPhoto = lostPosts.find((p) => p.imageUrl);
  await page.goto(`/posts/${withPhoto.id}`);
  await expect(page.getByRole("link", { name: /Back to reports/ })).toBeVisible();
  console.log("PASS: exit arrows on browse, my activity, submit, admin and report pages");

  // ---------- double-tap / double-click zoom ----------
  const photo = page.locator(`img[src="${withPhoto.imageUrl}"]`).first();
  await photo.dblclick();
  const viewer = page.getByRole("dialog", { name: /Zoomable view/ });
  await expect(viewer).toBeVisible();
  await expect(viewer.getByText("2.5×")).toBeVisible();
  await expect(viewer.getByText(/Double-tap the picture to zoom in and out/)).toBeVisible();
  const pane = viewer.locator("div.touch-none");
  await pane.dblclick();
  await expect(viewer.getByText("1.0×")).toBeVisible();
  await pane.dblclick();
  await expect(viewer.getByText("2.5×")).toBeVisible();
  await viewer.getByRole("button", { name: "Zoom out" }).click();
  await expect(viewer.getByText("2.0×")).toBeVisible();
  await viewer.getByRole("button", { name: "Reset zoom" }).click();
  await expect(viewer.getByText("1.0×")).toBeVisible();
  await pane.click();
  await expect(viewer.getByText("1.0×")).toBeVisible(); // single tap in viewer must not close it
  await page.screenshot({ path: "artifacts/kpriet-zoom.png" });
  await viewer.getByRole("button", { name: "Exit image viewer" }).click();
  await expect(viewer).not.toBeVisible();
  await photo.click();
  await expect(viewer.getByText("1.0×")).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(viewer).not.toBeVisible();
  // thumbnail on the card also zooms on double-tap, without opening the report
  await page.goto("/browse?type=lost");
  await page.locator(`img[src="${withPhoto.imageUrl}"]`).first().dblclick();
  await expect(page.getByRole("dialog", { name: /Zoomable view/ })).toBeVisible();
  await page.keyboard.press("Escape");
  console.log("PASS: double-tap zooms in/out with pan controls and exit arrow");

  // ---------- college management contacts in footer ----------
  await page.goto("/");
  const footer = page.locator("footer");
  const mgmtCard = footer.locator("div", { hasText: "College management · enquiries & helpline" }).first();
  await expect(mgmtCard).toBeVisible();
  const mgmtCardBox = await mgmtCard.boundingBox();
  expect(mgmtCardBox.x).toBeLessThan(120); // strictly on the left side of the portal
  await expect(footer).toContainText("College management · enquiries & helpline");
  await expect(footer).toContainText("0422 2635600");
  await expect(footer).toContainText("principal@kpriet.ac.in");
  await expect(footer.locator('a[href="tel:+917548888444"]')).toBeVisible();
  await expect(footer.locator('a[href="mailto:info@kpriet.ac.in"]').first()).toBeVisible();
  await expect(footer).toContainText("KPR Knowledge Campus, Avinashi Road, Arasur");
  console.log("PASS: college management contacts and helpline in footer");

  // ---------- escalation to the CEO's Office ----------
  const escPost = await context.request.post("/api/posts", {
    data: { type: "issue", title: "Escalation smoke test issue", description: "A brand new issue used to verify CEO office escalation rules.", category: "Electrical", location: "Gym", priority: "medium", reporterName: "Priya Sharma", reporterPhone: "9876501234", reporterYear: "III Year", reporterDepartment: "CSE", reporterSection: "B" },
  });
  expect(escPost.status()).toBe(201);
  const { post: esc } = await escPost.json();
  createdPosts.push(esc.id);

  await page.goto(`/posts/${esc.id}`);
  const panel = page.getByRole("region", { name: /Escalate to CEO's Office/ });
  await expect(panel).toContainText("Not yet eligible — waiting period");
  await expect(panel).toContainText(/must stay without action for/);
  const waitTooSoon = await context.request.post(`/api/posts/${esc.id}/escalate`, { data: { reason: "Waiting period has not finished yet for this report.", confirmed: true } });
  expect(waitTooSoon.status()).toBe(409);
  expect((await waitTooSoon.json()).error).toMatch(/must stay without action/);

  // Admin verifies inaction and escalates immediately.
  const adminCtx = await browser.newContext({ baseURL, viewport: { width: 1440, height: 1050 } });
  const adminLogin = await adminCtx.request.post("/api/auth/login", { data: { email: "admin@kpriet.ac.in", password: "password123" } });
  expect(adminLogin.status()).toBe(200);
  const adminPage = await adminCtx.newPage();
  await adminPage.goto(`/posts/${esc.id}`);
  const adminPanel = adminPage.getByRole("region", { name: /Escalate to CEO's Office/ });
  await expect(adminPanel).toContainText("Verification passed");
  const escalateBtn = adminPanel.getByRole("button", { name: /Escalate to the CEO's Office/ });
  await expect(escalateBtn).toBeDisabled();
  await adminPanel.getByLabel(/Why should the CEO's Office look into this/).fill("short");
  await expect(escalateBtn).toBeDisabled();
  await adminPanel.getByLabel(/Why should the CEO's Office look into this/).fill("No department has responded to this electrical issue and students are affected during evening sessions.");
  await expect(escalateBtn).toBeDisabled();
  await adminPanel.getByRole("checkbox").check();
  await expect(escalateBtn).toBeEnabled();
  const [escRes] = await Promise.all([
    adminPage.waitForResponse((r) => r.url().includes("/escalate") && r.request().method() === "POST"),
    escalateBtn.click(),
  ]);
  expect(escRes.status()).toBe(201);
  const { escalation } = await escRes.json();
  expect(escalation.reference).toMatch(/^KP-ESC-\d{4}$/);
  await expect(adminPanel).toContainText(escalation.reference);
  await expect(adminPanel).toContainText("Verified — contact the CEO's Office directly");
  const mail = adminPanel.getByRole("link", { name: /Email with reference/ });
  await expect(mail).toHaveAttribute("href", new RegExp(`mailto:info@kpriet.ac.in.*${escalation.reference}`));
  await expect(adminPanel.getByRole("link", { name: /Call office/ })).toHaveAttribute("href", "tel:+914222635600");
  await adminPage.screenshot({ path: "artifacts/kpriet-escalation.png", fullPage: true });

  const dup = await adminCtx.request.post(`/api/posts/${esc.id}/escalate`, { data: { reason: "Trying to escalate the same report a second time should fail.", confirmed: true } });
  expect(dup.status()).toBe(409);
  expect((await dup.json()).error).toMatch(/already escalated/i);
  const acted = await adminCtx.request.post("/api/posts/14/escalate", { data: { reason: "This report is already in progress so escalation must be blocked.", confirmed: true } });
  expect(acted.status()).toBe(409);
  expect((await acted.json()).error).toMatch(/already acted on this report/i);

  // Admin queue: acknowledge then resolve.
  await adminPage.goto("/admin");
  const queue = adminPage.getByRole("region", { name: /CEO's Office escalations/ });
  await expect(queue).toContainText("KP-ESC-0001");
  await expect(queue).toContainText(escalation.reference);
  const row = queue.locator("li", { hasText: escalation.reference });
  await row.getByRole("button", { name: /Add office note/ }).click();
  await row.getByLabel(`Note for escalation ${escalation.reference}`).fill("Forwarded to the electrical department by the CEO's Office.");
  await row.getByRole("button", { name: "Acknowledge" }).click();
  await expect(queue.locator("li", { hasText: escalation.reference })).toContainText("acknowledged");
  await expect(queue.locator("li", { hasText: escalation.reference })).toContainText("Forwarded to the electrical department");
  await queue.locator("li", { hasText: escalation.reference }).getByRole("button", { name: "Mark resolved" }).click();
  await expect(queue.locator("li", { hasText: escalation.reference })).toContainText("closed");
  await adminPage.goto(`/posts/${esc.id}`);
  const closedPanel = adminPage.getByRole("region", { name: /Escalate to CEO's Office/ });
  await expect(closedPanel).toContainText(escalation.reference);
  await expect(closedPanel).toContainText("closed");
  await expect(closedPanel).toContainText("Forwarded to the electrical department");
  // A report the college has already acted on can never be escalated.
  await adminPage.goto("/posts/14");
  await expect(adminPage.getByRole("region", { name: /Escalate to CEO's Office/ })).toContainText("Not eligible — action was taken");
  await adminCtx.close();
  console.log("PASS: CEO office escalation verified, created, deduplicated and handled by admin");

  expect(errors).toEqual([]);
  console.log("PASS: no uncaught browser errors");
} catch (err) {
  await page.screenshot({ path: "artifacts/kpriet-test-failure.png", fullPage: true }).catch(() => {});
  console.log("Browser diagnostic:", await page.evaluate(() => ({
    url: location.href,
    dialogOpen: document.querySelector("dialog")?.open,
    alerts: [...document.querySelectorAll('[role="alert"]')].map((el) => el.textContent),
    invalidInputs: [...document.querySelectorAll("input, textarea, select")].filter((el) => !el.checkValidity()).map((el) => ({ id: el.id, type: el.type, message: el.validationMessage, value: el.value })),
  })).catch(() => ({})));
  throw err;
} finally {
  for (const id of createdPosts) {
    const detail = await context.request.get(`/api/posts/${id}`);
    const { post } = await detail.json();
    await context.request.delete(`/api/posts/${id}`);
    if (post?.imageUrl) {
      const deletedPhoto = await context.request.get(post.imageUrl, { headers: { "Cache-Control": "no-cache" } });
      expect(deletedPhoto.status()).toBe(404);
    }
  }
  await browser.close();
}
