#!/usr/bin/env bash
# Local pre-flight check for the KPRIET Smart Campus portal.
# Run this before starting the app on a new machine.
set -u

FAIL=0
info() { echo "  OK   $*"; }
warn() { echo "  WARN $*"; }
fail() { echo "  FAIL $*"; FAIL=1; }

echo "===== KPRIET Smart Campus - local setup check ====="

echo "[1/4] Node.js"
if command -v node >/dev/null 2>&1; then
  info "node $(node --version)"
else
  fail "node not found - install Node.js 22+ (nodejs.org)"
fi

echo "[2/4] npm"
if command -v npm >/dev/null 2>&1; then
  info "npm $(npm --version)"
else
  fail "npm not found"
fi

echo "[3/4] PostgreSQL"
if command -v psql >/dev/null 2>&1; then
  info "psql found"
  if [ -z "${DATABASE_URL:-}" ] && [ -f .env ]; then
    DATABASE_URL=$(grep -E '^DATABASE_URL=' .env | head -1 | cut -d= -f2 | tr -d "\"'" | xargs)
  fi
  if [ -n "${DATABASE_URL:-}" ]; then
    if psql "$DATABASE_URL" -tAc "SELECT 1" >/dev/null 2>&1; then
      info "PostgreSQL reachable at ${DATABASE_URL}"
    else
      fail "cannot connect to ${DATABASE_URL}"
      warn "start PostgreSQL and check the URL in .env (create the DB with: psql -c "CREATE DATABASE app_db")"
    fi
  else
    warn "DATABASE_URL not set - copy .env.example to .env and edit it"
  fi
else
  warn "psql not found - install PostgreSQL (or: docker run --name kpriet-db -e POSTGRES_PASSWORD=postgres -p 5432:5432 postgres)"
fi

echo "[4/4] Project files"
[ -f package.json ] && info "package.json present" || fail "run this script from the project root"
[ -f .env ] && info ".env present" || warn "no .env - copy .env.example to .env and edit DATABASE_URL"
[ -d node_modules ] && info "dependencies installed" || warn "run npm install"

echo ""
if [ "$FAIL" -eq 0 ]; then
  echo "Setup looks ready. Run: npm run dev"
else
  echo "Fix the issues above, then re-run: bash scripts/local-check.sh"
fi
exit $FAIL
